import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "fran · 趣味工具箱",
  description: "计算、记录、专注、随机选择，给日常留一点好玩。",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
