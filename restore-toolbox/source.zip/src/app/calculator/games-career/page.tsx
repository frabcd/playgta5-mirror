import { NestedCareer } from "@/components/toolbox/nested-career";
export const metadata={title:'计算器 · fran'};
export default function Page(){return <NestedCareer tool="calculator" label="计算器"/>;}
