import { CalculatorEntrance } from "@/components/sites/lanqiushengya/calculator-entrance";
export const metadata={title:'计算器 · fran'};
export default function Page(){return <CalculatorEntrance/>;}
