import { NestedCareer } from "@/components/toolbox/nested-career";
export const metadata={title:'文档便签 · fran'};
export default function Page(){return <NestedCareer tool="notes" label="文档"/>;}
