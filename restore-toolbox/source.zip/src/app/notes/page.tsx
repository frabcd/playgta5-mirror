import { NotesTool } from "@/components/toolbox/tools";
export const metadata={title:'文档便签 · fran'};
export default function Page(){return <NotesTool/>;}
