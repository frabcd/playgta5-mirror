import { NestedCareer } from "@/components/toolbox/nested-career";
export const metadata={title:'专注时光机 · fran'};
export default function Page(){return <NestedCareer tool="timer" label="专注"/>;}
