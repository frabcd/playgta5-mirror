import { TimerTool } from "@/components/toolbox/tools";
export const metadata={title:'专注时光机 · fran'};
export default function Page(){return <TimerTool/>;}
