import { NestedCareer } from "@/components/toolbox/nested-career";
export const metadata={title:'命运转盘 · fran'};
export default function Page(){return <NestedCareer tool="wheel" label="随机"/>;}
