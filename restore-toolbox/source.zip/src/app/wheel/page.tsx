import { WheelTool } from "@/components/toolbox/tools";
export const metadata={title:'命运转盘 · fran'};
export default function Page(){return <WheelTool/>;}
