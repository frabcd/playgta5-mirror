import { ToolboxHome } from "@/components/toolbox/shell";

export default function Home() {
  return <ToolboxHome />;
}
