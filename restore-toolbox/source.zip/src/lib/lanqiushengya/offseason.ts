import { NBA_TEAMS, allSeasonGames, enterDraft, nextSeason, overall, signTeam, type Career, type RatingKey } from './engine';
import { getRoster, rosterSources } from './rosters';

export type DevelopmentFocus = 'shooting' | 'finishing' | 'playmaking' | 'defense' | 'physical' | 'recovery';
export interface OffseasonRecord { season: number; phase: 'college' | 'nba'; from: string; to: string; focus: DevelopmentFocus; route: 'return' | 'transfer' | 'draft' | 'freeagency'; before: Record<RatingKey, number>; after: Record<RatingKey, number>; summary: string }
export const DEVELOPMENT_PLANS: { id: DevelopmentFocus; title: string; description: string; keys: RatingKey[] }[] = [
  { id:'shooting', title:'投篮实验室', description:'重建出手稳定性，重点练中投、三分与罚球。', keys:['mid','three','freeThrow'] },
  { id:'finishing', title:'终结训练营', description:'磨练对抗中的突破与上篮，增加禁区终结手段。', keys:['drive','layup','handle'] },
  { id:'playmaking', title:'持球决策课', description:'阅读包夹和弱侧协防，提高控球、传球与移动能力。', keys:['pass','handle','speed'] },
  { id:'defense', title:'防守特训', description:'练习横移、身体对抗与护筐，提升内外线防守和盖帽。', keys:['interior','perimeter','block'] },
  { id:'physical', title:'力量与弹跳', description:'用力量房和场地训练打好基础，提高力量、速度与弹跳。', keys:['strength','speed','jump'] },
  { id:'recovery', title:'恢复与技术维护', description:'减少训练负担，调整身体状态，同时打磨罚球、篮板与传球。', keys:['freeThrow','dreb','pass'] },
];
export function isOffseason(c: Career) { return c.phase === 'college' ? c.game === 30 && c.ncaa?.stage === 'complete' : c.phase === 'nba' && c.game === 82 && c.nba?.stage === 'complete'; }
export function teamFit(c: Career, team: string) {
  const roster = getRoster(team, c.season + 1);
  const rivals = roster.filter(p => p.position === c.player.position).sort((a,b) => b.rating-a.rating);
  const difference = overall(c.player) - (rivals[0]?.rating ?? 70);
  const role = difference >= 5 ? 3 : difference >= -8 ? 2 : 1;
  return { roster, rivals, role, label: role === 3 ? '主力得分点' : role === 2 ? '竞争首发' : '轮换起步', minutes: role === 3 ? '28–34' : role === 2 ? '22–28' : '14–22', strength: Math.round(roster.slice(0,8).reduce((sum,p)=>sum+p.rating,0)/Math.max(1,Math.min(8,roster.length))) };
}
export function collegeOffers(c: Career) {
  const schools = rosterSources.filter(s => s.league === 'NCAA').map(s => s.team);
  const ranked = schools.filter(t=>t!==c.team).map(team=>({team,fit:teamFit(c,team)})).sort((a,b)=>Math.abs(a.fit.strength-overall(c.player))-Math.abs(b.fit.strength-overall(c.player)));
  return [c.team,...ranked.slice(0,7).map(t=>t.team)];
}
/** The season advances exactly once; the next season's number prevents replaying a camp. */
export function resolveOffseason(c: Career, focus: DevelopmentFocus, team = c.team, draft = false): Career {
  const plan = DEVELOPMENT_PLANS.find(p=>p.id===focus);
  if (!plan || !isOffseason(c) || c.offseasons?.some(r=>r.season===c.season)) return c;
  const completedCollegeYears = new Set([...c.history.filter(s=>s.phase==='college').map(s=>s.season), c.season]).size;
  if (c.phase === 'college' && !draft && completedCollegeYears < 4 && !collegeOffers(c).includes(team)) return c;
  if (c.phase === 'nba' && c.contract.years <= 1 && !NBA_TEAMS.includes(team)) return c;
  let next = draft ? enterDraft(c) : nextSeason(c);
  if (next === c || next.phase === 'retired') return next;
  let route: OffseasonRecord['route'] = next.phase !== c.phase ? 'draft' : 'return';
  if (c.phase === 'college' && next.phase === 'college' && team !== c.team) {
    const fit=teamFit(c,team);
    next={...next,team,role:fit.role,trust:40,confidence:Math.min(100,(next.confidence??75)+3)};
    route='transfer';
  } else if (next.phase==='nba' && c.phase==='nba' && next.contract.years===0) {
    next=signTeam(next,team);
    if(next.contract.years>0) route='freeagency';
  }
  const ratings={...next.player.ratings};
  for(const key of plan.keys) ratings[key]=Math.min(next.player.caps[key],ratings[key]+(focus==='recovery'?1:2));
  const summary=route==='draft'?`完成${plan.title}，参加选秀并加盟${next.team}。`:route==='transfer'?`完成${plan.title}，从${c.team}转学至${next.team}，从新的球队角色开始。`:route==='freeagency'?`完成${plan.title}，签约${next.team}，开启下一份职业合同。`:`完成${plan.title}，继续为${next.team}效力。`;
  const record:OffseasonRecord={season:c.season,phase:c.phase as 'college'|'nba',from:c.team,to:next.team,focus,route,before:{...c.player.ratings},after:{...ratings},summary};
  return {...next,energy:focus==='recovery'?100:90,player:{...next.player,ratings},offseasons:[...(c.offseasons??[]),record],log:[summary,...next.log].slice(0,100)};
}
export function seasonDebrief(c: Career) {
  const games=allSeasonGames(c), played=games.filter(g=>g.min>0), avg=(key:'pts'|'reb'|'ast')=>played.reduce((sum,g)=>sum+g[key],0)/Math.max(1,played.length);
  return {games:played.length,wins:games.filter(g=>g.won).length,losses:games.filter(g=>!g.won).length,pts:avg('pts'),reb:avg('reb'),ast:avg('ast'),best:played.reduce<typeof played[number]|undefined>((best,g)=>!best||g.pts>best.pts?g:best,undefined),honors:c.honors.filter(h=>h.includes(String(c.season)))};
}
