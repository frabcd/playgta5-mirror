import type { Career, GamePlan } from './engine';
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
export function offensiveWorkload(c:Career,tactic:GamePlan) {
  const r=c.player.ratings,role=c.role??2,ai=c.simulationPlan;
  const offense=(r.three+r.mid+r.drive+r.layup+r.handle)/5;
  const min=Math.round(clamp(({1:17,2:29,3:35,4:38}[role]??29)+(offense-65)/12+((c.trust??50)-50)/20+(Math.random()-.5)*6+(ai?.minutesAdjustment??0),10,c.phase==='college'?39:44));
  const roleUsage=({1:.7,2:.95,3:1.06,4:1.15}[role]??.95);
  const abilityUsage=clamp(.85+(offense-55)/100,.65,1.25);
  const usage=clamp(ai?.usage??1,.8,1.2),pace=clamp(ai?.pace??1,.92,1.08);
  const attempts=Math.round(clamp(15*(min/34)*roleUsage*abilityUsage*(.78+Math.random()*.44)*usage*pace+(tactic==='scoring'?4:tactic==='playmaking'?-2:tactic==='defense'?-2:0),3,34));
  const share=clamp(.12+(r.three-40)/120+(c.player.position==='C'?-.12:0),.08,.6);
  const tpa=Math.round(attempts*share),twoAttempts=attempts-tpa;
  const fta=Math.round(clamp((r.drive+r.layup)/35*(min/30)*roleUsage*(.4+Math.random()*1.4)+(tactic==='scoring'?2:0),0,16));
  return {min,tpa,twoAttempts,fta,pace,fitness:clamp(.8+c.energy/500,.8,1)};
}
