import { getRoster } from './rosters';
import type { AwardCandidate } from './nba-awards';
import { archive, simulateMatch, type Career, type GamePlan, type GameResult } from './engine';
export interface NcaaMatchup {
    id: string;
    stage: 'conference' | 'national';
    round: number;
    label: string;
    region: string;
    home: string;
    away: string;
    homeSeed: number;
    awaySeed: number;
    winner: string;
    homeScore?: number;
    awayScore?: number;
    game?: GameResult;
}
export interface NcaaAward {
    candidates?: AwardCandidate[];
    members?: AwardCandidate[];
    name: string;
    winner: string;
    team: string;
    detail: string;
    player: boolean;
    category: 'conference' | 'national' | 'tournament';
}
export interface NcaaState {
    season: number;
    stage: 'regular' | 'conference' | 'national' | 'complete';
    round: number;
    matchups: NcaaMatchup[];
    postseasonGames: GameResult[];
    awards: NcaaAward[];
    champion?: string;
    conferenceChampion?: string;
    finish?: string;
    qualified?: boolean;
}
export const NCAA_TEAMS = ['佛罗里达大学', '伊利诺伊大学', '维拉诺瓦大学', '杜克大学', '印第安纳大学', '休斯敦大学', '阿肯色大学', '威斯康星大学', '堪萨斯大学', '北卡罗来纳大学', '肯塔基大学', '康涅狄格大学', '冈萨加大学', '奥本大学', '田纳西大学', '亚利桑那大学', '普渡大学', '密歇根州立大学', '密歇根大学', '加州大学洛杉矶分校', '阿拉巴马大学', '爱荷华州立大学', '德克萨斯理工大学', '马里兰大学', '俄勒冈大学', '克莱姆森大学', '路易斯维尔大学', '圣约翰大学', '德克萨斯农工大学', '密苏里大学', '俄克拉荷马大学', '得克萨斯大学', '密西西比大学', '密西西比州立大学', '贝勒大学', '杨百翰大学', '犹他州立大学', '圣迭戈州立大学', '新墨西哥大学', '内华达大学', '克瑞顿大学', '马凯特大学', '泽维尔大学', '巴特勒大学', '乔治城大学', '普罗维登斯大学', '西顿霍尔大学', '圣玛丽大学', '圣克拉拉大学', '旧金山大学', '华盛顿州立大学', '代顿大学', '弗吉尼亚联邦大学', '乔治梅森大学', '耶鲁大学', '哈佛大学', '普林斯顿大学', '大峡谷大学', '利普斯科姆大学', '麦克尼斯州立大学', '德雷克大学', '自由大学', '罗伯特莫里斯大学', '诺福克州立大学'];
/** 2025–26 conference membership for the historical opening college season. */
export const NCAA_CONFERENCES: Record<string, string[]> = {
    SEC: ['佛罗里达大学', '阿肯色大学', '奥本大学', '田纳西大学', '肯塔基大学', '阿拉巴马大学', '德克萨斯农工大学', '密苏里大学', '俄克拉荷马大学', '得克萨斯大学', '密西西比大学', '密西西比州立大学'],
    'Big Ten': ['伊利诺伊大学', '印第安纳大学', '威斯康星大学', '密歇根州立大学', '密歇根大学', '普渡大学', '加州大学洛杉矶分校', '马里兰大学', '俄勒冈大学'],
    'Big 12': ['休斯敦大学', '堪萨斯大学', '贝勒大学', '德克萨斯理工大学', '亚利桑那大学', '爱荷华州立大学', '杨百翰大学', '辛辛那提大学'],
    ACC: ['杜克大学', '北卡罗来纳大学', '克莱姆森大学', '路易斯维尔大学', '弗吉尼亚大学', '弗吉尼亚理工大学', '迈阿密大学', '圣母大学'],
    'Big East': ['维拉诺瓦大学', '康涅狄格大学', '圣约翰大学', '克瑞顿大学', '马凯特大学', '泽维尔大学', '巴特勒大学', '乔治城大学', '普罗维登斯大学', '西顿霍尔大学'],
    A10: ['代顿大学', '弗吉尼亚联邦大学', '乔治梅森大学', '圣路易斯大学', '罗德岛大学', '戴维森大学', '里士满大学', '圣博纳文图拉大学'],
    WCC: ['冈萨加大学', '圣玛丽大学', '圣克拉拉大学', '旧金山大学', '华盛顿州立大学', '佩珀代因大学', '波特兰大学', '太平洋大学'],
};
export function ncaaConference(team: string) { return Object.keys(NCAA_CONFERENCES).find(key => NCAA_CONFERENCES[key].includes(team)) ?? '独立联盟'; }
const hash = (s: string) => Array.from(s).reduce((v, x) => (v * 31 + x.charCodeAt(0)) >>> 0, 7);
const nationalLabels = ['64 强', '32 强', '甜蜜 16 强', '精英 8 强', '全国半决赛', '全国决赛'];
export function collegeOpponent(c: Career) { const opponents = NCAA_TEAMS.filter(t => t !== c.team); return opponents[(c.season + c.game * 11) % opponents.length]; }
function makeMatch(c: Career, stage: NcaaMatchup['stage'], round: number, index: number, home = '', away = '', homeSeed = 0, awaySeed = 0): NcaaMatchup { return { id: `${c.season}-${stage}-${round}-${index}`, stage, round, label: stage === 'conference' ? ['联盟四分之一决赛', '联盟半决赛', '联盟决赛'][round - 1] : nationalLabels[round - 1], region: stage === 'conference' ? '联盟锦标赛' : round <= 4 ? ['东部', '西部', '南部', '中西部'][Math.floor(index / (32 / 2 ** (round - 1) / 4))] ?? '全国' : '全国', home, away, homeSeed, awaySeed, winner: '' }; }
function conferenceSlots(c: Career): NcaaMatchup[] { const pool = NCAA_CONFERENCES[ncaaConference(c.team)] ?? NCAA_TEAMS; const rivals = pool.filter(t => t !== c.team).sort((a, b) => hash(`${c.season}-${a}`) - hash(`${c.season}-${b}`)).slice(0, 7); const teams = [c.team, ...rivals]; const seed = Math.max(1, Math.min(8, 9 - Math.round(c.wins / 4))); teams.splice(0, 1); teams.splice(seed - 1, 0, c.team); const slots = [[0, 7], [3, 4], [1, 6], [2, 5]].map(([a, b], i) => makeMatch(c, 'conference', 1, i, teams[a], teams[b], a + 1, b + 1)); for (let round = 2; round <= 3; round++)
    for (let i = 0; i < 4 / 2 ** (round - 1); i++)
        slots.push(makeMatch(c, 'conference', round, i)); return slots; }
function nationalSlots(c: Career, n: NcaaState): NcaaMatchup[] { const qualified = c.wins >= 15 || n.conferenceChampion === c.team; n.qualified = qualified; const teams = NCAA_TEAMS.filter(t => t !== c.team); if (qualified)
    teams.unshift(c.team);
else
    teams.push('北卡大学威尔明顿分校'); const unique = [...new Set(teams)].slice(0, 64); const seeded = unique.sort((a, b) => a === c.team ? -1 : b === c.team ? 1 : hash(`${c.season}-${a}-seed`) - hash(`${c.season}-${b}-seed`)); if (qualified) {
    const team = seeded.shift()!;
    const seed = Math.max(1, Math.min(16, 17 - Math.floor(c.wins / 2)));
    seeded.splice((seed - 1) * 4, 0, team);
} const pattern = [1, 16, 8, 9, 5, 12, 4, 13, 6, 11, 3, 14, 7, 10, 2, 15]; const slots: NcaaMatchup[] = []; for (let region = 0; region < 4; region++)
    for (let i = 0; i < 8; i++) {
        const hs = pattern[i * 2], as = pattern[i * 2 + 1];
        slots.push(makeMatch(c, 'national', 1, region * 8 + i, seeded[(hs - 1) * 4 + region], seeded[(as - 1) * 4 + region], hs, as));
    } for (let round = 2; round <= 6; round++)
    for (let i = 0; i < 32 / 2 ** (round - 1); i++)
        slots.push(makeMatch(c, 'national', round, i)); return slots; }
function buildAwards(c: Career): NcaaAward[] { const games = c.games.filter(g => g.season === c.season && g.min > 0), n = games.length, avg = (key: 'pts' | 'reb' | 'ast' | 'stl' | 'blk' | 'min') => games.reduce((sum, g) => sum + g[key], 0) / Math.max(1, n); const eligible = n >= 21 && avg('min') >= 10, freshman = !c.history.some(s => s.phase === 'college' && s.season < c.season), impact = avg('pts') + avg('reb') + avg('ast'); const definitions: [
    string,
    boolean,
    NcaaAward['category'],
    string
][] = [['联盟年度最佳球员', impact >= 27, 'conference', '综合场均贡献达到 27'], ['联盟最佳防守球员', avg('stl') + avg('blk') >= 3.2, 'conference', '场均抢断与盖帽合计达到 3.2'], ['联盟最佳新秀', freshman && impact >= 18, 'conference', '大学第一年、综合场均贡献达到 18'], ['联盟最佳阵容一队', impact >= 22, 'conference', '综合场均贡献达到 22'], ['联盟最佳新秀阵容', freshman && impact >= 14, 'conference', '大学第一年、综合场均贡献达到 14'], ['联盟最佳防守阵容', avg('stl') + avg('blk') >= 2.4, 'conference', '场均抢断与盖帽合计达到 2.4'], ['奈史密斯年度最佳球员', impact >= 32, 'national', '综合场均贡献达到 32'], ['伍登奖', impact >= 33, 'national', '综合场均贡献达到 33'], ['奈史密斯最佳防守球员', avg('stl') + avg('blk') >= 4.5, 'national', '场均抢断与盖帽合计达到 4.5'], ['提斯代尔最佳新秀', freshman && impact >= 27, 'national', '大学第一年、综合场均贡献达到 27'], ['全美最佳阵容', impact >= 29, 'national', '综合场均贡献达到 29'], [`${({ PG: '鲍勃·库西', SG: '杰里·韦斯特', SF: '朱利叶斯·欧文', PF: '卡尔·马龙', C: '卡里姆·贾巴尔' })[c.player.position]}位置奖`, impact >= 28, 'national', '对应位置、综合场均贡献达到 28']]; const pool = NCAA_TEAMS.flatMap(team=>getRoster(team,c.season).slice(0,10).map((p,i): AwardCandidate & {position:string}=>({id:p.id,name:p.name,team,player:false,games:25,starts:i<5?25:3,pts:Math.max(4,(p.rating-50)*.55),reb:(p.position==='C'||p.position==='PF'?7:3)+(p.rating-65)/10,ast:(p.position==='PG'?5:2)+(p.rating-65)/15,stl:.6+(p.rating-60)/35,blk:(p.position==='C'||p.position==='PF'?1.2:.2)+(p.rating-60)/40,improvement:0,rookie:/fr|freshman/i.test(p.classYear??'')||p.generated,score:0,position:p.position})));
    if(eligible) pool.push({id:'user',name:c.player.name,team:c.team,player:true,games:n,starts:games.filter(g=>g.started).length,pts:avg('pts'),reb:avg('reb'),ast:avg('ast'),stl:avg('stl'),blk:avg('blk'),improvement:0,rookie:freshman,score:0,position:c.player.position});
    return definitions.map(([name,,category])=>{
      const candidates=pool.filter(p=>(category!=='conference'||ncaaConference(p.team)===ncaaConference(c.team))&&(!name.includes('新秀')||p.rookie)&&(!name.includes('位置奖')||p.position===c.player.position)).map(p=>({...p,score:Number((name.includes('防守')?p.stl*3+p.blk*3+p.reb*.4:p.pts+p.reb+p.ast).toFixed(2))})).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id)).slice(0,name.includes('阵容')?10:5);
      const members=name.includes('阵容')?candidates.slice(0,5):undefined,winner=candidates[0];
      return {name,winner:winner?.name??'无人符合资格',team:winner?.team??'',player:members?members.some(p=>p.player):winner?.player??false,category,candidates,members,detail:'本地候选评选：玩家常规赛至少 21 场且场均 10 分钟；联盟、年级和位置资格独立筛选。玩家数据来自比赛，其他候选数据为名单能力模型估算。'};
    }); }

export function ensureNcaa(c: Career): Career { if (c.phase !== 'college')
    return c; let n = c.ncaa; if (!n || n.season !== c.season)
    n = { season: c.season, stage: 'regular', round: 0, matchups: [], postseasonGames: [], awards: [] }; if (c.game >= 30 && n.stage === 'regular')
    n = { ...n, stage: 'conference', round: 1, matchups: conferenceSlots(c), awards: buildAwards(c) }; return n === c.ncaa ? c : { ...c, ncaa: n }; }
export function pendingNcaaMatch(c: Career) { const ready = ensureNcaa(c), n = ready.ncaa; if (!n || n.stage === 'regular' || n.stage === 'complete')
    return undefined; const m = n.matchups.find(m => m.stage === n.stage && m.round === n.round && !m.winner && (m.home === c.team || m.away === c.team)); if (!m)
    return undefined; const home = m.home === c.team; return { id: m.id, opponent: home ? m.away : m.home, home, stage: m.stage, round: m.round, label: m.label, seed: home ? m.homeSeed : m.awaySeed, opponentSeed: home ? m.awaySeed : m.homeSeed }; }
function completeTournament(c: Career, n: NcaaState) { n.champion = n.matchups.find(m => m.stage === 'national' && m.round === 6)?.winner; n.stage = 'complete'; n.finish = n.champion === c.team ? '全国总冠军' : n.finish ?? '未获全国锦标赛资格'; if (n.champion === c.team) {
    n.awards.push({ name: '全国锦标赛冠军', winner: c.player.name, team: c.team, player: true, category: 'tournament', detail: '赢得全国锦标赛全部六轮单场淘汰赛。' });
    const finalFour = n.postseasonGames.filter(g => n.matchups.some(m => m.id === g.id && m.stage === 'national' && m.round >= 5));
    if (finalFour.length === 2 && finalFour.reduce((sum, g) => sum + g.pts + g.reb + g.ast, 0) / 2 >= 20)
        n.awards.push({ name: '最终四强最杰出球员 MOP', winner: c.player.name, team: c.team, player: true, category: 'tournament', detail: '本地评选：全国冠军，最终四强两场平均得分、篮板、助攻之和至少 20。' });
} c.honors = [...new Set([...c.honors, ...n.awards.filter(a=>a.player).map(a => `${c.season} ${a.name}`)])]; }
/** One call is one tournament round and at most one user-team game, never an entire tournament. */
export function advanceNcaaPostseason(input: Career, tactic: GamePlan = 'balanced'): Career {
    if (input.phase !== 'college' || input.game < 30)
        return input;
    const ready = ensureNcaa(input), c = { ...ready, points: { ...ready.points }, ncaa: structuredClone(ready.ncaa) }, n = c.ncaa!;
    if (n.stage === 'complete')
        return input;
    const stage = n.stage as 'conference' | 'national', round = n.round;
    const current = n.matchups.filter(m => m.stage === stage && m.round === round);
    for (const m of current) {
        if (m.winner || !m.home || !m.away)
            continue;
        const own = m.home === c.team || m.away === c.team;
        if (own) {
            const home = m.home === c.team, g = simulateMatch(c, home ? m.away : m.home, home, tactic, stage, m.id);
            m.game = g;
            m.homeScore = home ? g.teamScore : g.opponentScore;
            m.awayScore = home ? g.opponentScore : g.teamScore;
            m.winner = g.won ? c.team : g.opponent;
            n.postseasonGames.push(g);
            c.energy = Math.max(20, c.energy - (tactic === 'scoring' ? 8 : 5));
            for (const group of Object.keys(c.points) as (keyof Career['points'])[])
                c.points[group] += 2;
            if (!g.won)
                n.finish = stage === 'conference' ? `联盟${m.label.replace('联盟', '')}出局` : `全国${m.label.replace('全国', '')}出局`;
        }
        else {
            const probability = Math.max(.2, Math.min(.8, .5 + (m.awaySeed - m.homeSeed) * .02)), win = Math.random() < probability;
            m.homeScore = 58 + Math.floor(Math.random() * 30);
            m.awayScore = m.homeScore + (win ? -1 : 1) * (1 + Math.floor(Math.random() * 17));
            m.winner = win ? m.home : m.away;
        }
    }
    const lastRound = stage === 'conference' ? 3 : 6;
    if (round < lastRound) {
        const next = n.matchups.filter(m => m.stage === stage && m.round === round + 1);
        next.forEach((m, i) => { const a = current[i * 2], b = current[i * 2 + 1]; m.home = a.winner; m.away = b.winner; m.homeSeed = a.winner === a.home ? a.homeSeed : a.awaySeed; m.awaySeed = b.winner === b.home ? b.homeSeed : b.awaySeed; });
        n.round++;
    }
    else if (stage === 'conference') {
        n.conferenceChampion = current[0].winner;
        if (n.conferenceChampion === c.team) {
            n.awards.push({ name: '联盟锦标赛冠军', winner: c.player.name, team: c.team, player: true, category: 'tournament', detail: '联盟锦标赛三连胜。' });
            const games = n.postseasonGames.filter(g => g.stage === 'conference');
            if (games.length === 3 && games.reduce((sum, g) => sum + g.pts + g.reb + g.ast, 0) / 3 >= 20)
                n.awards.push({ name: '联盟锦标赛最杰出球员 MOP', winner: c.player.name, team: c.team, player: true, category: 'tournament', detail: '本地评选：联盟锦标赛冠军，三场平均得分、篮板、助攻之和至少 20。' });
        }
        n.matchups.push(...nationalSlots(c, n));
        n.stage = 'national';
        n.round = 1;
        if (n.qualified)
            n.finish = undefined;
        else
            n.finish = '未获全国锦标赛资格';
    }
    else
        completeTournament(c, n);
    c.honors = [...new Set([...c.honors, ...n.awards.filter(a => a.player).map(a => `${c.season} ${a.name}`)])];
    c.log = [(n.stage as NcaaState['stage']) === 'complete' ? `全国锦标赛结束：${n.champion}夺冠；${n.finish}。可以进入休赛期。` : `${current[0]?.label}结束。${n.stage === 'national' && n.round === 1 ? `${n.qualified ? '获得' : '未获得'}全国锦标赛资格。` : ''}`, ...c.log].slice(0, 100);
    return archive(c);
}
