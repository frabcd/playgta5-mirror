import { NBA_TEAMS, type Career } from './engine';
import { getRoster, rosterSources } from './rosters';
import type { NbaAward, NbaSeries } from './nba';

export interface AwardCandidate {
  id: string; name: string; team: string; player: boolean; games: number; starts: number;
  pts: number; reb: number; ast: number; stl: number; blk: number; improvement: number; rookie: boolean; score: number;
}
const hash = (s: string) => Array.from(s).reduce((v, x) => (v * 31 + x.charCodeAt(0)) >>> 0, 7);
const contribution = (p: AwardCandidate) => p.pts + p.reb * 1.2 + p.ast * 1.5 + (p.stl + p.blk) * 2;

/** NPC averages are a deterministic local season model, not official statistics. */
export function awardPool(c: Career): AwardCandidate[] {
  const elapsed = Math.max(1, c.game);
  const college = new Set(rosterSources.filter(s => s.league === 'NCAA').flatMap(s => getRoster(s.team, 2026).map(p => p.name)));
  const pool = NBA_TEAMS.flatMap(team => getRoster(team, c.season).sort((a,b)=>b.rating-a.rating).map((p, index) => {
    const seed = hash(`${c.season}-${p.id}`), big = ['C', 'PF'].includes(p.position), guard = p.position === 'PG';
    const games = Math.max(1, Math.floor(elapsed * (0.78 + seed % 22 / 100)));
    return { id: p.id, name: p.name, team, player: false, games, starts: index < 5 ? games : Math.floor(games * .15),
      pts: Math.max(3, (p.rating - 55) * .72 + seed % 30 / 10 - (index >= 5 ? 5 : 0)),
      reb: Math.max(1, (p.rating - 55) * (big ? .27 : .12)), ast: Math.max(1, (p.rating - 55) * (guard ? .24 : .09)),
      stl: .3 + Math.max(0,p.rating-60)*.04*(guard?1.1:.85) + seed%4/10, blk: .1+Math.max(0,p.rating-60)*(big?.075:.012)+seed%4/10,
      improvement: .5 + seed % 60 / 10,
      rookie: c.season === 2026 ? college.has(p.name) : p.generated && p.id.includes(String(c.season)), score: 0 };
  }));
  // Future draft classes have explicit simulated identities instead of reusing real veterans as rookies.
  if (pool.filter(p => p.rookie).length < 10) for (let i = 0; i < 12; i++) pool.push({ id: `rookie-${c.season}-${i}`, name: `${c.season}届模拟新秀 ${i + 1}`, team: NBA_TEAMS[i], player: false, games: Math.floor(elapsed * .9), starts: Math.floor(elapsed * .6), pts: 10 + i * .55, reb: 3 + i % 5, ast: 2 + i % 4, stl: 1, blk: .5, improvement: 0, rookie: true, score: 0 });
  const games = c.games.filter(g => g.season === c.season && g.min > 0);
  const avg = (k: 'pts'|'reb'|'ast'|'stl'|'blk') => games.reduce((s,g) => s+g[k],0)/Math.max(1,games.length);
  const previous = c.games.filter(g => g.season === c.season-1 && g.phase === 'nba' && g.min > 0);
  pool.push({ id: 'user', name: c.player.name, team: c.team, player: true, games: games.length, starts: games.filter(g => g.started ?? (c.role ?? 2) >= 2).length, pts: avg('pts'), reb: avg('reb'), ast: avg('ast'), stl: avg('stl'), blk: avg('blk'), improvement: previous.length ? avg('pts') - previous.reduce((s,g)=>s+g.pts,0)/previous.length : 0, rookie: !c.history.some(s => s.phase === 'nba' && s.season < c.season), score: 0 });
  return pool;
}
export function buildNbaAwards(c: Career): NbaAward[] {
  const pool = awardPool(c), progress = Math.min(1, c.game/82);
  const rules: [string, number, (p: AwardCandidate)=>boolean, (p: AwardCandidate)=>number, string][] = [
    ['常规赛 MVP',1,p=>p.games>=65*progress,p=>contribution(p)+(c.nba?.standings.find(t=>t.team===p.team)?.wins??0)/Math.max(.1,progress)*.35,'65 场；综合贡献与球队胜场'],
    ['最佳新秀',1,p=>p.rookie&&p.games>=50*progress,contribution,'新秀资格、50 场；综合贡献'],
    ['最佳防守球员',1,p=>p.games>=65*progress,p=>p.stl*3+p.blk*3+p.reb*.4,'65 场；抢断、盖帽、篮板'],
    ['最佳第六人',1,p=>p.games>=50*progress&&p.starts<p.games/2,contribution,'50 场且替补场次多于首发；综合贡献'],
    ['进步最快球员',1,p=>!p.rookie&&p.games>=65*progress&&p.improvement>0,p=>p.improvement,'65 场；相比上季常规赛场均得分增幅'],
    ...(['pts','reb','ast','stl','blk'] as const).map((key,i): typeof rules[number] => [['得分王','篮板王','助攻王','抢断王','盖帽王'][i],1,p=>p.games>=58*progress,p=>p[key],'58 场；按对应场均数据排名']),
    ['最佳阵容',15,p=>p.games>=65*progress,contribution,'65 场；综合贡献排序，一至三阵各 5 人'],
    ['最佳防守阵容',10,p=>p.games>=65*progress,p=>p.stl*3+p.blk*3+p.reb*.4,'65 场；防守贡献排序，一至二阵各 5 人'],
    ['最佳新秀阵容',10,p=>p.rookie&&p.games>=50*progress,contribution,'新秀资格、50 场；一至二阵各 5 人'],
    ['全明星',24,p=>p.games>=30*progress,contribution,'30 场；本地综合贡献前 24 人，赛季末汇总'],
  ];
  return rules.map(([name,count,eligible,score,detail])=>{
    const ranked=pool.filter(eligible).map(p=>({...p,score:Math.round(score(p)*100)/100})).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
    const members=ranked.slice(0,count), winner=members[0];
    return {name,winner:winner?.name??'本季无人符合资格',team:winner?.team??'',player:members.some(p=>p.player),detail:`本地评选：${detail}。你的数据取自比赛记录；其他球员为赛季模型估算，不是官方统计。`,members:count>1?members:undefined,candidates:ranked.slice(0,Math.max(5,count))};
  });
}

export function seriesMvp(c: Career, series: NbaSeries, name: string): NbaAward {
  const totals = new Map<string, AwardCandidate>();
  for (const g of series.games) {
    const box = g.team === series.winner ? g.boxScore?.team : g.opponent === series.winner ? g.boxScore?.opponent : undefined;
    for (const p of box ?? []) if (p.min > 0) {
      const row = totals.get(p.id) ?? {id:p.id,name:p.name,team:series.winner,player:p.isUser,games:0,starts:0,pts:0,reb:0,ast:0,stl:0,blk:0,improvement:0,rookie:false,score:0};
      row.games++; for(const k of ['pts','reb','ast','stl','blk'] as const) row[k]+=p[k]; totals.set(p.id,row);
    }
  }
  const actual = totals.size > 0;
  const candidates = actual ? [...totals.values()].map(p=>({...p,score:contribution(p)})) : awardPool(c).filter(p=>p.team===series.winner&&!p.player).map(p=>({...p,score:contribution(p)}));
  candidates.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  for (const p of candidates) if(actual) for(const k of ['pts','reb','ast','stl','blk'] as const) p[k]/=p.games;
  const winner=candidates[0];
  return {name,winner:winner?.name??'冠军队球员',team:series.winner,player:winner?.player??false,candidates:candidates.slice(0,5),detail:actual?'按获胜球队本轮逐场箱分累计贡献评选，候选表显示场均数据。':'本轮没有个人箱分，依据获胜球队名单及赛季模型估算，不补造逐场表现。'};
}
