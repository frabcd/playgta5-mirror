import type { Career, GameResult } from './engine';
import { getRoster, type RosterPlayer } from './rosters';

export interface BoxPlayer {
  id: string; name: string; position: string; generated: boolean; source?: string; isUser: boolean; started: boolean;
  min: number; pts: number; reb: number; ast: number; stl: number; blk: number; to: number;
  fgm: number; fga: number; tpm: number; tpa: number; ftm: number; fta: number;
}
export interface MatchBoxScore { team: BoxPlayer[]; opponent: BoxPlayer[] }
const hash = (text: string) => Array.from(text).reduce((sum, c) => (sum * 31 + c.charCodeAt(0)) >>> 0, 17);
/** Integer allocation preserves a team total exactly, including rounding remainders. */
function allocate(total: number, weights: number[]): number[] {
  const sum = weights.reduce((s, n) => s + n, 0);
  const exact = weights.map(w => total * w / sum);
  const amounts = exact.map(Math.floor);
  let remainder = total - amounts.reduce((s, n) => s + n, 0);
  const order = exact.map((n, i) => ({ i, fraction: n - amounts[i] })).sort((a, b) => b.fraction - a.fraction);
  for (const item of order) { if (remainder <= 0) break; amounts[item.i]++; remainder--; }
  return amounts;
}
function pool(team: string, season: number, size: number): RosterPlayer[] {
  const players = getRoster(team, season).slice(0, size);
  while (players.length < size) {
    const i = players.length;
    const position = (['PG', 'SG', 'SF', 'PF', 'C'] as const)[i % 5];
    players.push({ id: `simulated-${team}-${i}`, name: `模拟球员 ${i + 1}`, position, listedPosition: position, rating: 65, generated: true });
  }
  return players;
}
function rosterLine(p: RosterPlayer, index: number, min: number, pts: number, key: string): BoxPlayer {
  const seed = hash(`${key}-${p.id}`);
  const perimeter = p.position === 'PG' || p.position === 'SG' || p.position === 'SF';
  const tpm = Math.floor(pts * (perimeter ? .35 : .15) / 3);
  const remaining = pts - tpm * 3;
  const ftm = remaining % 2 + 2 * Math.floor(remaining * .12 / 2);
  const twoMade = (remaining - ftm) / 2;
  const tpa = tpm + (min > 0 && perimeter ? seed % 4 : 0);
  const fgm = twoMade + tpm;
  return { id: p.id, name: p.name, position: p.position, generated: p.generated, source: p.source, isUser: false, started: index < 5, min, pts, reb: 0, ast: 0, stl: 0, blk: 0, to: 0, fgm, fga: twoMade + Math.round(twoMade * (.5 + (seed % 50) / 100)) + tpa, tpm, tpa, ftm, fta: ftm + (ftm ? seed % 2 : 0) };
}
function teamBox(g: GameResult, c: Career, own: boolean): BoxPlayer[] {
  const players = pool(own ? g.team ?? c.team : g.opponent, g.season, own ? 9 : 10);
  const college = (g.phase ?? c.phase) === 'college';
  const overtime = Math.max(0, (g.periods?.length ?? (college ? 2 : 4)) - (college ? 2 : 4));
  const minutes = (college ? 200 : 240) + overtime * 25;
  const allocatedMinutes = allocate(minutes - (own ? g.min : 0), players.map((_, i) => players.length - i));
  const pts = allocate((own ? g.teamScore - g.pts : g.opponentScore), players.map((p, i) => allocatedMinutes[i] * (p.rating + hash(`${g.id}-${p.id}`) % 30)));
  const rows = players.map((p, i) => rosterLine(p, i, allocatedMinutes[i], pts[i], g.id));
  if (own && g.started) rows.forEach((p, i) => { p.started = i < 4; });
  const metrics = { reb: Math.max(0, 39 - (own ? g.reb : 0)), ast: Math.max(0, Math.min(26, rows.reduce((s, r) => s + r.fgm, 0) + (own ? g.fgm : 0)) - (own ? g.ast : 0)), stl: Math.max(0, 8 - (own ? g.stl : 0)), blk: Math.max(0, 5 - (own ? g.blk : 0)), to: Math.max(0, 13 - (own ? g.to ?? 0 : 0)) };
  for (const metric of Object.keys(metrics) as (keyof typeof metrics)[]) {
    const weights = players.map((p, i) => allocatedMinutes[i] * (metric === 'reb' || metric === 'blk' ? (p.position === 'C' || p.position === 'PF' ? 2 : .8) : metric === 'ast' ? (p.position === 'PG' ? 2.4 : 1) : 1));
    const values = allocate(metrics[metric], weights);
    rows.forEach((p, i) => { p[metric] = values[i]; });
  }
  if (own) rows.unshift({ id: `user-${c.player.name}`, name: c.player.name, position: c.player.position, generated: false, isUser: true, started: !!g.started, min: g.min, pts: g.pts, reb: g.reb, ast: g.ast, stl: g.stl, blk: g.blk, to: g.to ?? 0, fgm: g.fgm, fga: g.fga, tpm: g.tpm, tpa: g.tpa, ftm: g.ftm, fta: g.fta });
  return rows;
}
/** Names come from the sourced roster; every game's statistics are simulated, never historical facts. */
export function addBoxScore(g: GameResult, c: Career): GameResult {
  if (g.boxScore) return g;
  return { ...g, boxScore: { team: teamBox(g, c, true), opponent: teamBox(g, c, false) } };
}
export function validBoxScore(value: MatchBoxScore): boolean {
  return !!value && [value.team, value.opponent].every(rows => Array.isArray(rows) && rows.length >= 5 && rows.every(p => p && typeof p.name === 'string' && typeof p.position === 'string' && typeof p.isUser === 'boolean' && typeof p.generated === 'boolean' && ['min', 'pts', 'reb', 'ast', 'stl', 'blk', 'to', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta'].every(key => Number.isInteger(p[key as keyof BoxPlayer]) && Number(p[key as keyof BoxPlayer]) >= 0) && p.pts === p.fgm * 2 + p.tpm + p.ftm && p.fga >= p.fgm && p.tpa >= p.tpm && p.fta >= p.ftm));
}
