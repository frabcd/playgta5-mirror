import type { Career } from './engine';
import type { Appearance } from '../../components/sites/lanqiushengya/pixel-art';

export interface SavedCareer { id: string; updated: string; appearance: Appearance; career: Career }
export const LEGACY_STORAGE_KEY = 'kba-local-careers-v1';
export const STORAGE_FAILURE_MESSAGE = '本机存档保存失败。当前进度仍保留在页面内，请导出备份后再关闭页面。';
const DB_NAME = 'kba-career-archive';
const STORE = 'careers';
const META = 'settings';
let connection: Promise<IDBDatabase> | undefined;

/** Snapshot at enqueue time; a rejected write must not prevent later retries. */
export function createSerialWriter<T>(write: (value: T) => Promise<void>) {
  let pending: Promise<void> = Promise.resolve();
  return {
    enqueue(value: T) {
      const snapshot = structuredClone(value);
      const result = pending.then(() => write(snapshot));
      pending = result.catch(() => undefined);
      return result;
    },
    settled: () => pending,
  };
}
function database(): Promise<IDBDatabase> {
  if (connection) return connection;
  connection = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') { reject(new Error('IndexedDB unavailable')); return; }
    const request = indexedDB.open(DB_NAME, 1);
    let rejected = false;
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(META)) db.createObjectStore(META);
    };
    request.onerror = () => reject(request.error ?? new Error('Unable to open save database'));
    request.onblocked = () => { rejected = true; reject(new Error('Save database upgrade blocked')); };
    request.onsuccess = () => {
      const db = request.result;
      if (rejected) { db.close(); return; }
      db.onversionchange = () => { db.close(); connection = undefined; };
      resolve(db);
    };
  }).catch(error => { connection = undefined; throw error; });
  return connection;
}
async function commit(entries: SavedCareer[], activeId: string | null, migrate = false) {
  const db = await database();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction([STORE, META], 'readwrite');
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error('Save transaction aborted'));
    transaction.onerror = () => reject(transaction.error ?? new Error('Save transaction failed'));
    entries.forEach(entry => transaction.objectStore(STORE).put(entry));
    transaction.objectStore(META).put(activeId, 'activeId');
    if (migrate) transaction.objectStore(META).put(true, 'legacyMigrated');
  });
}
const writes = createSerialWriter<{ entries: SavedCareer[]; activeId: string | null; migrate?: boolean }>(value => commit(value.entries, value.activeId, value.migrate));
export function persistCareer(entry: SavedCareer) { return writes.enqueue({ entries: [entry], activeId: entry.id }); }
export function persistDraftSelection() { return writes.enqueue({ entries: [], activeId: null }); }
export function flushCareerWrites() { return writes.settled(); }
export async function loadCareers(legacy: SavedCareer[] = []): Promise<{ saves: SavedCareer[]; activeId: string | null }> {
  await flushCareerWrites();
  const db = await database();
  const result = await new Promise<{ saves: SavedCareer[]; activeId: string | null | undefined; migrated: boolean }>((resolve, reject) => {
    const transaction = db.transaction([STORE, META], 'readonly');
    const all = transaction.objectStore(STORE).getAll();
    const active = transaction.objectStore(META).get('activeId');
    const migrated = transaction.objectStore(META).get('legacyMigrated');
    transaction.oncomplete = () => resolve({ saves: all.result, activeId: active.result, migrated: migrated.result === true });
    transaction.onabort = () => reject(transaction.error ?? new Error('Unable to read saves'));
    transaction.onerror = () => reject(transaction.error ?? new Error('Unable to read saves'));
  });
  if (!result.migrated) {
    const existing = new Set(result.saves.map(s => s.id));
    const missing = legacy.filter(s => !existing.has(s.id));
    result.saves.push(...missing);
    if (result.activeId === undefined) result.activeId = result.saves.sort((a, b) => b.updated.localeCompare(a.updated))[0]?.id ?? null;
    await writes.enqueue({ entries: missing, activeId: result.activeId, migrate: true });
    // Keep the old localStorage JSON as a recovery backup, even after migration commits.
  }
  return { saves: result.saves.sort((a, b) => b.updated.localeCompare(a.updated)), activeId: result.activeId ?? null };
}
