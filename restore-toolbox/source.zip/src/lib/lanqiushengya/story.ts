import type { Career, TrainingGroup } from './engine';
import { getRoster } from './rosters';
import { STORY_EVENTS, type StoryChoiceDefinition, type StoryDefinition, type StoryEffects, type StoryMeter, type StoryPhase } from './story-data';
export type { StoryEffects, StoryMeter } from './story-data';
export interface StorySnapshot {energy:number;confidence:number;trust:number;points:Record<TrainingGroup,number>;meters:Record<StoryMeter,number>}
export interface StoryRecord {
  key:string;eventId:string;title:string;choiceId:string;choiceLabel:string;season:number;game:number;progress:number;phase:StoryPhase;
  context:string;body:string;outcome:string;effects:StoryEffects;before:StorySnapshot;after:StorySnapshot;followUp?:string;
}
export interface StoryState {version:1;meters:Record<StoryMeter,number>;history:StoryRecord[];flags:Record<string,boolean>}
export interface StoryEvent {id:string;title:string;body:string;context:string;category:string;choices:StoryChoiceDefinition[];scheduledGame:number;catchUp:boolean;fictional:true}
const meters:StoryMeter[]=['chemistry','reputation','pressure','academics','leadership'];
const groups:TrainingGroup[]=['shooting','finishing','playmaking','defense','rebounding','physical','freeThrow'];
const clamp=(v:number,lo=0,hi=100)=>Math.max(lo,Math.min(hi,v));
const hash=(text:string)=>Array.from(text).reduce((v,c)=>(v*31+c.charCodeAt(0))>>>0,17);
const progress=(c:Career)=>c.game+(c.phase==='college'?c.ncaa?.postseasonGames.length??0:c.nba?.playoffGames.length??0);
const key=(c:Career,id:string)=>`${c.season}:${c.phase}:${id}`;
export function getStoryState(c:Career):StoryState {
  const saved=(c as Career&{story?:StoryState}).story;
  return saved??{version:1,meters:{chemistry:50,reputation:30,pressure:35,academics:65,leadership:35},history:[],flags:{}};
}
function snapshot(c:Career,state:StoryState):StorySnapshot{return {energy:c.energy,confidence:c.confidence??75,trust:c.trust??50,points:{...c.points},meters:{...state.meters}};}
function permitted(c:Career,event:StoryDefinition):boolean {
  if(event.phase!=='shared'&&event.phase!==c.phase)return false;
  if(event.minGame!==undefined&&c.game<event.minGame)return false;
  if(event.condition==='injured'&&!c.nba?.injury)return false;
  if(event.condition==='rookie'&&c.history.some(s=>s.phase===c.phase&&s.season<c.season))return false;
  if(event.condition==='veteran'&&!c.history.some(s=>s.phase===c.phase&&s.season<c.season))return false;
  if(event.condition==='postseason'&&c.game<(c.phase==='college'?30:82))return false;
  return true;
}
function render(c:Career,event:StoryDefinition,scheduledGame:number):StoryEvent {
  const roster=getRoster(c.team,c.season).filter(p=>p.name!==c.player.name);
  const teammate=roster.length?roster[hash(`${c.player.name}-${event.id}`)%Math.min(5,roster.length)].name:'一位队友';
  const interpolate=(text:string)=>text.replaceAll('{teammate}',teammate).replaceAll('{team}',c.team).replaceAll('{name}',c.player.name);
  const catchUp=progress(c)>scheduledGame+2;
  return {id:event.id,title:interpolate(event.title),body:interpolate(event.body),category:event.category,context:`${c.season}–${String(c.season+1).slice(-2)} · ${c.phase==='college'?'大学':'NBA'} · ${scheduledGame===0?'季前准备':`第 ${scheduledGame} 场后`}${catchUp?' · 待处理的赛季片段（回顾补记）':''} · 原创虚构剧情`,choices:event.choices.map(choice=>({...choice,label:interpolate(choice.label),description:interpolate(choice.description),outcome:interpolate(choice.outcome),effects:structuredClone(choice.effects)})),scheduledGame,catchUp,fictional:true};
}
/** Unresolved scenes are optional. Advancing games never silently selects a response. */
export function getAvailableStory(c:Career):StoryEvent|undefined {
  if(c.phase==='retired')return undefined;
  const state=getStoryState(c),played=progress(c);
  const season=state.history.filter(r=>r.season===c.season&&r.phase===c.phase);
  const seen=new Set(season.map(r=>r.eventId));
  for(const record of season){
    if(!record.followUp||seen.has(record.followUp)||played<record.progress+2)continue;
    const follow=STORY_EVENTS.find(e=>e.id===record.followUp);
    if(follow&&permitted(c,follow))return render(c,follow,record.progress+2);
  }
  const thresholds=c.phase==='college'?[0,2,5,8,10,13,16,19,22,25,28,30]:[0,4,9,14,19,24,30,36,42,48,54,60,66,72,78,82];
  const answered=season.filter(r=>!STORY_EVENTS.find(e=>e.id===r.eventId)?.followUpOnly).length;
  if(answered>=thresholds.length||played<thresholds[answered])return undefined;
  const pool=STORY_EVENTS.filter(e=>!e.followUpOnly&&!seen.has(e.id)&&permitted(c,e));
  if(!pool.length)return undefined;
  // A deterministic order makes reloads safe: opening a scene cannot reroll it.
  pool.sort((a,b)=>hash(`${c.player.name}-${c.season}-${a.id}`)-hash(`${c.player.name}-${c.season}-${b.id}`));
  const postseason=pool.find(e=>e.condition==='postseason');
  const injury=pool.find(e=>e.condition==='injured');
  const selected=postseason??injury??pool[0];
  const scheduled=Math.max(thresholds[answered],selected.minGame??0,selected.condition==='postseason'?(c.phase==='college'?30:82):0,selected.condition==='injured'?played:0);
  return render(c,selected,scheduled);
}
/** Only the currently available event can be committed; stale clicks and repeated IDs are no-ops. */
export function chooseStory(c:Career,eventId:string,choiceId:string):Career {
  const available=getAvailableStory(c);
  if(!available||available.id!==eventId)return c;
  const choice=available.choices.find(option=>option.id===choiceId);
  if(!choice)return c;
  const current=getStoryState(c);
  if(current.history.some(r=>r.key===key(c,eventId)))return c;
  const state:StoryState={version:1,meters:{...current.meters},history:[...current.history],flags:{...current.flags}};
  const before=snapshot(c,state),effects=choice.effects;
  const updated:Career={...c,energy:clamp(c.energy+(effects.energy??0)),confidence:clamp((c.confidence??75)+(effects.confidence??0)),trust:clamp((c.trust??50)+(effects.trust??0)),points:{...c.points}};
  for(const group of groups)updated.points[group]=clamp(updated.points[group]+(effects.points?.[group]??0),0,100000);
  for(const meter of meters)state.meters[meter]=clamp(state.meters[meter]+(effects.meters?.[meter]??0));
  const after=snapshot(updated,state);
  const actual:StoryEffects={energy:after.energy-before.energy,confidence:after.confidence-before.confidence,trust:after.trust-before.trust,points:{},meters:{}};
  for(const group of groups)if(after.points[group]!==before.points[group])actual.points![group]=after.points[group]-before.points[group];
  for(const meter of meters)if(after.meters[meter]!==before.meters[meter])actual.meters![meter]=after.meters[meter]-before.meters[meter];
  state.flags[key(c,eventId)]=true;
  if(choice.followUp)state.flags[`follow:${c.season}:${choice.followUp}`]=true;
  state.history.push({key:key(c,eventId),eventId,title:available.title,choiceId,choiceLabel:choice.label,season:c.season,game:c.game,progress:progress(c),phase:c.phase as StoryPhase,context:available.context,body:available.body,outcome:choice.outcome,effects:actual,before,after,followUp:choice.followUp});
  return Object.assign(updated,{story:state,log:[`生涯故事「${available.title}」：${choice.outcome}`,...c.log].slice(0,100)});
}
/** Small bounded deltas, not hidden deterministic wins: chemistry aids playmaking, pressure costs composure. */
export function getStoryModifiers(c:Career):{scoring:number;playmaking:number;defense:number;stamina:number} {
  const m=getStoryState(c).meters;
  const bound=(v:number)=>clamp(v,-.06,.06);
  return {scoring:bound((m.reputation-30)/2200-(m.pressure-35)/1600),playmaking:bound((m.chemistry-50)/1000),defense:bound((m.leadership-35)/1400),stamina:bound((m.chemistry-50)/2400-(m.pressure-35)/1600)};
}
export function validateStory(value:unknown):value is StoryState {
  if(!value||typeof value!=='object')return false;
  const s=value as StoryState;
  const finite=(n:unknown)=>typeof n==='number'&&Number.isFinite(n);
  const bounded=(n:unknown)=>finite(n)&&Number(n)>=0&&Number(n)<=100;
  const validMeters=(m:StoryState['meters'])=>!!m&&meters.every(k=>bounded(m[k]));
  const validSnapshot=(v:StorySnapshot)=>!!v&&[v.energy,v.confidence,v.trust].every(bounded)&&validMeters(v.meters)&&!!v.points&&groups.every(g=>finite(v.points[g])&&v.points[g]>=0&&v.points[g]<=100000);
  const validEffects=(e:StoryEffects)=>!!e&&typeof e==='object'&&[e.energy,e.confidence,e.trust].every(n=>n===undefined||finite(n))&&(!e.points||(typeof e.points==='object'&&Object.entries(e.points).every(([k,n])=>groups.includes(k as TrainingGroup)&&finite(n))))&&(!e.meters||(typeof e.meters==='object'&&Object.entries(e.meters).every(([k,n])=>meters.includes(k as StoryMeter)&&finite(n))));
  return s.version===1&&validMeters(s.meters)&&!!s.flags&&typeof s.flags==='object'&&!Array.isArray(s.flags)&&Object.values(s.flags).every(v=>typeof v==='boolean')&&Array.isArray(s.history)&&new Set(s.history.map(r=>r?.key)).size===s.history.length&&s.history.every(r=>r&&[r.key,r.eventId,r.title,r.choiceId,r.choiceLabel,r.context,r.body,r.outcome].every(v=>typeof v==='string')&&['college','nba'].includes(r.phase)&&[r.season,r.game,r.progress].every(n=>Number.isInteger(n)&&n>=0)&&validSnapshot(r.before)&&validSnapshot(r.after)&&validEffects(r.effects)&&(r.followUp===undefined||typeof r.followUp==='string'));
}
