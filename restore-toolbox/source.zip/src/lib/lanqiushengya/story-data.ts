export type StoryPhase = 'college' | 'nba';
export type StoryMeter = 'chemistry' | 'reputation' | 'pressure' | 'academics' | 'leadership';
export interface StoryEffects {
  energy?: number; confidence?: number; trust?: number;
  points?: Partial<Record<'shooting'|'finishing'|'playmaking'|'defense'|'rebounding'|'physical'|'freeThrow',number>>;
  meters?: Partial<Record<StoryMeter,number>>;
}
export interface StoryChoiceDefinition {id:string;label:string;description:string;outcome:string;effects:StoryEffects;followUp?:string}
export interface StoryDefinition {id:string;phase:StoryPhase|'shared';category:string;title:string;body:string;choices:StoryChoiceDefinition[];followUpOnly?:boolean;condition?:'injured'|'rookie'|'veteran'|'postseason';minGame?:number}
const choice=(id:string,label:string,description:string,outcome:string,effects:StoryEffects,followUp?:string):StoryChoiceDefinition=>({id,label,description,outcome,effects,followUp});
const event=(id:string,phase:StoryDefinition['phase'],category:string,title:string,body:string,choices:StoryChoiceDefinition[],extra:Partial<StoryDefinition>={}):StoryDefinition=>({id,phase,category,title,body,choices,...extra});
/** All dialogue and incidents are original fictional career scenes, not claims about real people. */
export const STORY_EVENTS:StoryDefinition[]=[
 event('campus-roommate','college','校园生活','宿舍里的第一场录像课','{teammate}发现你深夜还在看球队录像，问你是否愿意一起研究下一位对手。桌上另一边，是还没交的课程作业。',[
 choice('film','一起拆解挡拆','花精力建立配合，但今晚无法兼顾所有事情。','你们画出三种挡拆回应；{teammate}开始主动与你交流跑位。',{energy:-7,points:{playmaking:4},meters:{chemistry:7,academics:-3}},'campus-film-follow'),
 choice('study','先完成作业，约明天见','稳住学业与节奏，给合作留下明确安排。','你把作业按时交上，也把明天的录像时间写进日程。',{confidence:2,meters:{academics:7,chemistry:2}}),
 choice('sleep','解释疲劳，早点休息','恢复体能，暂时放下额外沟通。','你没有硬撑到凌晨，第二天以更好的精神走进球馆。',{energy:9,meters:{chemistry:-2}})]),
 event('campus-professor','college','学业','教授留下的提醒','一次客场之旅让你错过小组讨论。教授愿意听你的补交计划，队内加练也正好安排在同一时段。',[
 choice('class','参加补课','减少加练，承担学生的责任。','你与教授确定了补交时间，不再把问题推到下一周。',{energy:-4,trust:-1,meters:{academics:10,pressure:-4}}),
 choice('balance','与教练协调时间','主动说明安排，承担更紧凑的日程。','教练认可你的提前沟通；你完成了补课和缩短后的训练。',{energy:-9,trust:3,meters:{academics:5,leadership:3}}),
 choice('practice','本周优先训练','多获得训练积累，但课程压力会追上来。','你留在球馆，随后收到下一次学业约谈的通知。',{points:{shooting:5},meters:{academics:-9,pressure:6}},'campus-academic-follow')]),
 event('campus-captain','college','球队关系','队长把白板递给你','训练结束后，队长请你解释一次失败的防守轮转。你可以指出问题，也可以把这次发言变成共同复盘。',[
 choice('own','先说明自己的漏人','建立责任感，承受短暂的自我审视。','你承认自己晚移动了一步，其他人也开始讨论各自的位置。',{confidence:-2,trust:4,meters:{chemistry:6,leadership:6}}),
 choice('teach','提出一套沟通口令','把问题转成可执行的合作。','你们约定新的换防口令，并在下一组演练中反复确认。',{energy:-4,points:{defense:3},meters:{chemistry:4,leadership:4}})]),
 event('campus-fan','college','校园生活','食堂外的签名请求','几名学生在食堂门口认出你，想请你签名合影。距离球队会议开始只剩十分钟。',[
 choice('brief','简单致谢后准时离开','尊重支持者，也守住球队时间。','你留下几句感谢，准时进入会议室。',{meters:{reputation:4,leadership:2}}),
 choice('stay','多聊一会','亲近校园球迷，需要承担迟到的后果。','大家很高兴；教练则在会议后提醒了你的时间观念。',{trust:-4,meters:{reputation:8,pressure:3}})]),
 event('campus-rival','college','竞争','对手在赛前提起你','校园媒体把你的名字放进宿敌战预告。记者希望你回应对方球员一句带火药味的评价。',[
 choice('calm','把注意力放回比赛','降低外界压力，保持合作基调。','你表示比赛会给出答案，然后把话题转向全队准备。',{meters:{pressure:-5,reputation:2,leadership:3}}),
 choice('challenge','公开接受挑战','提高关注，也抬高自己的心理负担。','你的回应成为赛前标题，训练馆外多了几位采访者。',{confidence:5,meters:{pressure:8,reputation:6}},'rival-follow')]),
 event('campus-scout','college','选秀观察','看台上出现球探','助教提醒你，今天的训练有球探旁观。一次精巧但高风险的传球机会出现在你面前。',[
 choice('simple','把简单的球处理好','强调稳定判断和教练信任。','你完成了正确的转移，没有为了镜头改变日常习惯。',{trust:5,points:{playmaking:3},meters:{pressure:-2}}),
 choice('show','展示练过的高难度技术','承担更高压力，争取信心与曝光。','你主动练习了那次传球，并记录需要改进的细节。',{energy:-6,confidence:4,meters:{reputation:5,pressure:6}})]),
 event('campus-midterm','college','学业','期中周与客场名单','期中考试和连续客场重叠。学业顾问帮你列出可以调整的复习时间，但你要自己选择优先级。',[
 choice('plan','每天固定复习一小时','牺牲部分休息，避免最后一晚突击。','小块复习时间逐渐累积，考试不再像一团无法处理的压力。',{energy:-5,meters:{academics:9,pressure:-5}}),
 choice('tutor','邀请队友结伴补习','把学习变成互相支持的安排。','你和{teammate}在旅途中互相抽问，关系也更熟悉了。',{energy:-6,meters:{academics:6,chemistry:6}})]),
 event('campus-bench','college','角色竞争','替补队友的沉默','{teammate}训练结束后留在座位上。他觉得自己的出场机会减少，不确定该不该找教练谈。',[
 choice('listen','先听他说完','花时间倾听，不承诺你无法决定的轮换。','你认真听完他的担忧，建议他带着具体问题和教练沟通。',{energy:-3,meters:{chemistry:8,leadership:4}}),
 choice('compete','约一次公平的一对一','用球场交流，但可能加重竞争感。','训练结束后你们打了一组一对一，彼此也看清了需要补强的地方。',{energy:-8,points:{finishing:4},meters:{chemistry:2,pressure:3}})]),
 event('campus-home','college','家庭','家人问你最近是否太累','电话那头的家人没有追问数据，只问你有没有按时吃饭。你第一次意识到已经很久没有聊过篮球之外的事情。',[
 choice('honest','坦诚说说压力','获得支持，放下逞强。','说出真实感受后，你重新整理了这一周最重要的几件事。',{confidence:3,meters:{pressure:-9}}),
 choice('visit','邀请家人来看主场','增加期待，也把家人带入赛季。','你们约好了时间，下一场主场比赛多了一份具体的牵挂。',{confidence:5,meters:{pressure:3,reputation:2}})]),
 event('campus-transfer','college','生涯选择','转学话题被提起','一篇报道猜测你是否会在休赛期转学。当前没有任何决定，队友却开始担心你的投入。',[
 choice('commit','说明当前专注于球队','把未来决定留到赛季结束。','你向队友表明这一季会全力以赴，私下保留对未来的思考。',{trust:4,meters:{chemistry:6,pressure:-3}}),
 choice('evaluate','请顾问整理发展选择','收集信息，并承担传闻带来的摩擦。','你列出发展需求，也主动向队友解释自己尚未做出决定。',{confidence:3,meters:{reputation:3,chemistry:-4,pressure:4}})],{minGame:12}),
 event('campus-freshman','college','成长','新生的第一次公开演讲','学校邀请你给新生讲一次适应大学的经历。你可以分享篮球，也可以谈那些不在集锦里的困难。',[
 choice('real','讲一次失败和调整','以真实经历建立联系。','你谈到失误、补课和重新开始，台下有人认真记下了建议。',{meters:{reputation:5,leadership:6,pressure:-2}}),
 choice('demo','带大家做基础动作','把精力投入互动教学。','你带领学生完成简单的传接球练习，活动比预计更热闹。',{energy:-6,points:{playmaking:2},meters:{reputation:6,chemistry:3}})],{condition:'rookie'}),
 event('campus-nil','college','商业与声誉','本地商店的合作邀约','一家校园附近的商店提出宣传合作。这里只讨论职业态度，不会自动签合同或产生真实交易。',[
 choice('review','先让顾问审核内容','慎重处理形象和时间安排。','你把合作细节交给顾问，明确不影响训练与学业的底线。',{meters:{leadership:4,reputation:3,pressure:-2}}),
 choice('decline','本赛季暂不参与','减少分心，放弃一些曝光。','你礼貌谢绝了邀约，把日程还给训练和课程。',{energy:4,meters:{pressure:-5,reputation:-1}})]),
 event('campus-crowd','college','客场挑战','客场学生区的噪声','热身时，学生看台反复喊你的名字。队友打趣说，这代表他们认为你值得被针对。',[
 choice('routine','坚持自己的罚球准备','用可重复动作稳定情绪。','你把注意力拉回呼吸、拍球与出手节奏。',{points:{freeThrow:4},meters:{pressure:-4}}),
 choice('fuel','把噪声当作动力','提高进取心，也接受紧绷感。','你和队友击掌，决定用更积极的防守回应客场气氛。',{confidence:5,energy:-3,meters:{pressure:4,chemistry:2}})]),
 event('campus-lab','college','训练研究','体能组展示你的移动数据','体能教练发现你在连续比赛后横移质量下降。减少额外训练或调整项目，都需要放下“练得越多越好”的想法。',[
 choice('recover','安排主动恢复','优先恢复身体，暂缓技能加练。','你完成了低强度恢复，并重新获得训练的耐心。',{energy:10,meters:{pressure:-3}}),
 choice('technique','减少总量，练移动技术','用有目的的训练替代堆时间。','你把训练缩短为几组高质量横移，结束后记录动作感受。',{energy:-4,points:{physical:4,defense:2},trust:2})]),
 event('campus-graduation','college','团队传承','学长谈起离队后的生活','一位即将毕业的队友问你，除了下一场比赛，还想给这支球队留下些什么。更衣室突然安静下来。',[
 choice('mentor','接手帮助年轻队友','让领导力成为日常工作。','你开始在训练后帮助新队友理解战术，而不是等到他们犯错。',{energy:-4,meters:{leadership:8,chemistry:5}}),
 choice('record','整理球队训练笔记','把经验留下来供后人使用。','你把整季的战术注释整理成清楚的训练笔记。',{points:{playmaking:3},meters:{academics:3,leadership:5}})],{minGame:18}),
 event('campus-selection','college','锦标赛','等待全国锦标赛席位','联盟赛程结束，球队看着全国锦标赛的讨论。外界预测不能替代真正的赛果，接下来仍需你们自己准备。',[
 choice('film','研究不同类型的对手','为单场淘汰赛准备多种回应。','你们复盘了联防、快节奏与内线强队的比赛片段。',{energy:-6,points:{defense:4},trust:3}),
 choice('bond','一起吃一顿安静的晚餐','让队友从预测和排名中暂时抽离。','这一晚没有人统计投票，大家只聊这一路走过的客场。',{energy:3,meters:{chemistry:7,pressure:-6}})],{condition:'postseason'}),
 event('nba-rookie-bag','nba','职业适应','新秀的第一趟长途客场','球队工作人员介绍了客场日程：航班、治疗、会议、训练。你开始理解职业赛季比一场比赛长得多。',[
 choice('routine','建立自己的恢复清单','把可靠习惯放在第一位。','你和训练师确认了睡眠与恢复安排，不再临时猜测该做什么。',{energy:8,meters:{leadership:3,pressure:-3}}),
 choice('veteran','请{teammate}分享经验','主动学习职业更衣室的节奏。','你记下几条客场建议，也更自然地融入了球队交流。',{trust:2,meters:{chemistry:7}})],{condition:'rookie'}),
 event('nba-agent','nba','职业规划','经纪人发来一份日程表','商业采访与休息日安排挤在一起。经纪人请你明确哪些时段必须留给训练和恢复。',[
 choice('boundary','为恢复留出固定时间','少一些曝光，换取稳定状态。','团队重新排好了日程，你终于有一段不被打断的恢复时间。',{energy:9,meters:{pressure:-5,reputation:-2}}),
 choice('select','只保留一项重点采访','在曝光和恢复之间做取舍。','你选了一次能完整表达自己想法的采访，其余安排延期。',{energy:-3,meters:{reputation:6,pressure:2}})]),
 event('nba-screen','nba','战术关系','队友希望挡拆更有耐心','{teammate}在训练后指出，你们的挡拆经常差半拍。他想和你多练几种启动时机。',[
 choice('reps','留下来配合十分钟','消耗精力，积累更默契的进攻。','你们逐渐找到相同的节奏，并给几种配合起了简短口令。',{energy:-7,points:{playmaking:4},meters:{chemistry:7}},'nba-screen-follow'),
 choice('video','先看录像再练','重视观察与交流，减少今天的负荷。','你们在录像里标出彼此的习惯，约好下次训练再验证。',{energy:-2,points:{playmaking:2},meters:{chemistry:4,leadership:2}})]),
 event('nba-trade-rumor','nba','交易流言','你的名字出现在流言里','一位记者把你写进交易猜测。报道并不意味着交易已发生，但它已经影响到更衣室里的谈话。',[
 choice('private','私下向球队询问定位','争取信息，避免把猜测升级成公开冲突。','你表达了对未来的疑问，也重申会完成眼前的训练安排。',{trust:3,meters:{pressure:-4,leadership:3}}),
 choice('public','公开表达留队意愿','向队友与球迷表态，同时承受更多关注。','你的回应被广泛转发，队友感谢你把球队放进答案。',{meters:{chemistry:6,reputation:5,pressure:4}},'nba-rumor-follow'),
 choice('silence','暂时不回应','保留空间，但需要独自处理不确定感。','你关掉了社交媒体提醒，把这件事暂时留在球馆门外。',{energy:3,meters:{pressure:2}})]),
 event('nba-backtoback','nba','赛程管理','背靠背之间的清晨','旅馆闹钟响起时，你仍能感到双腿发沉。训练师建议减少额外负荷，队内投篮练习则照常开放。',[
 choice('recover','接受恢复安排','优先体能，为下一场保留精力。','你完成了轻量活动和恢复治疗，没有因为缺席加练而自责。',{energy:12,meters:{pressure:-2}}),
 choice('short','进行短时定点投篮','控制训练量，保持手感。','你只练习了少量比赛常用位置，到时间便准时收工。',{energy:-4,points:{shooting:4}})]),
 event('nba-media','nba','媒体','一段采访被截成短视频','你关于战术的长段回答被剪成一句话，有人认为你在抱怨队友。原本普通的采访开始发酵。',[
 choice('talk','先与队友面对面解释','把真正的关系放在评论区之前。','你和{teammate}把原话说清楚，大家决定不被断章取义牵着走。',{meters:{chemistry:8,pressure:-4,leadership:3}}),
 choice('clarify','发布简短澄清','回应公众误解，但让话题继续停留一阵。','你补充了完整语境，并表示接下来会专注于比赛。',{meters:{reputation:4,pressure:3}})]),
 event('nba-contract','nba','合同规划','经纪人谈起长期价值','经纪人问你，未来希望通过什么建立职业价值：角色稳定、全面能力，还是更高的个人曝光？这次谈话不会自动改变合同。',[
 choice('role','先把当前角色做到可靠','重视教练信任与团队需求。','你们整理了一份可以持续改进的角色清单。',{trust:5,meters:{leadership:4}}),
 choice('growth','制定全面发展目标','为长期成长投入额外精力。','你把休息日的一部分留给弱项训练，同时约定定期复盘。',{energy:-6,points:{defense:3,playmaking:3},meters:{pressure:3}})]),
 event('nba-veteran','nba','更衣室','老将让你主持录像讨论','教练希望更多人参与讨论。{teammate}把遥控器递过来，示意你从一个熟悉的回合开始。',[
 choice('invite','先请队友讲各自判断','让会议成为共同解决问题的场合。','不同位置的视角让大家看见同一个回合里不同的难处。',{trust:3,meters:{leadership:7,chemistry:5}}),
 choice('lead','提出自己的调整建议','清楚表达判断，并承担验证建议的责任。','你提出的调整被加入下一次训练，结果还需要大家一起检验。',{confidence:4,points:{playmaking:3},meters:{leadership:5,pressure:2}})]),
 event('nba-fan-night','nba','社区','主场社区活动','球队邀请你参加社区篮球活动。孩子们比起数据，更想知道你遇到困难时会怎么做。',[
 choice('teach','带一组基础训练','用行动建立社区联系。','你耐心示范脚步，直到最后一名孩子也敢主动尝试。',{energy:-6,meters:{reputation:8,leadership:4}}),
 choice('share','分享一段真实感受','用个人经历回应他们的好奇。','你谈到训练中的失误和坚持，把球星光环暂时放到一边。',{confidence:2,meters:{reputation:5,pressure:-3}})]),
 event('nba-role-change','nba','球队角色','教练尝试新的轮换搭配','教练准备在训练中试验一套不同的阵容。你的任务可能更偏向无球，而不是每次持球发起。',[
 choice('adapt','主动熟悉无球路线','适应球队需求，积累不同技能。','你和助教逐个确认掩护后的阅读选项。',{energy:-5,trust:6,points:{shooting:3},meters:{chemistry:3}}),
 choice('discuss','说明自己的优势和顾虑','争取理解，同时接受试验需要耐心。','你提出具体问题，教练也解释了这套搭配想解决的困难。',{trust:2,confidence:3,meters:{leadership:4}})]),
 event('nba-slump','nba','心理调整','训练中的连续打铁','一次投篮练习结束时，命中数远低于自己的预期。你可以继续追加，也可以暂停并检查疲劳与动作。',[
 choice('mechanics','检查动作，控制练习量','以过程替代焦虑。','你找到出手前的一个小偏差，用少量高质量练习重新确认。',{energy:-3,points:{shooting:5},meters:{pressure:-3}}),
 choice('reset','离开球馆，接受今天的状态','给身体和注意力恢复的空间。','你把今天的记录留在本子上，没有把一次训练定义成整个赛季。',{energy:8,confidence:2,meters:{pressure:-6}})]),
 event('nba-injury','nba','伤病恢复','康复室里的耐心','恢复期间，你听见球场上传来队友训练的声音。医疗安排不会因为焦虑而提前结束，但你仍能决定怎样度过今天。',[
 choice('rehab','严格完成康复计划','以长期状态为重，不擅自提前复出。','你按训练师安排完成恢复，记录身体反馈。伤停仍按原计划推进。',{energy:9,meters:{pressure:-5,leadership:3}}),
 choice('film','帮队友做录像笔记','在不能上场时保持参与感。','你把观察交给{teammate}，也找回了自己属于球队的感觉。',{energy:-2,points:{playmaking:3},meters:{chemistry:6,pressure:-3}})],{condition:'injured'}),
 event('nba-allstar','nba','关注与期待','全明星讨论季','媒体开始讨论全明星人选。即使名单还没有确定，外界比较也很容易改变你的训练心态。',[
 choice('team','把目标落在球队进步','避免每天追踪排名带来的起伏。','你与教练确定了几个可执行的过程目标。',{trust:3,meters:{pressure:-6,leadership:3}}),
 choice('ambition','承认自己想争取认可','让雄心成为动力，同时正视压力。','你没有回避目标，也提醒自己投票不由一场训练决定。',{confidence:5,meters:{reputation:4,pressure:6}})],{minGame:24}),
 event('nba-deadline','nba','交易截止日','截止日前的更衣室','更衣室里的手机提示音比平常更多。有人可能离开，也有人可能加入，但眼前的训练仍需要大家一起完成。',[
 choice('welcome','主动照顾不安的队友','在不确定中维持合作。','你邀请几位队友一起吃饭，没有追问任何传闻的真假。',{meters:{chemistry:8,leadership:5,pressure:-2}}),
 choice('focus','列出今天能控制的事情','稳定个人节奏，不参与流言猜测。','你按计划完成训练，把手机留在更衣柜里。',{energy:3,confidence:3,meters:{pressure:-5}})],{minGame:36}),
 event('nba-playoff','nba','季后赛','淘汰赛前的战术会议','常规赛结束后，每一次准备都被放大。球队需要更清楚的沟通，而不是更多相互传染的紧张。',[
 choice('detail','仔细研究对手的固定配合','投入精力，强化防守准备。','你记录了几种常见启动方式，并和队友确认各自职责。',{energy:-7,points:{defense:5},trust:3}),
 choice('unity','组织一次轻松的队内交流','降低压力，维持合作关系。','大家谈到各自面对大场面的方法，紧张感不再只有一个人承担。',{meters:{chemistry:7,pressure:-8,leadership:3}})],{condition:'postseason'}),
 event('nba-legacy','nba','职业责任','年轻队友向你请教','一个年轻队友问，怎样才能在漫长赛季里保持专注。你突然意识到，自己也在成为别人观察的榜样。',[
 choice('mentor','分享方法并持续跟进','把经验变成真正的支持。','你和他约定定期交流，不只是留下几句励志的话。',{energy:-4,meters:{leadership:9,chemistry:5}}),
 choice('practice','邀请他一起完成基础训练','通过共同练习传递职业习惯。','你们从枯燥的基础动作开始，认真完成了每一组。',{energy:-7,points:{physical:3},meters:{leadership:6,chemistry:4}})]),
 event('shared-free-throw','shared','专项训练','最后十次罚球','训练将结束时，助教提出做一组带干扰的罚球。你今天的精力已经不多，可以选择怎样收尾。',[
 choice('challenge','完成干扰训练','用消耗换取专项经验。','你记录了十次罚球的节奏问题，下一次有了明确的练习重点。',{energy:-6,points:{freeThrow:5},confidence:2}),
 choice('rest','按原计划停止训练','尊重恢复安排。','你带着还没耗尽的精力离开，准备明天再继续。',{energy:6,meters:{pressure:-2}})]),
 event('shared-film','shared','战术学习','一个反复出现的空位','你在录像中发现，对手的协防后总会短暂出现一个空位。能否利用它，取决于队友与你是否想到一起。',[
 choice('share','把发现发给队友讨论','强调团队阅读。','{teammate}补充了自己的视角，你们找到了更简单的传球窗口。',{points:{playmaking:4},meters:{chemistry:4}}),
 choice('practice','在训练里验证路线','以动作检验判断。','你多次演练观察与传球，逐渐缩短了决策时间。',{energy:-6,points:{playmaking:5},trust:2})]),
 event('shared-social','shared','心理调整','评论区里的噪声','一条关于你表现的帖子引来争论。支持和批评混在一起，继续刷新似乎没有终点。',[
 choice('mute','关闭提醒，回到日常','减少外界评价对情绪的控制。','手机安静下来，你把注意力留给了一顿完整的晚餐。',{energy:4,meters:{pressure:-8}}),
 choice('reflect','只记录一条具体建议','区分可行动的反馈和情绪。','你写下值得向教练请教的细节，然后停止浏览。',{trust:2,meters:{pressure:-3,leadership:3}})]),
 event('shared-defend','shared','训练竞争','一对一防守邀请','{teammate}想在训练结束后多打一组一对一。他说，只有认真防守的对手才能暴露自己的问题。',[
 choice('play','认真完成一组对抗','双方互相帮助，同时增加负荷。','你们交换了几次攻防，并坦诚指出对方容易被预判的动作。',{energy:-8,points:{defense:5},meters:{chemistry:4}}),
 choice('watch','今天帮他录像','降低负荷，换一种方式支持训练。','你逐帧指出他的启动习惯，也从旁观中学到新的判断方式。',{points:{defense:2},meters:{chemistry:3,leadership:2}})]),
 event('shared-nutrition','shared','生活管理','营养师看了你的饮食记录','忙碌的日程让你经常随便解决一餐。营养师提出更稳定的安排，希望你选一个能长期坚持的起点。',[
 choice('routine','固定一餐的时间与内容','从容易执行的习惯开始。','你不再追求完美菜单，而是先把一件事稳定下来。',{energy:7,meters:{leadership:2}}),
 choice('team','邀请队友一起改善','用互相提醒帮助坚持。','你和{teammate}约定训练后一起吃饭，恢复变成共同安排。',{energy:4,meters:{chemistry:5}})]),
 event('shared-referee','shared','纪律','训练赛中的争议判罚','一次训练赛判罚让你很不服气。下一回合已经开始，队友在等你回到防守位置。',[
 choice('reset','立即回防，赛后再问','控制情绪并维护球队节奏。','你把疑问留到训练结束，用平静的问题换来清楚的解释。',{trust:4,meters:{leadership:5,pressure:-3}}),
 choice('speak','短暂说明意见后跟上','表达感受，但承受教练对专注度的提醒。','你表达了自己的观察，随后重新投入训练。',{confidence:3,trust:-1,meters:{pressure:2}})]),
 event('shared-focus','shared','目标管理','这一周只选一个重点','助教让你从投篮、防守、组织中选一个短期目标。不是所有弱项都能在同一周解决。',[
 choice('shoot','稳定常用位置的出手','积累投篮训练点。','你的训练记录第一次围绕一个清楚的问题展开。',{energy:-5,points:{shooting:5},meters:{pressure:-2}}),
 choice('defend','改善一次防守轮转','积累防守训练点。','你开始更早观察持球人之外的位置。',{energy:-5,points:{defense:5},trust:2}),
 choice('pass','减少犹豫的传球','积累组织训练点。','你把注意力放在接球前的观察，决策逐渐更干脆。',{energy:-5,points:{playmaking:5},meters:{chemistry:2}})]),
 event('shared-rest-day','shared','休息日','没有比赛的一天','日历上终于出现一块空白。你可以独处、和队友相处，或者把空白继续填成训练。',[
 choice('alone','给自己完整的休息','补充体力，降低压力。','你暂时离开计分板与训练表，重新感到身体恢复了余地。',{energy:11,meters:{pressure:-5}}),
 choice('team','和队友做些篮球之外的事','用共同经历增加默契。','你发现{teammate}在球场之外也有许多有趣的故事。',{energy:4,meters:{chemistry:7}}),
 choice('work','进行轻量弱项练习','少休息一点，换取技术积累。','你只练了一个细节，按时结束，没有把休息日变成惩罚。',{energy:-5,points:{finishing:4},confidence:2})]),
 event('campus-film-follow','college','后续 · 配合','那套挡拆口令又被提起','你和{teammate}之前研究的配合已经进入日常交流。助教希望你们决定下一步：简化它，还是增加变化。',[
 choice('simple','把最稳定的一种练熟','加强信任和执行。','你们删去多余变化，让更多队友能快速理解。',{trust:5,meters:{chemistry:5,leadership:3}}),
 choice('expand','再尝试一个变化','为组织训练投入更多精力。','你们新增了一个应对换防的选项，同时承认仍需要时间磨合。',{energy:-6,points:{playmaking:5},meters:{chemistry:3,pressure:2}})],{followUpOnly:true}),
 event('campus-academic-follow','college','后续 · 学业','补交作业的最后提醒','之前把训练放在前面留下了课程欠账。学业顾问给出两种补救安排，都需要你实际投入时间。',[
 choice('intensive','集中完成补交','较大体能消耗，尽快稳住学业。','你完成了补交安排，并重新制定了不会无限拖延的计划。',{energy:-12,meters:{academics:14,pressure:-7}}),
 choice('steady','按每天的小目标补上','恢复较慢，但日程更平衡。','你把任务拆成几步，每天向顾问汇报完成情况。',{energy:-5,meters:{academics:8,pressure:-3,leadership:2}})],{followUpOnly:true}),
 event('rival-follow','shared','后续 · 竞争','公开挑战之后','你之前公开接受挑战，让更多人注意到这组对位。教练提醒你，不能让证明自己压过球队的判断。',[
 choice('team','向教练说明团队优先','把个人动力放回整体计划。','你与队友确认了职责，不再把每个回合都当成个人回应。',{trust:5,meters:{pressure:-6,chemistry:4}}),
 choice('prepare','为具体对位做额外准备','承担额外负荷，将情绪变成细节。','你研究了对方的习惯，用明确准备替代笼统的狠话。',{energy:-7,points:{defense:4},confidence:3,meters:{pressure:2}})],{followUpOnly:true}),
 event('nba-screen-follow','nba','后续 · 配合','挡拆后的第二次阅读','你和{teammate}的额外训练得到助教注意。现在他希望你们在第一种路线被堵住时，也能保持耐心。',[
 choice('read','练第二次传球','组织经验与默契继续积累。','你们开始观察弱侧，而不是在第一条路线失败时停球。',{energy:-6,points:{playmaking:5},meters:{chemistry:6}}),
 choice('communicate','把配合解释给更多队友','提升团队沟通而非只建立双人习惯。','其他队友加入讨论，这套配合不再只属于你们两人。',{trust:4,meters:{chemistry:5,leadership:6}})],{followUpOnly:true}),
 event('nba-rumor-follow','nba','后续 · 流言','表态之后的队内谈话','你之前表达了留队意愿。{teammate}说，比公开发言更重要的，是之后每天如何参与球队。',[
 choice('daily','用稳定的日常回应','让承诺落在训练态度上。','你按计划完成自己的工作，没有再主动放大流言。',{trust:5,meters:{chemistry:6,pressure:-4}}),
 choice('open','坦诚讨论不确定感','用开放沟通换取理解。','你承认未来无法保证，但眼前的投入是真实的。',{meters:{chemistry:7,leadership:4,pressure:-5}})],{followUpOnly:true}),
];
