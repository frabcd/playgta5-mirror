import rosterData from './roster-data.json' with { type: 'json' };

export interface RosterPlayer {
  id: string;
  name: string;
  position: 'PG' | 'SG' | 'SF' | 'PF' | 'C';
  listedPosition: string;
  height?: number;
  number?: string;
  rating: number;
  source?: string;
  generated: boolean;
  classYear?: string;
}
interface SourceRoster {
  league: string; season: string; retrieved: string; url: string;
  players: { id: string; name: string; position: string; height?: number; number?: string; rating: number; source: string; classYear?: string }[];
}
const data: Record<string, SourceRoster> = rosterData;
const aliases: Record<string, string> = { '休斯顿大学': '休斯敦大学', '北卡大学': '北卡罗来纳大学', '冈萨加': '冈萨加大学', '俄克拉荷马城雷霆': '俄克拉荷马雷霆', '德州理工大学': '德克萨斯理工大学' };
export const rosterSources = Object.entries(data).map(([team, r]) => ({ team, league: r.league, season: r.season, retrieved: r.retrieved, url: r.url, playerCount: r.players.length }));
export const ROSTER_NOTE = 'NBA：2026-10-12 官网季前赛名单；NCAA：2025–26 官网历史名单作为开局球员池。能力值和细分位置为本地游戏估计，后续赛季为模拟发展。';
const hash = (s: string) => Array.from(s).reduce((n, c) => ((n * 31 + c.charCodeAt(0)) >>> 0), 7);
// These are balancing estimates, not NBA/college official ratings or statistics.
const ratings: Record<string, number> = {
  'Nikola Jokić': 98, 'Nikola Jokic': 98, 'Shai Gilgeous-Alexander': 97, 'Luka Dončić': 96, 'Luka Doncic': 96,
  'Giannis Antetokounmpo': 97, 'Victor Wembanyama': 94, 'Jayson Tatum': 93, 'Stephen Curry': 94,
  'Anthony Edwards': 94, 'Donovan Mitchell': 93, 'Jalen Brunson': 93, 'Kevin Durant': 92, 'Devin Booker': 91,
  'Cade Cunningham': 91, 'LeBron James': 91, 'Anthony Davis': 92, 'Kawhi Leonard': 90, 'Tyrese Haliburton': 90,
  'Jaylen Brown': 90, 'Karl-Anthony Towns': 89, 'Paolo Banchero': 89, 'Franz Wagner': 88, 'Chet Holmgren': 89,
  'Bam Adebayo': 88, 'Evan Mobley': 90, 'Tyrese Maxey': 89, 'Jalen Williams': 90, 'Alperen Sengun': 89,
  'Alperen Şengün': 89, 'Jamal Murray': 87, 'Austin Reaves': 85, 'Trae Young': 88, 'LaMelo Ball': 86,
  'Scottie Barnes': 87, 'James Harden': 87, 'Zion Williamson': 87, 'Darius Garland': 87, 'Domantas Sabonis': 88,
  'Derrick White': 84, 'Walker Kessler': 83, 'Alex Caruso': 80, 'Rudy Gobert': 83, 'Jarrett Allen': 85,
  'Cooper Flagg': 88, 'Dylan Harper': 83, 'Darryn Peterson': 82, 'Cameron Boozer': 82, 'AJ Dybantsa': 83,
  'JT Toppin': 82, 'Graham Ike': 80, 'Alex Condon': 79, 'Thomas Haugh': 79, 'Rueben Chinyelu': 77,
  'Darius Acuff Jr.': 80, 'Nate Ament': 79, 'Emanuel Sharp': 79, 'Milos Uzan': 77, 'Joseph Tugler': 79,
  'Flory Bidunga': 78, 'Boogie Fland': 78, 'Kylan Boswell': 78, 'Tomislav Ivisic': 78, 'John Blackwell': 78,
  'Tucker DeVries': 79, 'Tahaad Pettiford': 79, 'Ja’Kobi Gillespie': 79, 'Jeremy Fears Jr.': 78,
};
function gamePosition(listed: string, height = 198, seed = 0): RosterPlayer['position'] {
  if (['PG', 'SG', 'SF', 'PF', 'C'].includes(listed)) return listed as RosterPlayer['position'];
  if (/Center|^C|\/C|-C/.test(listed)) return 'C';
  if (/Guard|^G/.test(listed)) return height <= 193 ? 'PG' : 'SG';
  return height >= 206 ? 'PF' : height < 195 && seed % 2 === 0 ? 'SG' : 'SF';
}
/** A sourced opening pool. Future college replacements are explicitly fictional. */
export function getRoster(team: string, season = 2026): RosterPlayer[] {
  const canonical = aliases[team] || team;
  const roster = data[canonical];
  if (!roster) return [];
  const elapsed = Math.max(0, Math.floor(season - 2026));
  return roster.players.map((p, i) => {
    const seed = hash(p.name);
    const guards: Record<string, RosterPlayer['position']> = { 'Luka Dončić': 'PG', 'Luka Doncic': 'PG', 'James Harden': 'PG', 'Shai Gilgeous-Alexander': 'PG', 'Cade Cunningham': 'PG', 'LaMelo Ball': 'PG', 'Tyrese Haliburton': 'PG', 'Austin Reaves': 'SG', 'Jayson Tatum': 'SF', 'Jaylen Brown': 'SG' };
    const position = guards[p.name] ?? gamePosition(p.position, p.height, seed);
    const baseYear = /Gr|Sr|Senior|5th|6th/.test(p.classYear || '') ? 4 : /Jr|Junior/.test(p.classYear || '') ? 3 : /So|Sophomore/.test(p.classYear || '') ? 2 : 1;
    const replaced = roster.league === 'NCAA' && baseYear + elapsed > 4;
    if (replaced) return {
      id: `generated-${canonical}-${Math.floor((elapsed + baseYear - 1) / 4)}-${i}`, name: `模拟新生 ${i + 1}`,
      position, listedPosition: position, height: p.height, number: p.number,
      rating: 61 + (seed + elapsed) % 17, generated: true, classYear: `大学第 ${(baseYear + elapsed - 1) % 4 + 1} 年`,
    };
    return { ...p, position, listedPosition: p.position, rating: ratings[p.name] ?? (roster.league === 'NBA' ? 72 + seed % 9 : 61 + seed % 15), generated: false };
  }).sort((a, b) => b.rating - a.rating);
}
export function getRosterSource(team: string) {
  return rosterSources.find(r => r.team === (aliases[team] || team));
}
