import { offensiveWorkload } from './workload';
import { buildNbaAwards, seriesMvp, type AwardCandidate } from './nba-awards';
import { getStoryModifiers } from './story';
import { addBoxScore } from './boxscore';
import { NBA_TEAMS, createCareer, overall, archive, type Career, type Player, type GameResult } from './engine';
export interface NbaStanding { team: string; conference: '东部' | '西部'; wins: number; losses: number; seed: number }
export interface NbaAward { members?: AwardCandidate[]; candidates?: AwardCandidate[]; name: string; winner: string; team: string; detail: string; player: boolean }
export type NbaTactic = 'balanced' | 'scoring' | 'playmaking' | 'defense';
export interface NbaSeriesScore { game: number; home: string; away: string; homeScore: number; awayScore: number; homeWon: boolean }
export interface NbaSeries { id?: string; status?: 'waiting' | 'ready' | 'active' | 'complete'; sources?: string[]; scores?: NbaSeriesScore[]; round: number; conference: string; home: string; away: string; homeWins: number; awayWins: number; winner: string; games: GameResult[] }
export interface NbaState { bracketVersion?: 2; postseasonDay?: number; season: number; stage: 'regular' | 'playin' | 'playoffs' | 'complete'; round: number; standings: NbaStanding[]; series: NbaSeries[]; playoffGames: GameResult[]; awards: NbaAward[]; milestones: string[]; injury?: { name: string; remaining: number }; champion?: string; tradeRequested?: boolean }
const isEast = (team: string) => NBA_TEAMS.slice(2,17).includes(team);
const hash = (s: string) => Array.from(s).reduce((v, x) => (v * 31 + x.charCodeAt(0)) >>> 0, 7);
const chance = (key: string) => (hash(key) % 10000) / 10000;
function pairs(day: number): [string, string][] { const a = [...NBA_TEAMS]; for (let i = 0; i < day % 29; i++) a.splice(1, 0, a.pop()!); return Array.from({ length: 15 }, (_, i) => [a[i], a[29 - i]]); }
function order(rows: NbaStanding[]) { for (const conf of ['东部', '西部']) rows.filter(t => t.conference === conf).sort((a,b) => b.wins-a.wins || a.team.localeCompare(b.team)).forEach((r,i) => { r.seed=i+1; }); return rows; }
export function ensureNba(c: Career): Career {
  if (c.phase !== 'nba' || c.nba?.season === c.season) return c;
  const nba: NbaState = { season: c.season, stage: 'regular', round: 0, standings: NBA_TEAMS.map(team => ({ team, conference: isEast(team) ? '东部' : '西部', wins: 0, losses: 0, seed: 0 })), series: [], playoffGames: [], awards: [], milestones: [] };
  let updated: Career = { ...c, nba, game: 0, wins: 0, losses: 0 };
  for (const g of c.games.filter(g => g.season === c.season)) updated = recordLeagueGame({ ...updated, game: updated.game + 1, wins: updated.wins + Number(g.won), losses: updated.losses + Number(!g.won) }, g);
  return { ...updated, game: c.game, wins: c.wins, losses: c.losses };
}
export function getNbaStandings(c: Career) { return ensureNba(c).nba?.standings ?? []; }
export function nbaOpponent(c: Career) { return pairs(c.game).find(p => p.includes(c.team))?.find(t => t !== c.team) ?? NBA_TEAMS.find(t=>t!==c.team)!; }
export function recordLeagueGame(c: Career, g: GameResult): Career {
  if (!c.nba) return c; const nba = structuredClone(c.nba); const row = nba.standings.find(t=>t.team===c.team); const day = row ? row.wins + row.losses : 0;
  for (const [a,b] of pairs(day)) { const own=a===c.team || b===c.team; const aWins=own ? (a===c.team ? g.won : !g.won) : chance(`${c.season}-${day}-${a}`) < .5 + (hash(a)%30-hash(b)%30)/100; const first=nba.standings.find(t=>t.team===a)!; const second=nba.standings.find(t=>t.team===b)!; first.wins+=Number(aWins); first.losses+=Number(!aWins); second.wins+=Number(!aWins); second.losses+=Number(aWins); }
  order(nba.standings);
  if (nba.injury) { nba.injury.remaining--; if (nba.injury.remaining <= 0) { nba.milestones.push(`第 ${c.game} 场：伤愈回归。`); nba.injury=undefined; } }
  else if (chance(`${c.player.name}-${c.season}-${day}-injury`) < .035) nba.injury={name:'脚踝扭伤',remaining:2+hash(`${day}-${c.season}`)%5};
  if (g.pts>=40) nba.milestones.push(`第 ${c.game} 场对${g.opponent}得到 ${g.pts} 分。`);
  if ([g.pts,g.reb,g.ast,g.stl,g.blk].filter(x=>x>=10).length>=3) nba.milestones.push(`第 ${c.game} 场取得三双。`);
  if (c.game===82) { nba.stage='playin'; nba.awards=buildAwards({...c,nba}); }
  const honors = [...new Set([...c.honors, ...nba.awards.filter(a=>a.player).map(a=>`${c.season} ${a.name}`)])];
  const result = {...c,nba,honors};
  return c.game === 82 ? initializeNbaPostseason(result) : result;
}
const buildAwards = buildNbaAwards;
export function getNbaAwards(c: Career) { return ensureNba(c).nba?.awards ?? []; }
const CONFERENCES = ['东部', '西部'] as const;
const conferenceId = (conference: string) => conference === '东部' ? 'E' : 'W';
const seriesId = (conference: string, round: number, index: number) => round === 4 ? 'F-4-0' : `${conferenceId(conference)}-${round}-${index}`;
export function playoffSeed(n: NbaState, team: string) {
  const entry=n.series.find(row=>row.round===1&&(row.home===team||row.away===team));
  if(entry?.away===team&&entry.sources?.length) return entry.id?.endsWith('-0')?8:7;
  return n.standings.find(t=>t.team===team)?.seed;
}
function pendingSeries(id: string, round: number, conference: string, home = '', away = '', sources: string[] = []): NbaSeries {
  return { id, round, conference, home, away, homeWins: 0, awayWins: 0, winner: '', games: [], scores: [], sources, status: home && away ? 'ready' : 'waiting' };
}
function makeBracket(n: NbaState): NbaSeries[] {
  const series: NbaSeries[] = [];
  for (const conf of CONFERENCES) {
    const teams = n.standings.filter(t => t.conference === conf).sort((a, b) => a.seed - b.seed).map(t => t.team);
    series.push(pendingSeries(seriesId(conf, 0, 0), 0, conf, teams[6], teams[7]));
    series.push(pendingSeries(seriesId(conf, 0, 1), 0, conf, teams[8], teams[9]));
    series.push(pendingSeries(seriesId(conf, 0, 2), 0, conf, '', '', [seriesId(conf, 0, 0), seriesId(conf, 0, 1)]));
    const slots = [[teams[0], ''], [teams[3], teams[4]], [teams[1], ''], [teams[2], teams[5]]];
    slots.forEach(([home, away], i) => series.push(pendingSeries(seriesId(conf, 1, i), 1, conf, home, away, i === 0 ? [seriesId(conf, 0, 2)] : i === 2 ? [seriesId(conf, 0, 0)] : [])));
    for (let i = 0; i < 2; i++) series.push(pendingSeries(seriesId(conf, 2, i), 2, conf, '', '', [seriesId(conf, 1, i * 2), seriesId(conf, 1, i * 2 + 1)]));
    series.push(pendingSeries(seriesId(conf, 3, 0), 3, conf, '', '', [seriesId(conf, 2, 0), seriesId(conf, 2, 1)]));
  }
  series.push(pendingSeries('F-4-0', 4, '总决赛', '', '', [seriesId('东部', 3, 0), seriesId('西部', 3, 0)]));
  return series;
}
function refreshBracket(n: NbaState) {
  for (const s of n.series) {
    if (s.winner) { s.status = 'complete'; continue; }
    const source = (s.sources ?? []).map(id => n.series.find(row => row.id === id));
    if (s.round === 0 && source.length === 2 && source.every(row => row?.winner)) {
      const first = source[0]!;
      s.home = first.winner === first.home ? first.away : first.home;
      s.away = source[1]!.winner;
    } else if (s.round === 1 && source.length === 1 && source[0]?.winner) {
      s.away = source[0].winner;
    } else if (s.round >= 2 && source.length === 2 && source.every(row => row?.winner)) {
      const [a, b] = source.map(row => row!.winner);
      const score = (team: string) => n.standings.find(row => row.team === team)!;
      const aFirst = s.round === 4 ? score(a).wins >= score(b).wins : (playoffSeed(n,a)??15) <= (playoffSeed(n,b)??15);
      s.home = aFirst ? a : b;
      s.away = aFirst ? b : a;
    }
    s.status = !s.home || !s.away ? 'waiting' : s.homeWins + s.awayWins > 0 ? 'active' : 'ready';
  }
  const playinDone = n.series.filter(s => s.round === 0).every(s => !!s.winner);
  const final = n.series.find(s => s.round === 4);
  if (final?.winner) { n.stage = 'complete'; n.round = 4; n.champion = final.winner; }
  else if (!playinDone) { n.stage = 'playin'; n.round = 0; }
  else { n.stage = 'playoffs'; n.round = [1, 2, 3, 4].find(round => n.series.some(s => s.round === round && !s.winner)) ?? 4; }
}
/** Build all 21 bracket slots before simulating a single postseason possession. */
export function initializeNbaPostseason(input: Career): Career {
  const ready = ensureNba(input);
  if (ready.phase !== 'nba' || ready.game !== 82 || !ready.nba || ready.nba.bracketVersion === 2) return ready;
  const c: Career = { ...ready, nba: structuredClone(ready.nba), points: { ...ready.points }, log: [...ready.log], honors: [...ready.honors] }, n = c.nba!;
  const old = n.series;
  n.series = makeBracket(n);
  // Older local saves contain completed rounds. Preserve these results, never replay them.
  for (const conf of [...CONFERENCES, '总决赛']) for (let round = 0; round <= 4; round++) {
    old.filter(s => s.conference === conf && s.round === round).forEach((s, i) => {
      const target = n.series.find(row => row.id === seriesId(conf, round, i));
      if (target) Object.assign(target, s, { id: target.id, sources: target.sources, status: s.winner ? 'complete' : s.status ?? 'ready', scores: s.scores ?? [] });
    });
  }
  n.bracketVersion = 2;
  n.postseasonDay ??= 0;
  refreshBracket(n);
  return c;
}
function activeSeries(n: NbaState): NbaSeries[] {
  return n.series.filter(s => !s.winner && !!s.home && !!s.away && s.round === (n.stage === 'playin' ? 0 : n.round));
}
export interface PendingNbaMatch { seriesId: string; opponent: string; home: boolean; round: number; conference: string; gameNumber: number; homeWins: number; awayWins: number }
export function pendingNbaMatch(c: Career): PendingNbaMatch | undefined {
  const ready = initializeNbaPostseason(c);
  if (ready.phase !== 'nba' || ready.game !== 82 || !ready.nba || ready.nba.stage === 'complete') return undefined;
  const s = activeSeries(ready.nba).find(row => row.home === c.team || row.away === c.team);
  if (!s) return undefined;
  const gameNumber = s.homeWins + s.awayWins + 1;
  const topSeedHosts = s.round === 0 || [1, 2, 5, 7].includes(gameNumber);
  return { seriesId: s.id!, opponent: s.home === c.team ? s.away : s.home, home: (s.home === c.team) === topSeedHosts, round: s.round, conference: s.conference, gameNumber, homeWins: s.homeWins, awayWins: s.awayWins };
}
const bound = (n: number, low: number, high: number) => Math.max(low, Math.min(high, n));
const randomInt = (low: number, high: number) => low + Math.floor(Math.random() * (high - low + 1));
const makes = (attempts: number, accuracy: number) => Array.from({ length: attempts }).reduce<number>(n => n + Number(Math.random() < bound(accuracy, .1, .95)), 0);
function partition(total: number, parts: number): number[] {
  const weights = Array.from({ length: parts }, () => .8 + Math.random() * .4);
  const sum = weights.reduce((a, b) => a + b, 0);
  const result = weights.map(w => Math.floor(total * w / sum));
  for (let i = 0; result.reduce((a, b) => a + b, 0) < total; i++) result[i % parts]++;
  return result;
}
type DetailedGame = GameResult & {
  tactic?: NbaTactic;
  periods?: { label: string; team: number; opponent: number }[];
  playByPlay?: { period: string; clock: string; teamScore: number; opponentScore: number; text: string }[];
};
function addMatchNarrative(g: DetailedGame, overtime: boolean) {
  const regulation = overtime ? Math.min(g.teamScore, g.opponentScore) - randomInt(7, 13) : 0;
  const team = partition(overtime ? regulation : g.teamScore, 4);
  const opponent = partition(overtime ? regulation : g.opponentScore, 4);
  g.periods = team.map((score, i) => ({ label: `第 ${i + 1} 节`, team: score, opponent: opponent[i] }));
  if (overtime) g.periods.push({ label: '加时赛', team: g.teamScore - regulation, opponent: g.opponentScore - regulation });
  const attacks = g.tactic === 'scoring' ? ['拉开空间，单打突破得分。', '高位挡拆后攻击篮筐。', '外线接球出手，命中三分。'] : g.tactic === 'playmaking' ? ['连续传导找到底角空位。', '高位策应，助攻队友空切。', '挡拆分球，队友顺下完成终结。'] : g.tactic === 'defense' ? ['抢下后场篮板，快速推进得分。', '逼迫失误，反击完成终结。', '保护篮筐后稳步组织进攻。'] : ['内外传导，找到空位得分。', '攻守转换中快速终结。', '执行挡拆，命中中距离。'];
  let us = 0, them = 0;
  g.playByPlay = [];
  for (const p of g.periods) {
    const own = partition(p.team, 4), other = partition(p.opponent, 4);
    for (let i = 0; i < 4; i++) {
      us += own[i]; them += other[i];
      g.playByPlay.push({ period: p.label, clock: p.label === '加时赛' ? ['3:45', '2:30', '1:15', '0:00'][i] : ['9:00', '6:00', '3:00', '0:00'][i], teamScore: us, opponentScore: them, text: i === 3 ? `${p.label}结束：本节 ${p.team}–${p.opponent}。` : `球队${attacks[(i + g.playByPlay.length) % attacks.length]}${own[i] >= other[i] ? '这一阶段占据主动。' : '对手及时回应，继续保持防守。'}` });
    }
  }
  g.playByPlay.push({ period: '终场', clock: '0:00', teamScore: g.teamScore, opponentScore: g.opponentScore, text: g.min === 0 ? '因伤缺席，队友完成本场比赛。' : `${g.won ? '拿下胜利' : '遗憾失利'}：出场 ${g.min} 分钟，${g.pts} 分 ${g.reb} 篮板 ${g.ast} 助攻。` });
}
/** Simulate exactly one game in one series. NPC scores are retained independently of the player's box scores. */
function playSeriesGame(c: Career, s: NbaSeries, tactic: NbaTactic) {
  const n = c.nba!, index = s.homeWins + s.awayWins;
  const topHosts = s.round === 0 || [0, 1, 4, 6].includes(index);
  const home = topHosts ? s.home : s.away, away = topHosts ? s.away : s.home;
  const owns = s.home === c.team || s.away === c.team;
  const played = owns && !n.injury;
  const r = c.player.ratings, narrative = getStoryModifiers(c);
  const work=offensiveWorkload(c,tactic),fitness=work.fitness*(1+narrative.stamina);
  const min=played?work.min:0,usage=min/34;
  const tpa=played?work.tpa:0,twoAttempts=played?work.twoAttempts:0;
  const tpm=makes(tpa,(.12+r.three/310)*fitness*(1+narrative.scoring));
  const twom=makes(twoAttempts,(.25+(r.mid+r.layup)/560)*fitness*(1+narrative.scoring));
  const fta=played?work.fta:0,ftm=makes(fta,.3+r.freeThrow/150);
  const pts = 2 * twom + 3 * tpm + ftm;
  const reb = played ? Math.max(0, Math.round(((r.oreb + r.dreb) / 20 + (c.player.height - 198) / 7 + randomInt(-3, 4)) * usage)) : 0;
  const ast = played ? Math.max(0, Math.round((r.pass / 14 + randomInt(-3, 3) + (tactic === 'playmaking' ? 3 : tactic === 'scoring' ? -1 : 0) + narrative.playmaking*25) * usage)) : 0;
  const stl = played ? makes(tactic === 'defense' ? 6 : 4, r.steal / 180*(1+narrative.defense)) : 0;
  const blk = played ? makes(tactic === 'defense' ? 6 : 3, r.block / 190*(1+narrative.defense)) : 0;
  const to = played ? randomInt(0, tactic === 'scoring' || tactic === 'playmaking' ? 5 : 3) : 0;
  const row = (team: string) => n.standings.find(t => t.team === team)!;
  const power = (row(home).wins - row(away).wins) / 4;
  const contribution = played ? (overall(c.player) - 65) / 4 + (pts - 16) / 4 + (ast - 4) / 2 + (tactic === 'defense' ? (stl + blk) * .7 : 0) - to / 3 : owns ? -5 : 0;
  let margin = Math.round(randomInt(-19, 19) + power + 2.5 + (home === c.team ? contribution : away === c.team ? -contribution : 0));
  if (!margin) margin = Math.random() < .5 ? -1 : 1;
  const awayScore = Math.round(randomInt(94, 119)*work.pace), homeScore = Math.max(pts + 35, awayScore + margin);
  const homeWon = homeScore > awayScore;
  (s.scores ??= []).push({ game: index + 1, home, away, homeScore, awayScore, homeWon });
  if ((home === s.home) === homeWon) s.homeWins++; else s.awayWins++;
  if (s.homeWins === (s.round === 0 ? 1 : 4)) s.winner = s.home;
  if (s.awayWins === (s.round === 0 ? 1 : 4)) s.winner = s.away;
  s.status = s.winner ? 'complete' : 'active';
  if (!owns) return;
  const g: DetailedGame = { id: `${c.season}-post-${s.id}-${index + 1}`, season: c.season, team: c.team, phase: 'nba', stage: s.round === 0 ? 'playin' : 'playoffs', started: played && (c.role ?? 2) >= 2, opponent: home === c.team ? away : home, home: home === c.team, won: home === c.team ? homeWon : !homeWon, teamScore: home === c.team ? homeScore : awayScore, opponentScore: home === c.team ? awayScore : homeScore, pts, reb, ast, stl, blk, min, fgm: twom + tpm, fga: twoAttempts + tpa, tpm, tpa, ftm, fta, to, tactic };
  g.shots = createShotChart(g);
  addMatchNarrative(g, Math.abs(margin) <= 6 && Math.random() < .22);
  g.boxScore = addBoxScore(g, c).boxScore;
  s.games.push(g);
  n.playoffGames.push(g);
  if (n.injury) { n.injury.remaining--; if (!n.injury.remaining) { n.injury = undefined; n.milestones.push('季后赛伤愈回归，可以重新出场。'); } }
  else if (Math.random() < .018) n.injury = { name: '肌肉拉伤', remaining: randomInt(1, 3) };
  c.energy = bound(c.energy + (played ? -(tactic === 'scoring' || tactic === 'defense' ? 10 : 7) : 8), 15, 100);
  c.confidence = bound((c.confidence ?? 75) + (g.won ? 2 : -2), 0, 100);
  if (played) for (const key of Object.keys(c.points) as (keyof Career['points'])[]) c.points[key] += 2;
  c.log.unshift(`${s.round === 0 ? '附加赛' : `季后赛第 ${s.round} 轮 G${index + 1}`}：${c.team} ${g.teamScore}–${g.opponentScore} ${g.opponent}，${g.won ? '获胜' : '失利'}${s.round > 0 ? `，系列赛 ${s.homeWins}–${s.awayWins}` : ''}。`);
}
function finishPostseason(c: Career) {
  const n = c.nba!, final = n.series.find(s => s.round === 4)!;
  if (!n.awards.some(a => a.name === '总冠军')) n.awards.push({ name: '总冠军', winner: final.winner, team: final.winner, player: final.winner === c.team, detail: '四轮七场四胜系列赛冠军' }, seriesMvp(c, final, '总决赛 MVP'));
  if (!n.milestones.includes(`${c.season} 总冠军：${final.winner}`)) n.milestones.push(`${c.season} 总冠军：${final.winner}`);
  c.log.unshift(`总决赛结束：${final.winner}以 ${Math.max(final.homeWins, final.awayWins)}–${Math.min(final.homeWins, final.awayWins)}夺冠。休赛期开启。`);
}
/** Advance one match day. Each active series plays once; the user can play at most one game. */
export function playNbaPostseasonGame(input: Career, tactic: NbaTactic = 'balanced'): Career {
  const ready = initializeNbaPostseason(input);
  if (ready.phase !== 'nba' || ready.game !== 82 || !ready.nba || ready.nba.stage === 'complete') return input;
  const c = {...ready,nba:structuredClone(ready.nba),points:{...ready.points},log:[...ready.log],honors:[...ready.honors]}, n = c.nba!;
  const today = activeSeries(n);
  if (!today.length) return ready;
  for (const s of today) playSeriesGame(c, s, ['balanced', 'scoring', 'playmaking', 'defense'].includes(tactic) ? tactic : 'balanced');
  n.postseasonDay = (n.postseasonDay ?? 0) + 1;
  refreshBracket(n);
  for (const s of n.series.filter(s => s.round === 3 && s.winner)) {
    const name = s.conference + '决赛 MVP';
    if (!n.awards.some(a => a.name === name)) n.awards.push(seriesMvp(c, s, name));
  }
  if (n.stage === 'complete') finishPostseason(c);
  else if (!today.some(s => s.home === c.team || s.away === c.team)) c.log.unshift(`季后赛第 ${n.postseasonDay} 个比赛日结束，联盟对阵已更新。`);
  c.honors = [...new Set([...c.honors, ...n.awards.filter(a => a.player).map(a => `${c.season} ${a.name}`)])];
  c.log = c.log.slice(0, 100);
  return archive(c);
}
export const advanceNbaPostseason = playNbaPostseasonGame;
export function requestTrade(c: Career,team: string): Career { if(c.phase!=='nba'||c.game>45||!NBA_TEAMS.includes(team)||team===c.team)return c;const ready=ensureNba(c);if(ready.nba!.tradeRequested)return c;const row=ready.nba!.standings.find(t=>t.team===team)!;return {...ready,team,wins:row.wins,losses:row.losses,nba:{...ready.nba!,tradeRequested:true,milestones:[...ready.nba!.milestones,`交易至${team}`]},log:[`交易申请获批：加盟${team}，保留现有合同。`,...c.log]}; }
export function retireCareer(c: Career): Career { return c.phase==='retired'?c:{...c,phase:'retired',log:[`${c.age} 岁宣布退役。全部比赛与荣誉保留在生涯档案。`,...c.log]}; }
export function createNbaCareer(player: Player,team=NBA_TEAMS[0]): Career { return ensureNba({...createCareer(player,''),ncaa:undefined,phase:'nba',age:19,team:NBA_TEAMS.includes(team)?team:NBA_TEAMS[0],contract:{years:3,salary:4200000},log:['以职业新秀身份开启本地 NBA 生涯。所有功能免费开放。']}); }

export function extendContract(c: Career): Career { if(c.phase!=='nba'||c.contract.years!==1)return c;return {...c,contract:{years:3,salary:Math.max(300,(overall(c.player)-40)*80)*10000},log:[`与${c.team}提前续约 3 年。`,...c.log]}; }
/** Local simulation shot locations; basket at (50,12), full width/half court 0–100. */
export function createShotChart(g: GameResult): NonNullable<GameResult['shots']> { const shots:NonNullable<GameResult['shots']>=[]; for(let i=0;i<g.fga;i++){const three=i<g.tpa;const angle=(Math.random()-.5)*Math.PI; const radius=three?64+Math.random()*10:7+Math.random()*45; const x=Math.max(3,Math.min(97,50+Math.sin(angle)*radius*.7));const y=Math.max(4,Math.min(95,12+Math.cos(angle)*radius));const made=three?i<g.tpm:i-g.tpa<g.fgm-g.tpm;shots.push({x,y,made,three});}return shots; }
