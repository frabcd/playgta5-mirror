import { offensiveWorkload } from './workload';
import { validAiReport, type AiReport, type AiPlan } from './deepseek';
import { getRoster } from './rosters';
import { getStoryModifiers, validateStory, type StoryState } from './story';
import type { OffseasonRecord } from './offseason';
import { addBoxScore, validBoxScore, type MatchBoxScore } from './boxscore';
import { collegeOpponent, ensureNcaa, type NcaaState } from './ncaa';
import { ensureNba, recordLeagueGame, nbaOpponent, createShotChart, type NbaState } from './nba';
/** Original offline approximation; no connection to the source site's private simulation. */
export const RATING_LABELS = { mid: '中投', three: '三分', drive: '突破', layup: '上篮', handle: '控球', pass: '传球', interior: '内线防守', perimeter: '外线防守', steal: '抢断', block: '盖帽', oreb: '进攻篮板', dreb: '防守篮板', speed: '速度', strength: '力量', jump: '弹跳', freeThrow: '罚球' } as const;
export type RatingKey = keyof typeof RATING_LABELS;
export const GROUP_LABELS = { shooting: '投篮', finishing: '终结', playmaking: '组织', defense: '防守', rebounding: '篮板', physical: '身体', freeThrow: '罚球' } as const;
export type TrainingGroup = keyof typeof GROUP_LABELS;
export const RATING_GROUP: Record<RatingKey, TrainingGroup> = { mid: 'shooting', three: 'shooting', drive: 'finishing', layup: 'finishing', handle: 'playmaking', pass: 'playmaking', interior: 'defense', perimeter: 'defense', steal: 'defense', block: 'defense', oreb: 'rebounding', dreb: 'rebounding', speed: 'physical', strength: 'physical', jump: 'physical', freeThrow: 'freeThrow' };
export const COLLEGES = ['佛罗里达大学', '伊利诺伊大学', '维拉诺瓦大学', '杜克大学', '印第安纳大学', '休斯敦大学', '阿肯色大学', '威斯康星大学'];
export const NBA_TEAMS = ['洛杉矶湖人', '金州勇士', '波士顿凯尔特人', '芝加哥公牛', '迈阿密热火', '纽约尼克斯', '布鲁克林篮网', '费城76人', '密尔沃基雄鹿', '克利夫兰骑士', '底特律活塞', '印第安纳步行者', '奥兰多魔术', '亚特兰大老鹰', '夏洛特黄蜂', '华盛顿奇才', '多伦多猛龙', '洛杉矶快船', '萨克拉门托国王', '菲尼克斯太阳', '丹佛掘金', '明尼苏达森林狼', '俄克拉荷马雷霆', '波特兰开拓者', '犹他爵士', '达拉斯独行侠', '休斯顿火箭', '圣安东尼奥马刺', '孟菲斯灰熊', '新奥尔良鹈鹕'];
export interface PlayerInput { name: string; potential: number; height: number; weight: number; wingspan: number; number: string; position: 'PG' | 'SG' | 'SF' | 'PF' | 'C'; description: string }
export interface Player extends PlayerInput { ratings: Record<RatingKey, number>; caps: Record<RatingKey, number>; archetype: string }
export type GamePlan = 'balanced' | 'scoring' | 'playmaking' | 'defense';
export interface GameResult { boxScore?: MatchBoxScore; tactic?: GamePlan; periods?: {label:string;team:number;opponent:number}[]; playByPlay?: {period:string;clock:string;teamScore:number;opponentScore:number;text:string}[]; shots?: {x:number;y:number;made:boolean;three:boolean}[]; team?: string; to?: number; phase?: 'college' | 'nba'; stage?: 'regular' | 'playin' | 'playoffs' | 'conference' | 'national'; started?: boolean; id: string; season: number; opponent: string; home: boolean; won: boolean; teamScore: number; opponentScore: number; pts: number; reb: number; ast: number; stl: number; blk: number; min: number; fgm: number; fga: number; tpm: number; tpa: number; ftm: number; fta: number }
export interface SeasonRecord { season: number; age: number; phase: 'college' | 'nba'; team: string; games: number; wins: number; losses: number; pts: number; reb: number; ast: number; stl: number; blk: number; fgPct: number; threePct: number; ftPct: number }
export type ChallengeRoute = 'scoring' | 'playmaking' | 'inside';
export interface Career { aiReports?: AiReport[]; aiJudged?: string[]; simulationPlan?: AiPlan; story?: StoryState; offseasons?: OffseasonRecord[]; ncaa?: NcaaState; ncaaHistory?: NcaaState[]; nba?: NbaState; nbaHistory?: NbaState[]; player: Player; phase: 'college' | 'nba' | 'retired'; season: number; age: number; team: string; game: number; wins: number; losses: number; energy: number; points: Record<TrainingGroup, number>; games: GameResult[]; history: SeasonRecord[]; honors: string[]; log: string[]; contract: { years: number; salary: number }; confidence?: number; trust?: number; role?: number; eventStep?: number; eventOutcome?: string; challenge?: string; challengeGoal?: { route: ChallengeRoute; start: number; target: number }; challengeCooldown?: number }
export const ROLE_LABELS: Record<number, string> = { 1: '轮换球员', 2: '稳定首发', 3: '球队明星', 4: '球队核心' };
export const SEASON_LENGTH = { college: 30, nba: 82, retired: 0 };
const keys = Object.keys(RATING_LABELS) as RatingKey[];
const groups = Object.keys(GROUP_LABELS) as TrainingGroup[];
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, Number.isFinite(v) ? v : lo));
const rand = (lo: number, hi: number) => Math.floor(Math.random() * (hi - lo + 1)) + lo;
const round = (v: number) => Math.round(v * 10) / 10;
const note = (c: Career, message: string): Career => ({ ...c, log: [message, ...c.log].slice(0, 100) });
export const overall = (p: Player) => {
  const specialties: Record<PlayerInput['position'], RatingKey[]> = { PG: ['handle', 'pass', 'speed', 'perimeter'], SG: ['three', 'mid', 'drive', 'perimeter'], SF: ['mid', 'three', 'drive', 'perimeter'], PF: ['layup', 'interior', 'dreb', 'strength'], C: ['layup', 'interior', 'block', 'dreb'] };
  return Math.round(keys.reduce((s, k) => s + p.ratings[k] * (specialties[p.position].includes(k) ? 2 : 1), 0) / 20);
};
export function generatePlayer(input: PlayerInput): Player {
  const height = Math.round(clamp(input.height, 160, 240));
  const position = ['PG', 'SG', 'SF', 'PF', 'C'].includes(input.position) ? input.position : 'SF';
  const guard = position === 'PG' || position === 'SG';
  const big = position === 'C' || position === 'PF';
  const p: Player = { ...input, name: input.name.trim().slice(0, 24) || '新秀球员', position, height, weight: Math.round(clamp(input.weight, 50, 200)), wingspan: Math.round(clamp(input.wingspan, height - 12, height + 26)), potential: Math.round(clamp(input.potential, 80, 100)), number: input.number.replace(/\D/g, '').slice(0, 2) || '0', description: input.description.slice(0, 1500), ratings: {} as Player['ratings'], caps: {} as Player['caps'], archetype: guard ? '外线组织者' : big ? '内线守护者' : '全能侧翼' };
  const words: Record<RatingKey, string[]> = { mid: ['中投', '中距离'], three: ['三分', '远投'], drive: ['突破'], layup: ['上篮', '终结'], handle: ['控球', '运球'], pass: ['传球', '组织'], interior: ['内防', '内线防守'], perimeter: ['外防', '外线防守'], steal: ['抢断'], block: ['盖帽', '封盖'], oreb: ['前场篮板', '进攻篮板'], dreb: ['后场篮板', '防守篮板', '篮板'], speed: ['速度', '快速'], strength: ['力量', '强壮', '对抗'], jump: ['弹跳', '扣篮'], freeThrow: ['罚球'] };
  for (const key of keys) {
    let rating = 53 + rand(-5, 5);
    if (guard && ['three', 'handle', 'pass', 'speed', 'perimeter'].includes(key)) rating += 10;
    if (big && ['interior', 'block', 'oreb', 'dreb', 'strength', 'layup'].includes(key)) rating += 10;
    if (['block', 'dreb', 'interior'].includes(key)) rating += Math.round((height - 198) / 5);
    if (key === 'strength') rating += Math.round((p.weight - 90) / 8);
    if (key === 'speed') rating -= Math.round((height - 198) / 6);
    let cap = 75;
    for (const word of words[key]) {
      if (!p.description.includes(word)) continue;
      const clause = p.description.split(/[，。；、,;\n]/).find(s => s.includes(word)) || '';
      if (/不会|不能|无法/.test(clause)) { rating = 35; cap = 50; }
      else if (/弱|差|不擅长|短板|较慢/.test(clause)) { rating -= 13; cap = 70; }
      else { rating += 15; cap = 98; }
      break;
    }
    p.caps[key] = cap;
    p.ratings[key] = Math.round(clamp(rating, 25, cap));
  }
  while (overall(p) > 70) for (const k of keys) p.ratings[k] = Math.max(25, p.ratings[k] - 1);
  if (p.ratings.three >= 70) p.archetype = '外线神射手';
  else if (p.ratings.pass >= 70) p.archetype = '球场指挥官';
  else if (p.ratings.block >= 70) p.archetype = '禁区守护者';
  return p;
}
export function createCareer(player: Player, team: string): Career {
  return { player: structuredClone(player), phase: 'college', season: 2026, age: 18, team: COLLEGES.includes(team) ? team : COLLEGES[0], game: 0, wins: 0, losses: 0, energy: 90, confidence: 75, trust: 50, role: 2, eventStep: 0, points: Object.fromEntries(groups.map(g => [g, 0])) as Career['points'], games: [], history: [], honors: [], log: ['欢迎来到大学联赛，你的篮球生涯从这里开始。'], contract: { years: 0, salary: 0 } };
}
/** Original local story outcomes, deterministically selected from season/player/event state. */
export function seasonEvent(c: Career): Career {
  if (c.phase === 'retired' || (c.eventStep ?? 0) >= 4 || c.game >= SEASON_LENGTH[c.phase]) return c;
  const step = c.eventStep ?? 0;
  const seed = c.season + step * 17 + Array.from(c.player.name).reduce((n, s) => n + s.charCodeAt(0), 0);
  const outcomes = [
    { text: '加练得到了教练认可：信任 +5，体力 -5。', energy: -5, confidence: 0, trust: 5, rating: 'mid' as RatingKey },
    { text: '队友邀请你一起恢复：体力 +8，自信 +3。', energy: 8, confidence: 3, trust: 0 },
    { text: '训练赛表现抢眼：自信 +6，信任 +3。', energy: -4, confidence: 6, trust: 3 },
    { text: '连续训练略显疲惫：体力 -8，自信 -2；教练鼓励你调整。', energy: -8, confidence: -2, trust: 0 },
    { text: '力量课顺利完成：力量 +1，体力 -6。', energy: -6, confidence: 2, trust: 1, rating: 'strength' as RatingKey },
    { text: '战术交流让配合更默契：传球 +1，信任 +4。', energy: 0, confidence: 0, trust: 4, rating: 'pass' as RatingKey },
  ];
  const outcome = outcomes[seed % outcomes.length];
  const player = outcome.rating ? { ...c.player, ratings: { ...c.player.ratings, [outcome.rating]: Math.min(c.player.caps[outcome.rating], c.player.ratings[outcome.rating] + 1) } } : c.player;
  return note({ ...c, player, eventStep: step + 1, eventOutcome: outcome.text, energy: clamp(c.energy + outcome.energy, 0, 100), confidence: clamp((c.confidence ?? 75) + outcome.confidence, 0, 100), trust: clamp((c.trust ?? 50) + outcome.trust, 0, 100) }, outcome.text);
}
export function challengeCareer(c: Career, route: ChallengeRoute): Career {
  if (c.phase === 'retired' || c.challengeGoal || (c.role ?? 2) >= 4 || c.games.length < (c.challengeCooldown ?? 0) || SEASON_LENGTH[c.phase] - c.game < 5 || !['scoring', 'playmaking', 'inside'].includes(route)) return c;
  const target = route === 'scoring' ? 18 : route === 'playmaking' ? 6 : 9;
  const metric = route === 'scoring' ? '得分' : route === 'playmaking' ? '助攻' : '篮板';
  const challenge = `接下来 5 场场均${metric}达到 ${target}，争取${ROLE_LABELS[Math.min(4, (c.role ?? 2) + 1)]}。`;
  return note({ ...c, challenge, challengeGoal: { route, start: c.games.length, target } }, challenge);
}
/** Three schedule segments, with the remainder included in the final segment. */
export function simulateMonth(c: Career): Career {
  if (c.phase === 'retired') return c;
  const length = SEASON_LENGTH[c.phase];
  const boundary = [Math.floor(length / 3), Math.floor(length * 2 / 3), length].find(n => n > c.game);
  return boundary ? simulateGames(c, boundary - c.game) : c;
}
export function allSeasonGames(c: Career, season = c.season): GameResult[] {
  const college = c.ncaa?.season === season ? c.ncaa : c.ncaaHistory?.find(n => n.season === season);
  const nba = c.nba?.season === season ? c.nba : c.nbaHistory?.find(n => n.season === season);
  return [...c.games.filter(g => g.season === season), ...(college?.postseasonGames ?? []), ...(nba?.playoffGames ?? [])];
}
export function archive(c: Career): Career {
  if (!c.game || c.phase === 'retired') return c;
  const sum = (k: keyof GameResult) => allSeasonGames(c).reduce((n, g) => n + Number(g[k]), 0);
  const appearances = allSeasonGames(c).filter(g => g.min > 0).length;
  const record: SeasonRecord = { season: c.season, age: c.age, phase: c.phase, team: c.team, games: appearances, wins: allSeasonGames(c).filter(g => g.won).length, losses: allSeasonGames(c).filter(g => !g.won).length, pts: round(sum('pts') / Math.max(1, appearances)), reb: round(sum('reb') / Math.max(1, appearances)), ast: round(sum('ast') / Math.max(1, appearances)), stl: round(sum('stl') / Math.max(1, appearances)), blk: round(sum('blk') / Math.max(1, appearances)), fgPct: round(100 * sum('fgm') / Math.max(1, sum('fga'))), threePct: round(100 * sum('tpm') / Math.max(1, sum('tpa'))), ftPct: round(100 * sum('ftm') / Math.max(1, sum('fta'))) };
  const honors = [...c.honors];
  if (c.game === SEASON_LENGTH[c.phase] && !c.history.some(s => s.season === c.season)) {
    if (record.pts >= 20) honors.push(`${c.season} 年度最佳阵容`);
    if (c.wins >= Math.ceil(c.game * 0.75)) honors.push(`${c.season} 常规赛优秀战绩`);
    if (record.reb >= 10) honors.push(`${c.season} 篮板精英`);
  }
  return { ...c, history: [...c.history.filter(s => s.season !== c.season), record], honors: [...new Set(honors)] };
}
/** A stable fixture preview: viewing the schedule never rerolls the next opponent. */
export function nextRegularMatch(c: Career): {opponent:string;home:boolean} {
  return {opponent: c.phase === 'nba' ? nbaOpponent(c) : collegeOpponent(c), home:c.game % 2 === 0};
}
/** Period totals and a chronological score ledger reconcile exactly with the final score. */
export function addMatchTimeline(g: GameResult): GameResult {
  const count = g.phase === 'college' ? 2 : 4;
  const split = (total:number) => {
    let remaining=total;
    return Array.from({length:count},(_,i)=>{const points=i===count-1?remaining:Math.max(0,Math.round(remaining/(count-i)+rand(-4,4)));remaining-=points;return points;});
  };
  const own=split(g.teamScore),other=split(g.opponentScore);
  const periods=own.map((team,i)=>({label:count===2?(i===0?'上半场':'下半场'):`第${i+1}节`,team,opponent:other[i]}));
  const playByPlay:NonNullable<GameResult['playByPlay']>=[];
  let teamScore=0,opponentScore=0;
  for(const period of periods){
    let a=period.team,b=period.opponent;
    const possessions:{own:boolean;points:number}[]=[];
    while(a>0||b>0){const isOwn=b===0||(a>0&&Math.random()<.5);const remaining=isOwn?a:b;const points=Math.min(remaining,Math.random()<.25?3:2);possessions.push({own:isOwn,points});if(isOwn)a-=points;else b-=points;}
    possessions.forEach((event,i)=>{teamScore+=event.own?event.points:0;opponentScore+=event.own?0:event.points;const seconds=Math.round((count===2?1200:720)*(1-(i+1)/possessions.length));playByPlay.push({period:period.label,clock:`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`,teamScore,opponentScore,text:`${event.own?g.team??'本队':g.opponent}${event.points===3?'外线三分命中':event.points===2?'进攻终结得分':'罚球命中'}（+${event.points}）`});});
  }
  return {...g,periods,playByPlay};
}
/** Independent local box-score simulation; chosen game plan affects actual usage and defense. */
export function simulateMatch(c: Career, opponent:string, home:boolean, tactic:GamePlan='balanced',stage:GameResult['stage']='regular',id=`${c.season}-${c.game+1}`): GameResult {
  const r=c.player.ratings, narrative=getStoryModifiers(c), work=offensiveWorkload(c,tactic), fitness=work.fitness*(1+narrative.stamina);
  const active=!(c.phase==='nba'&&c.nba?.injury);
  const tpa=active?work.tpa:0;
  const twoAttempts=active?work.twoAttempts:0;
  const makes=(n:number,p:number)=>Array.from({length:n}).reduce<number>(sum=>sum+(Math.random()<p?1:0),0);
  const tpm=makes(tpa,(.1+r.three/300)*fitness*(1+narrative.scoring)),twom=makes(twoAttempts,(.22+(r.mid+r.layup)/520)*fitness*(1+narrative.scoring));
  const fta=active?work.fta:0,ftm=makes(fta,.3+r.freeThrow/160),pts=twom*2+tpm*3+ftm;
  const strength=(team:string)=>{const roster=getRoster(team,c.season).slice(0,8);return roster.length?roster.reduce((sum,p)=>sum+p.rating,0)/roster.length:70;};
  const matchup=Math.max(-6,Math.min(6,(strength(c.team)-strength(opponent))/3));
  const opponentScore=Math.round(rand(c.phase==='college'?58:90,c.phase==='college'?90:125)*work.pace)-(tactic==='defense'?4:0)-Math.round(narrative.defense*40);
  const margin=rand(-20,20)+Math.round((overall(c.player)-58)/2)+Math.round((pts-14)/3)+(home?2:0)+Math.round(narrative.playmaking*30+matchup);
  const teamScore=Math.max(pts,opponentScore+(margin===0?1:margin));
  const g:GameResult={id,season:c.season,team:c.team,phase:c.phase==='college'?'college':'nba',stage,tactic,opponent,home,teamScore,opponentScore,won:teamScore>opponentScore,started:active&&(c.role??2)>=2,min:active?work.min:0,pts,reb:active?Math.max(0,Math.round((r.oreb+r.dreb)/18+(c.player.height-198)/8+rand(-4,4))):0,ast:active?Math.max(0,Math.round(r.pass/14+(c.player.position==='PG'?2:-1)+rand(-3,3)+(tactic==='playmaking'?3:0)+narrative.playmaking*25)):0,stl:active?rand(0,Math.max(1,Math.floor(r.steal/20)))+(tactic==='defense'?1:0):0,blk:active?rand(0,Math.max(1,Math.floor(r.block/22))):0,to:active?rand(0,tactic==='scoring'||tactic==='playmaking'?5:4):0,fgm:twom+tpm,fga:twoAttempts+tpa,tpm,tpa,ftm,fta};
  g.shots=createShotChart(g);
  return addBoxScore(addMatchTimeline(g), c);
}
export function simulateGames(career: Career, count: number, tactic: GamePlan = 'balanced'): Career {
  if (career.phase === 'retired' || !Number.isFinite(count)) return career;
  let c = { ...ensureNcaa(ensureNba(career)), points: { ...career.points } };
  const n = Math.max(0, Math.min(Math.floor(count), SEASON_LENGTH[c.phase] - c.game));
  for (let i = 0; i < n; i++) {
    const next = nextRegularMatch(c);
    c = {...c,energy:Math.min(100,c.energy+10)};
    const g = simulateMatch(c, next.opponent, next.home, tactic);
    c = { ...c, game: c.game + 1, wins: c.wins + Number(g.won), losses: c.losses + Number(!g.won), energy: Math.max(20, c.energy - 10), games: [...c.games, g] };
    if (c.phase === 'nba') c = recordLeagueGame(c, g);
    for (const group of groups) c.points[group] += 2;
    c.confidence = clamp((c.confidence ?? 75) + (g.won ? 1 : -1), 0, 100);
    if (c.challengeGoal && c.games.length >= c.challengeGoal.start + 5) {
      const goal = c.challengeGoal;
      const metric = goal.route === 'scoring' ? 'pts' : goal.route === 'playmaking' ? 'ast' : 'reb';
      const average = c.games.slice(goal.start, goal.start + 5).reduce((sum, game) => sum + game[metric], 0) / 5;
      const passed = average >= goal.target;
      c = note({ ...c, role: passed ? Math.min(4, (c.role ?? 2) + 1) : (c.role ?? 2), trust: clamp((c.trust ?? 50) + (passed ? 10 : -3), 0, 100), challenge: `${passed ? '挑战成功' : '挑战未完成'}：5 场场均${metric === 'pts' ? '得分' : metric === 'ast' ? '助攻' : '篮板'} ${round(average)}（目标 ${goal.target}）。`, challengeGoal: undefined, challengeCooldown: c.games.length + 5 }, passed ? '球队地位挑战成功，教练给了你更重要的角色。' : '球队地位挑战未完成，再打 5 场后可以重试。');
    }
  }
  if (!n) return career;
  c = note(c, `完成 ${n} 场比赛，赛季战绩 ${c.wins} 胜 ${c.losses} 负。获得各项训练点 ${n * 2}。`);
  return c.game === SEASON_LENGTH[c.phase] ? note(ensureNcaa(archive(c)), c.phase === 'nba' ? '常规赛结束，进入附加赛与季后赛。' : '30 场常规赛结束，进入联盟锦标赛；赛季尚未结束。') : c;
}
export function train(c: Career, group: TrainingGroup, grade: 'C' | 'B' | 'A' | 'S'): Career {
  if (c.phase === 'retired' || c.energy < 15 || !groups.includes(group)) return c;
  const reward = { C: 8, B: 12, A: 18, S: 25 }[grade];
  if (!reward) return c;
  return note({ ...c, energy: c.energy - 15, points: { ...c.points, [group]: c.points[group] + reward } }, `${GROUP_LABELS[group]}训练 ${grade} 级，获得 ${reward} 训练点。`);
}
export function rest(c: Career): Career { return c.phase === 'retired' ? c : note({ ...c, energy: Math.min(100, c.energy + 35) }, '恢复训练结束，体力恢复 35 点（上限 100）。'); }
export function upgradeCost(p: Player, key: RatingKey): number { return Math.max(5, Math.round((p.ratings[key] / 4) * (1 + (100 - p.potential) / 30))); }
export function upgrade(c: Career, key: RatingKey): Career {
  if (!keys.includes(key) || c.phase === 'retired') return c;
  const group = RATING_GROUP[key], cost = upgradeCost(c.player, key);
  if (c.player.ratings[key] >= c.player.caps[key] || c.points[group] < cost) return c;
  return note({ ...c, player: { ...c.player, ratings: { ...c.player.ratings, [key]: c.player.ratings[key] + 1 } }, points: { ...c.points, [group]: c.points[group] - cost } }, `${RATING_LABELS[key]}提升至 ${c.player.ratings[key] + 1}，消耗 ${cost} 点。`);
}
function advance(c: Career): Career {
  const age = c.age + 1;
  const ratings = { ...c.player.ratings };
  for (const key of keys) {
    let change = 0;
    if (age <= 25) change = rand(0, c.player.potential >= 90 ? 3 : 2);
    else if (age <= 29) change = rand(0, 1);
    else if (age > 30 && ['speed', 'jump'].includes(key)) change = -rand(1, age > 35 ? 3 : 2);
    else if (age > 35) change = -rand(0, 1);
    ratings[key] = clamp(ratings[key] + change, 25, c.player.caps[key]);
  }
  return note({ ...c, player: { ...c.player, ratings }, season: c.season + 1, age, game: 0, wins: 0, losses: 0, energy: 90, eventStep: 0, eventOutcome: undefined, challengeGoal: undefined, contract: { ...c.contract, years: Math.max(0, c.contract.years - 1) } }, age <= 29 ? '休赛期自然成长已结算，能力提升受个人上限限制。' : '休赛期身体状态已更新，年龄会逐渐影响运动能力。');
}
export function enterDraft(c: Career): Career {
  if (c.phase !== 'college' || c.game !== SEASON_LENGTH.college || ensureNcaa(c).ncaa?.stage !== 'complete') return c;
  const archived = archive(c);
  const pick = Math.round(clamp(65 - overall(c.player) / 1.3 - (c.player.potential - 80) / 2, 1, 60));
  const team = NBA_TEAMS[(pick - 1) % NBA_TEAMS.length];
  return note({ ...advance(archived), phase: 'nba', team, ncaaHistory: [...(c.ncaaHistory ?? []), c.ncaa!], ncaa: undefined, contract: { years: 3, salary: Math.round(250 + (61 - pick) * 12) * 10000 } }, `选秀大会：第 ${pick} 顺位被${team}选中，签下 3 年新秀合同。`);
}
export function nextSeason(c: Career): Career {
  if (c.phase === 'retired' || c.game !== SEASON_LENGTH[c.phase]) return c;
  if (c.phase === 'nba' && ensureNba(c).nba?.stage !== 'complete') return c;
  if (c.phase === 'college' && ensureNcaa(c).ncaa?.stage !== 'complete') return c;
  const archived = archive(c);
  if (c.phase === 'college' && archived.history.filter(s => s.phase === 'college').length >= 4) return enterDraft(archived);
  if (c.phase === 'nba' && archived.history.filter(s => s.phase === 'nba').length >= 25) return note({ ...archived, phase: 'retired' }, '25 年职业旅程落幕。你的生涯数据已永久记录在本地。');
  const advanced = advance(archived);
  if (c.phase === 'nba') { advanced.nbaHistory = [...(c.nbaHistory ?? []), c.nba!]; advanced.nba = undefined; }
  if (c.phase === 'college') { advanced.ncaaHistory = [...(c.ncaaHistory ?? []), c.ncaa!]; advanced.ncaa = undefined; }
  return note(ensureNcaa(ensureNba(advanced)), `${c.season + 1}-${String(c.season + 2).slice(-2)} 赛季开始，继续追逐篮球梦想。`);
}
export function signTeam(c: Career, team: string): Career {
  if (c.phase !== 'nba' || !NBA_TEAMS.includes(team) || c.contract.years > 0) return c;
  return note({ ...c, team, contract: { years: 3, salary: Math.max(300, (overall(c.player) - 40) * 80) * 10000 } }, `与${team}签订 3 年合同。`);
}
export function validateCareer(value: unknown): value is Career {
  if (!value || typeof value !== 'object') return false;
  const c = value as Career;
  if (c.story !== undefined && !validateStory(c.story)) return false;
  if (c.aiReports !== undefined && (!Array.isArray(c.aiReports) || c.aiReports.length > 60 || !c.aiReports.every(validAiReport))) return false;
  if (c.aiJudged !== undefined && (!Array.isArray(c.aiJudged) || !c.aiJudged.every(v=>typeof v==='string'))) return false;
  if (c.offseasons !== undefined && (!Array.isArray(c.offseasons) || !c.offseasons.every(r=>r && Number.isInteger(r.season) && ['college','nba'].includes(r.phase) && ['shooting','finishing','playmaking','defense','physical','recovery'].includes(r.focus) && ['return','transfer','draft','freeagency'].includes(r.route) && [r.from,r.to,r.summary].every(v=>typeof v==='string') && r.before && r.after && keys.every(k=>[r.before[k],r.after[k]].every(v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=100))))) return false;
  const finite = (n: unknown) => typeof n === 'number' && Number.isFinite(n);
  if (!c.player || !c.player.ratings || !c.player.caps || !['college', 'nba', 'retired'].includes(c.phase)) return false;
  if (![c.season, c.age, c.game, c.wins, c.losses, c.energy, c.player.height, c.player.weight, c.player.wingspan, c.player.potential].every(finite)) return false;
  if (typeof c.player.name !== 'string' || typeof c.player.description !== 'string' || typeof c.player.number !== 'string' || typeof c.player.archetype !== 'string' || !['PG', 'SG', 'SF', 'PF', 'C'].includes(c.player.position)) return false;
  if (c.game < 0 || c.game > 82 || c.wins + c.losses !== c.game || c.energy < 0 || c.energy > 100 || typeof c.team !== 'string') return false;
  if (!keys.every(k => finite(c.player.ratings[k]) && finite(c.player.caps[k]) && c.player.ratings[k] >= 0 && c.player.ratings[k] <= c.player.caps[k] && c.player.caps[k] <= 100)) return false;
  const validAwardCandidates = (value: unknown) => value === undefined || (Array.isArray(value) && value.length <= 100 && value.every(p => p && ['id','name','team'].every(k => typeof p[k] === 'string') && typeof p.player === 'boolean' && ['games','starts','pts','reb','ast','stl','blk','improvement','score'].every(k => finite(p[k]))));
  const validNba = (n: NbaState) => !!n && finite(n.season) && ['regular','playin','playoffs','complete'].includes(n.stage) && Number.isInteger(n.round) && n.round >= 0 && n.round <= 4 && Array.isArray(n.standings) && n.standings.length === 30 && new Set(n.standings.map(t => t?.team)).size === 30 && n.standings.every(t => t && NBA_TEAMS.includes(t.team) && ['东部','西部'].includes(t.conference) && [t.wins,t.losses,t.seed].every(v => Number.isInteger(v) && v >= 0) && t.wins+t.losses <= 82) && Array.isArray(n.series) && n.series.every(s => s && Number.isInteger(s.round) && typeof s.conference === 'string' && [s.home,s.away,s.winner].every(t => t === '' || NBA_TEAMS.includes(t)) && finite(s.homeWins) && finite(s.awayWins) && (s.status === undefined || ['waiting','ready','active','complete'].includes(s.status)) && (s.sources === undefined || (Array.isArray(s.sources) && s.sources.every(source => typeof source === 'string'))) && (s.scores === undefined || (Array.isArray(s.scores) && s.scores.every(score => score && Number.isInteger(score.game) && score.game >= 1 && [score.home,score.away].every(team => NBA_TEAMS.includes(team)) && [score.homeScore,score.awayScore].every(points => Number.isInteger(points) && points >= 0) && typeof score.homeWon === 'boolean' && score.homeWon === (score.homeScore > score.awayScore) && score.homeScore !== score.awayScore))) && Array.isArray(s.games)) && Array.isArray(n.playoffGames) && n.playoffGames.every(g => g && (g.boxScore === undefined || validBoxScore(g.boxScore)) && typeof g.id === 'string' && typeof g.opponent === 'string' && typeof g.home === 'boolean' && typeof g.won === 'boolean' && ['season','teamScore','opponentScore','pts','reb','ast','stl','blk','min','fgm','fga','tpm','tpa','ftm','fta'].every(k => finite(g[k as keyof GameResult]))) && Array.isArray(n.awards) && n.awards.every(a => a && [a.name,a.winner,a.team,a.detail].every(v => typeof v === 'string') && typeof a.player === 'boolean' && validAwardCandidates(a.members) && validAwardCandidates(a.candidates)) && Array.isArray(n.milestones) && n.milestones.every(m => typeof m === 'string') && (!n.injury || (typeof n.injury.name === 'string' && Number.isInteger(n.injury.remaining) && n.injury.remaining > 0));
  if (c.nba && !validNba(c.nba)) return false;
  if (c.nbaHistory && (!Array.isArray(c.nbaHistory) || !c.nbaHistory.every(validNba))) return false;
  const validNcaa=(n:NcaaState)=>!!n&&finite(n.season)&&['regular','conference','national','complete'].includes(n.stage)&&Number.isInteger(n.round)&&n.round>=0&&n.round<=6&&Array.isArray(n.matchups)&&n.matchups.every(m=>m&&['conference','national'].includes(m.stage)&&Number.isInteger(m.round)&&m.round>=1&&m.round<=6&&[m.id,m.label,m.region,m.home,m.away,m.winner].every(x=>typeof x==='string')&&[m.homeSeed,m.awaySeed].every(x=>Number.isInteger(x)&&x>=0&&x<=16)&&(!m.winner||m.winner===m.home||m.winner===m.away))&&Array.isArray(n.postseasonGames)&&n.postseasonGames.every(g=>g&&(g.boxScore===undefined||validBoxScore(g.boxScore))&&typeof g.id==='string'&&typeof g.opponent==='string'&&typeof g.won==='boolean'&&['season','teamScore','opponentScore','pts','reb','ast','stl','blk','min','fgm','fga','tpm','tpa','ftm','fta'].every(k=>finite(g[k as keyof GameResult])))&&Array.isArray(n.awards)&&n.awards.every(a=>a&&[a.name,a.winner,a.team,a.detail].every(x=>typeof x==='string')&&typeof a.player==='boolean'&&validAwardCandidates(a.members)&&validAwardCandidates(a.candidates));
  if(c.ncaa&&!validNcaa(c.ncaa))return false;
  if(c.ncaaHistory&&(!Array.isArray(c.ncaaHistory)||!c.ncaaHistory.every(validNcaa)))return false;
  if (!c.points || !groups.every(g => finite(c.points[g]) && c.points[g] >= 0)) return false;
  if (!c.contract || !finite(c.contract.years) || !finite(c.contract.salary)) return false;
  if (![c.confidence, c.trust].every(n => n === undefined || (finite(n) && n >= 0 && n <= 100))) return false;
  if (c.role !== undefined && (!Number.isInteger(c.role) || c.role < 1 || c.role > 4)) return false;
  if (c.eventStep !== undefined && (!Number.isInteger(c.eventStep) || c.eventStep < 0 || c.eventStep > 4)) return false;
  if (c.challengeGoal && (!['scoring', 'playmaking', 'inside'].includes(c.challengeGoal.route) || !finite(c.challengeGoal.start) || !finite(c.challengeGoal.target))) return false;
  if (!Array.isArray(c.log) || !c.log.every(s => typeof s === 'string') || !Array.isArray(c.honors) || !c.honors.every(s => typeof s === 'string')) return false;
  if (!Array.isArray(c.games) || !Array.isArray(c.history)) return false;
  if (!c.games.every(g => g && (g.boxScore === undefined || validBoxScore(g.boxScore)) && (g.to === undefined || finite(g.to)) && (g.shots === undefined || (Array.isArray(g.shots) && g.shots.every(s => s && finite(s.x) && finite(s.y) && s.x >= 0 && s.x <= 100 && s.y >= 0 && s.y <= 100 && typeof s.made === 'boolean' && typeof s.three === 'boolean'))) && typeof g.id === 'string' && typeof g.opponent === 'string' && typeof g.won === 'boolean' && typeof g.home === 'boolean' && ['season', 'teamScore', 'opponentScore', 'pts', 'reb', 'ast', 'stl', 'blk', 'min', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta'].every(k => finite(g[k as keyof GameResult])))) return false;
  if (c.games.filter(g => g.season === c.season).length !== c.game) return false;
  return c.history.every(s => s && ['college', 'nba'].includes(s.phase) && typeof s.team === 'string' && ['season', 'age', 'games', 'wins', 'losses', 'pts', 'reb', 'ast', 'stl', 'blk', 'fgPct', 'threePct', 'ftPct'].every(k => finite(s[k as keyof SeasonRecord])));
}
