import Link from "next/link";
import Image from "next/image";
import type { ReactNode } from "react";
import s from "./toolbox.module.css";
import { SecretDoor } from "./secret-door";

export function ToolShell({children,title,subtitle,number}:{children:ReactNode;title:string;subtitle:string;number:string}) {
  return <main className={s.shell}><div className={s.wrap}><header className={s.nav}><Link className={s.brand} href="/"><Image src="/icon.svg" alt="木棍" width={34} height={34} />fran.</Link><nav className={s.links} aria-label="工具导航"><Link href="/calculator">计算器</Link><Link href="/notes">文档</Link><Link href="/timer">专注</Link><Link href="/wheel">随机</Link></nav></header><section className={s.hero}><div><span className={s.eyebrow}>{number} / FRAN PLAYGROUND</span><h1>{title}</h1><p>{subtitle}</p></div><div className={s.stamp}>小工具<br/>大玩心<br/>✳</div></section>{children}<SecretDoor/><footer className={s.footer}>只在你的浏览器里工作。文档与游戏存档保存在本机，不会自动同步到其他设备。<br/>FRAN — ABCD — ABCD · 给日常留一点好玩。</footer></div></main>;
}

export function ToolboxHome() {
  const tools=[['01','＋','口袋计算器','认真算数，也留一扇通往球场的秘密小门。','/calculator','计算 / 彩蛋'],['02','▤','灵感便签','写一篇小文档，记点子、列计划，随时导出。','/notes','记录 / 本机保存'],['03','◷','专注时光机','让倒计时帮你专心一会儿，再好好休息。','/timer','专注 / 休息'],['04','✳','命运转盘','吃什么、做什么？把纠结交给随机选择。','/wheel','抽签 / 决策']];
  return <ToolShell title="有用一点，好玩很多。" subtitle="你的日常小工具收藏夹。每一张卡片，都是一扇独立的小门。" number="THE TOOLBOX"><div className={s.grid}>{tools.map(([n,icon,title,description,href,label])=><Link href={href} key={href} className={s.card}><small>TOOL {n} / {label}</small><span className={s.symbol}>{icon}</span><h2>{title}</h2><p>{description}</p><footer><span>{href}</span><span>打开 ↗</span></footer></Link>)}</div></ToolShell>;
}


