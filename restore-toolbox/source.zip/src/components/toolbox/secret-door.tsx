"use client";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import s from "./toolbox.module.css";

export function SecretDoor(){
  const path=usePathname().replace(/\/$/,'');
  return <ToolDoor key={path} path={path}/>;
}
function ToolDoor({path}:{path:string}){
  const router=useRouter();
  const [visible,setVisible]=useState(false),[score,setScore]=useState(0),[basket,setBasket]=useState(1),[message,setMessage]=useState(''),[charge,setCharge]=useState(0),[cards,setCards]=useState<number[]>([]),[lucky,setLucky]=useState(1),[won,setWon]=useState(false);
  const interval=useRef<ReturnType<typeof setInterval>|null>(null),start=useRef(0);
  const open=()=>router.push(path+'/games-career');
  function stop(){if(interval.current){clearInterval(interval.current);interval.current=null;}setCharge(c=>c>=100?100:0);}
  useEffect(()=>()=>{if(interval.current)clearInterval(interval.current);},[]);
  function hold(){if(interval.current||won)return;start.current=Date.now();interval.current=setInterval(()=>{const progress=Math.min(100,(Date.now()-start.current)/30);setCharge(progress);if(progress===100){clearInterval(interval.current!);interval.current=null;setWon(true);}},40);}
  if(!['/notes','/timer','/wheel'].includes(path))return null;
  const label=path==='/notes'?'揉张纸，投个篮':path==='/timer'?'给自己充个电':'抽屉里有三张神秘卡';
  return <aside className={s.panel}><button aria-expanded={visible} onClick={()=>{stop();setVisible(!visible);if(!visible&&path==='/wheel'&&!cards.length)setLucky(Math.floor(Math.random()*3));}}>✧ {visible?'收起课间小动作':label}</button>{visible&&<div className={s.center}>
    {path==='/notes'&&<><p>篮筐会换位置。点有篮筐的那一格，把纸团投进去。连进 3 球，看看会发生什么。</p><div className={s.actions}>{[0,1,2].map(i=><button key={i} className={s.miniTarget} aria-label={`向${['左','中','右'][i]}投纸团${basket===i?'，有篮筐':''}`} disabled={won} onClick={()=>{if(i===basket){const next=score+1;setScore(next);setMessage(next===3?'三投全中！纸篓后面竟然还有一座球场。':'空心入网！再来一个。');if(next===3)setWon(true);else setBasket((basket+1+Math.floor(Math.random()*2))%3);}else{setScore(0);setMessage('纸团弹出来了，再试一次。');}}}>{basket===i?'🗑️':'·'}</button>)}</div><p>{'●'.repeat(score)}{'○'.repeat(3-score)} · {score}/3</p><p role="status">{message}</p></>}
    {path==='/timer'&&<><p>按住下面的电池 3 秒，攒满课间能量。松开太早会重新开始。也支持按住空格或 Enter。</p><button className={s.chargeButton} aria-label="长按充电" onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);hold();}} onPointerUp={stop} onPointerCancel={stop} onKeyDown={e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)hold();}}} onKeyUp={e=>{if([' ','Enter'].includes(e.key))stop();}} onBlur={stop}>{won?'⚡ 电量已满':`▰ ${Math.floor(charge)}%`}</button><progress className={s.progress} aria-label="课间能量" max={100} value={charge}/>{won&&<p role="status">能量已满，发现一扇通往球场的门。</p>}</>}
    {path==='/wheel'&&<><p>翻开卡片，找出藏着篮球的那一张。每次打开都是一次小小的寻宝。</p><div className={s.actions}>{[0,1,2].map(i=><button key={i} className={s.miniTarget} disabled={cards.includes(i)||won} aria-label={`翻开第 ${i+1} 张卡片`} onClick={()=>{setCards([...cards,i]);if(i===lucky)setWon(true);}}>{cards.includes(i)?i===lucky?'🏀':i===0?'🍀':'⭐':'?'}</button>)}</div>{won&&<p role="status">找到篮球了！卡片背面写着一个球场地址。</p>}</>}
    {won&&<button className={s.primary} onClick={open}>走进隐藏球场 ↗</button>}
  </div>}</aside>;
}
