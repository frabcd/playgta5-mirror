import { CareerApp } from "@/components/sites/lanqiushengya/career-app";
import Link from "next/link";
import s from "./toolbox.module.css";
export function NestedCareer({tool,label}:{tool:string;label:string}){return <><CareerApp/><Link className={s.gameBack} href={'/'+tool}>← 返回{label}</Link></>;}
