"use client";

import { useState } from "react";
import { GROUP_LABELS, NBA_TEAMS, overall, rest, signTeam, simulateGames, nextRegularMatch, type Career, type TrainingGroup } from "@/lib/lanqiushengya/engine";
import { advanceNbaPostseason, initializeNbaPostseason, pendingNbaMatch, playNbaPostseasonGame, extendContract, getNbaAwards, getNbaStandings, requestTrade, retireCareer } from "@/lib/lanqiushengya/nba";
import { MatchCenter } from "./match-center";
import { NbaPostseason } from "./nba-postseason";
import { buildNbaAwards } from "@/lib/lanqiushengya/nba-awards";
import { TeamRoster } from "./team-roster";
import { StoryPanel } from "./career-story";
import { SeasonDetail } from "./season-detail";
import { OffseasonDesk } from "./offseason-desk";
import { CourtScene } from "./pixel-art";
import styles from "./nba-dashboard.module.css";

type Props = { career: Career; onChange: (career: Career) => void; onArchive: () => void; onRecords: () => void; onTraining: (group: TrainingGroup) => void };
const tabs = ["赛季旅程", "联盟排名", "季后赛", "薪资与交易", "赛季回顾", "球队阵容", "生涯故事", "赛季手册", "休赛期"];
const rounds = ["附加赛", "季后赛首轮", "分区半决赛", "分区决赛", "NBA 总决赛"];
const stages = { regular: "常规赛", playin: "附加赛", playoffs: "季后赛", complete: "休赛期" };
const money = (salary: number) => `$${(salary / 10000).toLocaleString("zh-CN", { maximumFractionDigits: 0 })} 万`;

export function NbaAwards({ career }: { career: Career }) {
  const [ownOnly, setOwnOnly] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState(career.season);
  const seasons = [...new Set([career.season, ...(career.nbaHistory ?? []).map(season => season.season)])].sort((a, b) => b - a);
  const year = seasons.includes(selectedSeason) ? selectedSeason : career.season;
  const awards = year === career.season ? getNbaAwards(career) : career.nbaHistory?.find(season => season.season === year)?.awards ?? [];
  const previewAwards = year === career.season && career.game > 0 && !awards.length ? buildNbaAwards(career) : [];
  const shown = ownOnly ? awards.filter(a => a.player) : awards;
  return <div className={styles.dashboard}><section className={styles.panel}>
    <div className={styles.heading}><div><div className={styles.eyebrow}>{year}–{String(year + 1).slice(-2)} · NBA HONORS</div><h2>赛季荣誉榜</h2></div><span className={styles.badge}>个人荣誉 {awards.filter(a => a.player).length}</span></div>
    <label>奖项赛季 <select aria-label="奖项赛季" value={year} onChange={event => setSelectedSeason(Number(event.target.value))}>{seasons.map(season => <option key={season} value={season}>{season}–{String(season + 1).slice(-2)}</option>)}</select></label>
    <p className={styles.muted}>常规赛结束后公布年度奖项，总决赛结束后公布冠军与总决赛 MVP。属于你的荣誉以金色标记。</p>
    <div className={styles.tabs}><button className={!ownOnly ? styles.active : ""} onClick={() => setOwnOnly(false)}>全部荣誉</button><button className={ownOnly ? styles.active : ""} onClick={() => setOwnOnly(true)}>我的荣誉</button></div>
    {!awards.length ? <p className={styles.empty}>本赛季还在进行中。完成 82 场常规赛后，荣誉榜将在这里揭晓。</p> : !shown.length ? <p className={styles.empty}>本赛季暂未获得个人奖项。继续训练，向下一项荣誉进发。</p> : <div className={styles.awardGrid}>{shown.map(a => <article key={a.name} className={`${styles.award} ${a.player ? styles.earned : ""}`}><h4>{a.player ? "★ " : "◇ "}{a.name}</h4><p><strong>{a.winner}</strong></p><p>{a.team}</p><p className={styles.muted}>{a.detail}</p>{a.members && <ol>{a.members.map((p,i)=><li key={p.id} className={p.player?styles.winner:undefined}>{a.name==='全明星'?'入选':'第 '+(Math.floor(i/5)+1)+' 阵'} · {p.name}{p.player?'（你）':''} · {p.team}</li>)}</ol>}{a.candidates && <details><summary>候选榜与评选数据</summary><div className={styles.tableWrap}><table><thead><tr><th>球员</th><th>出场</th><th>分 / 板 / 助</th><th>断 / 帽</th><th>评选分</th></tr></thead><tbody>{a.candidates.map(p=><tr key={p.id} className={p.player?styles.own:undefined}><td>{p.name}{p.player?' · 你':''}</td><td>{p.games}</td><td>{p.pts.toFixed(1)} / {p.reb.toFixed(1)} / {p.ast.toFixed(1)}</td><td>{p.stl.toFixed(1)} / {p.blk.toFixed(1)}</td><td>{p.score.toFixed(1)}</td></tr>)}</tbody></table></div></details>}</article>)}</div>}
    {previewAwards.length>0&&<><h3>赛季奖项追踪 · 暂定候选</h3><p className={styles.muted}>出勤按赛季进度折算，仅为当前走势；82 场结束时按完整资格结算。</p><div className={styles.awardGrid}>{previewAwards.slice(0,5).map(a=><article className={styles.award} key={a.name}><h4>{a.name}</h4><ol>{a.candidates?.slice(0,3).map(p=><li key={p.id}>{p.name}{p.player?"（你）":""} · {p.score.toFixed(1)} 分</li>)}</ol></article>)}</div></>}
  </section></div>;
}

export function NbaDashboard({ career, onChange, onArchive, onRecords, onTraining }: Props) {
  const c = initializeNbaPostseason(career);
  const n = c.nba;
  const [tab, setTab] = useState(0);
  const [conference, setConference] = useState("东部");
  const [destination, setDestination] = useState(NBA_TEAMS.find(team => team !== c.team) ?? NBA_TEAMS[0]);
  const [matchInfo, setMatchInfo] = useState<{opponent:string;home:boolean;label:string} | null>(null);
  const [retiring, setRetiring] = useState(false);
  const retired = c.phase === "retired";
  const regular = (n?.stage ?? "regular") === "regular" && !retired;
  const complete = n?.stage === "complete";
  const games = c.games.filter(g => g.season === c.season && g.min > 0);
  const avg = (key: "pts" | "reb" | "ast" | "stl" | "blk") => (games.reduce((sum, g) => sum + g[key], 0) / Math.max(1, games.length)).toFixed(1);
  const rows = getNbaStandings(c).filter(row => row.conference === conference).sort((a, b) => a.seed - b.seed);
  const ownStanding = getNbaStandings(c).find(row => row.team === c.team);
  const last = n?.playoffGames.at(-1) ?? c.games.filter(g => g.season === c.season).at(-1);
  const goal = (c.role ?? 2) <= 1 ? { title: "成为可靠的第六人", points: 15, assists: 3 } : (c.role ?? 2) === 2 ? { title: "稳住首发，争取最佳阵容", points: 20, assists: 4 } : { title: "带领球队争冠", points: 25, assists: 6 };
  const pending = pendingNbaMatch(c);
  const preview = regular ? nextRegularMatch(c) : pending;
  const matchLabel = regular ? `常规赛 · 第 ${c.game + 1} 场 / 82` : `${rounds[pending?.round ?? n?.round ?? 0]} · G${pending?.gameNumber ?? 1}`;
  const openMatch = () => { if(preview) setMatchInfo({...preview,label:matchLabel}); };
  const postseasonControl = !retired && !regular && !complete && <button className={styles.primary} onClick={() => pending ? openMatch() : onChange(advanceNbaPostseason(c))}>{pending ? `进入比赛 · ${pending.opponent} →` : "推进下一比赛日 →"}</button>;
  return <div className={styles.dashboard}>
    <div className={styles.hero}><CourtScene name={c.player.name} number={c.player.number} /></div>
    <div className={styles.heading}><div><div className={styles.eyebrow}>NBA · {c.season}–{String(c.season + 1).slice(-2)}</div><h2>{c.player.name} · 职业生涯</h2><p className={styles.muted}>{c.team} · #{c.player.number} · {c.player.position} · {c.age} 岁</p></div><span className={styles.badge}>{retired ? "已退役" : stages[n?.stage ?? "regular"]} · 总评 {overall(c.player)}</span></div>
    <div className={styles.tabs} role="tablist" aria-label="NBA 生涯内容">{tabs.map((label, index) => <button key={label} role="tab" aria-selected={tab === index} className={tab === index ? styles.active : ""} onClick={() => setTab(index)}>{label}</button>)}</div>
    {tab === 0 && <>
      <div className={styles.grid}><section className={styles.panel}><h3>每一场，书写你的生涯</h3><div className={styles.stats}>{[["场均得分", avg("pts")], ["场均篮板", avg("reb")], ["场均助攻", avg("ast")], ["场均抢断", avg("stl")], ["场均盖帽", avg("blk")], ["实际出场", String(games.length)]].map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div><div className={styles.summary}><span className={styles.badge}>{c.wins} 胜 · {c.losses} 负</span><span className={styles.muted}>常规赛 {c.game} / 82 场</span></div><div className={styles.progress} role="progressbar" aria-label="常规赛进度" aria-valuenow={c.game} aria-valuemin={0} aria-valuemax={82}><i style={{ width: `${c.game / 82 * 100}%` }} /></div>
        {retired ? <div className={styles.note}>球鞋挂起，故事留在这里。你的比赛、数据和荣誉都已保留。</div> : regular ? <div className={styles.actions}><button className={styles.primary} onClick={() => openMatch()}>进入下一场比赛 →</button><button onClick={() => onChange(simulateGames(c, 10))}>推进 10 场</button><button onClick={() => onChange(simulateGames(c, 82 - c.game))}>完成常规赛</button></div> : complete ? <><div className={styles.note}>赛季落幕 · 总冠军：{n?.champion}。回顾这一年的表现，准备休赛期与新的挑战。</div><button className={styles.primary} onClick={() => setTab(8)}>安排休赛期与下一季 →</button></> : <><p className={styles.muted}>常规赛结束。分区前六直接晋级，第 7–10 名争夺最后两个席位。即使你的球队出局，也可以继续观察联盟争冠。</p>{postseasonControl}</>}
        <div className={styles.actions}><button onClick={onArchive}>完整比赛与生涯档案</button></div>
      </section><section className={styles.panel}><h3>身体与心态</h3>{[["体力", c.energy], ["信心", c.confidence ?? 75], ["教练信任", c.trust ?? 50]].map(([label, value]) => <div key={label}><div className={styles.summary}><span className={styles.muted}>{label}</span><strong>{value}</strong></div><div className={styles.progress}><i style={{ width: `${value}%` }} /></div></div>)}{n?.injury && <div className={`${styles.note} ${styles.injury}`}><strong>{n.injury.name}</strong><br />预计还需恢复 {n.injury.remaining} 场。伤停期间球队继续比赛，你不会产生个人比赛数据。</div>}<button className={styles.wide} disabled={retired || c.energy >= 100} onClick={() => onChange(rest(c))}>休息与康复</button><p className={styles.muted}>休息恢复 35 体力。伤病按球队比赛场次恢复；休息不会跳过伤停时间。</p></section></div>
      <StoryPanel career={c} onChange={onChange} />
      <section className={styles.panel}><div className={styles.heading}><h3>日常训练</h3><span className={styles.muted}>每次消耗 15 体力</span></div><div className={styles.training}>{(Object.keys(GROUP_LABELS) as TrainingGroup[]).map(group => <button key={group} disabled={retired || c.energy < 15 || !!n?.injury} onClick={() => onTraining(group)}><strong>{GROUP_LABELS[group]}</strong><small>{c.points[group]} 训练点</small></button>)}</div></section>
      {last && <section className={styles.panel}><div className={styles.summary}><div><h3>最近一场 · {last.won ? "胜利" : "失利"}</h3><p>{c.team} vs {last.opponent}</p><p>{last.min ? `${last.min} 分钟 · ${last.pts} 分 / ${last.reb} 篮板 / ${last.ast} 助攻 / ${last.stl} 抢断 / ${last.blk} 盖帽` : "伤停 · 未出场"}</p></div><strong className={styles.score}>{last.teamScore}–{last.opponentScore}</strong></div><button onClick={onRecords}>查看比赛回顾</button></section>}
      <section className={styles.panel}><h3>赛季目标 · {goal.title}</h3><p className={styles.muted}>根据你当前的球队角色制定目标。达标进度随比赛更新，奖项仍按荣誉榜的评选条件结算。</p><div className={styles.stats}><div><span>场均得分目标 {goal.points}</span><strong>{avg("pts")}</strong></div><div><span>场均助攻目标 {goal.assists}</span><strong>{avg("ast")}</strong></div><div><span>出场目标 65 场</span><strong>{games.length} / 65</strong></div></div><p>{Number(avg("pts")) >= goal.points ? "✓" : "○"} 得分目标　{Number(avg("ast")) >= goal.assists ? "✓" : "○"} 组织目标　{games.length >= 65 ? "✓" : "○"} 出勤目标</p></section>
      <section className={styles.panel}><h3>生涯动态</h3><ul className={styles.log}>{c.log.slice(0, 8).map((line, i) => <li key={`${i}-${line}`}>{line}</li>)}</ul></section>
    </>}
    {tab === 1 && <section className={styles.panel}><div className={styles.heading}><h3>联盟排名</h3><span className={styles.badge}>30 支球队 · 82 场常规赛</span></div><div className={styles.tabs}>{["东部", "西部"].map(conf => <button key={conf} className={conference === conf ? styles.active : ""} onClick={() => setConference(conf)}>{conf}</button>)}</div><p className={styles.muted}>前 6 名直接晋级季后赛 · 第 7–10 名参加附加赛 · 同战绩按球队名称排序</p><div className={styles.tableWrap}><table><thead><tr><th>排名</th><th>球队</th><th>胜</th><th>负</th><th>胜率</th><th>席位</th></tr></thead><tbody>{rows.map(row => <tr key={row.team} className={row.team === c.team ? styles.own : ""}><td>{row.seed || "—"}</td><td>{row.team}{row.team === c.team ? " · 你" : ""}</td><td>{row.wins}</td><td>{row.losses}</td><td>{row.wins + row.losses ? (row.wins / (row.wins + row.losses) * 100).toFixed(1) : "0.0"}%</td><td>{!row.seed ? "待定" : row.seed <= 6 ? "季后赛" : row.seed <= 10 ? "附加赛" : "区外"}</td></tr>)}</tbody></table></div></section>}
    {tab === 2 && <NbaPostseason career={c} controls={<>{postseasonControl}{complete && !retired && <button onClick={() => setTab(8)}>安排休赛期与下一季 →</button>}<button onClick={onRecords}>查看全部季后赛数据</button></>}/>}
    {tab === 3 && <section className={styles.panel}><h3>薪资与交易</h3><p>{c.team} · {c.player.name}</p><div className={styles.money}><div><span>当前年薪</span><strong>{money(c.contract.salary)}</strong></div><div><span>合同剩余</span><strong>{c.contract.years} 年</strong></div></div><label className={styles.label} htmlFor="nba-destination">选择目标球队</label><div className={styles.filters}><select id="nba-destination" value={destination} onChange={e => setDestination(e.target.value)}>{NBA_TEAMS.map(team => <option key={team}>{team}</option>)}</select></div>{c.contract.years <= 0 ? <div className={styles.offer}><h4>自由球员合同</h4><p>{destination} · 3 年 · 年薪 {money(Math.max(300, (overall(c.player) - 40) * 80) * 10000)}</p><p className={styles.muted}>薪资由当前能力决定。签约后立即加入球队并开始履行合同。</p><button className={styles.primary} disabled={retired} onClick={() => onChange(signTeam(c, destination))}>接受合同 · 加盟球队</button></div> : <><p className={styles.muted}>合同期间可以在常规赛前 45 场内申请一次交易，交易保留现有合同。</p><button disabled={retired || !regular || c.game > 45 || !!n?.tradeRequested || destination === c.team} onClick={() => onChange(requestTrade(c, destination))}>{n?.tradeRequested ? "本赛季已完成交易" : c.game > 45 ? "交易窗口已关闭" : "申请交易至所选球队"}</button></>}{retired && <p className={styles.muted}>已退役，合同与交易操作已关闭。</p>}</section>}
    {tab === 4 && <><section className={styles.panel}><h3>{c.season}–{String(c.season + 1).slice(-2)} · 赛季回顾</h3><div className={styles.stats}>{[["球队战绩", `${c.wins}–${c.losses}`], ["分区排名", ownStanding?.seed ? `${ownStanding.conference} #${ownStanding.seed}` : "待定"], ["总评", String(overall(c.player))]].map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div><p>{n?.champion ? `总冠军：${n.champion}${n.champion === c.team ? "。你与球队一起站上了最高领奖台！" : "。下一次，向更远的地方进发。"}` : "赛季仍在进行，最终成绩与冠军将在季后赛结束后公布。"}</p><div className={styles.actions}><button onClick={onArchive}>完整赛季与比赛回顾</button>{complete && !retired && <button className={styles.primary} onClick={() => setTab(8)}>安排休赛期与下一季 →</button>}</div></section><NbaAwards career={c} /><section className={styles.panel}><h3>赛季里程碑</h3>{n?.milestones.length ? <ul className={styles.log}>{n.milestones.map((line, i) => <li key={`${i}-${line}`}>{line}</li>)}</ul> : <p className={styles.muted}>高分、三双、交易、伤愈和冠军时刻将记录在这里。</p>}</section><section className={styles.panel}><h3>生涯的下一页</h3><p className={styles.muted}>休赛期会结算年龄成长与身体变化。退役后仍可查看全部比赛和荣誉；退役决定不能撤销。</p>{retired ? <button onClick={onArchive}>查看退役档案</button> : retiring ? <div className={styles.confirm}><p>确认结束 {c.player.name} 的职业生涯？</p><div className={styles.actions}><button className={styles.danger} onClick={() => { onChange(retireCareer(c)); setRetiring(false); }}>确认退役</button><button onClick={() => setRetiring(false)}>继续打球</button></div></div> : <button className={styles.danger} onClick={() => setRetiring(true)}>考虑退役</button>}</section></>}
    {tab === 3 && c.contract.years === 1 && !retired && <section className={styles.panel}><h3>续约谈判</h3><p>球队愿意以年薪 {money(Math.max(300, (overall(c.player) - 40) * 80) * 10000)} 提供一份 3 年合同。</p><p className={styles.muted}>接受后替换当前合同，继续留在 {c.team}。</p><button className={styles.primary} onClick={() => onChange(extendContract(c))}>接受续约 · 3 年</button></section>}
    {tab === 5 && <TeamRoster career={c} />}
    {tab === 6 && <StoryPanel career={c} onChange={onChange} />}
    {tab === 7 && <SeasonDetail career={c} onChange={onChange} onPlay={openMatch} />}
    {tab === 8 && <OffseasonDesk career={c} onChange={onChange} />}
    {matchInfo && <MatchCenter team={c.team} {...matchInfo} onClose={() => setMatchInfo(null)} onPlay={tactic => { const next = regular ? simulateGames(c, 1, tactic) : playNbaPostseasonGame(c, tactic); onChange(next); return regular ? next.games.at(-1) : next.nba?.playoffGames.at(-1); }} />}

  </div>;
}
