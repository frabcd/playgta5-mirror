"use client";

import Image from "next/image";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Archive, ArrowRight, Award, BarChart3, Check, ClipboardList, Download, Dumbbell, Home, Menu, RotateCw, Save, Sparkles, Trophy, Upload, X } from "lucide-react";
import { CourtScene, PixelPlayer, defaultAppearance, type Appearance } from "./pixel-art";
import { NbaPostseason } from "./nba-postseason";
import { TournamentBracket } from "./tournament-bracket";
import { NcaaAwards } from "./ncaa-awards";
import { NbaAwards } from "./nba-dashboard";
import { MatchRecords, CareerArchive } from "./career-reviews";
import { createNbaCareer } from "@/lib/lanqiushengya/nba";
import { Recruitment } from "./recruitment";
import { loadCareers, persistCareer, persistDraftSelection, LEGACY_STORAGE_KEY, STORAGE_FAILURE_MESSAGE, type SavedCareer } from "@/lib/lanqiushengya/career-storage";
import { RATING_LABELS, GROUP_LABELS, RATING_GROUP, generatePlayer, createCareer, overall, validateCareer, type Career, type Player, type PlayerInput, type RatingKey, type TrainingGroup } from "@/lib/lanqiushengya/engine";
import { DeepSeekSetup, AiCareerPanel, AiReportView } from "./deepseek-panel";
import { generateReport, type AiConfig, type AiReport } from "@/lib/lanqiushengya/deepseek";
import "./career.css";

const DRAFT_KEY = "kba-local-draft-v1";
const positions = { PG: "控球后卫", SG: "得分后卫", SF: "小前锋", PF: "大前锋", C: "中锋" };
const initialInput: PlayerInput = { name: "", potential: 88, height: 198, weight: 95, wingspan: 206, number: "0", position: "SF", description: "" };
const tabs = ["生涯主页", "球员能力", "比赛记录", "球探报告", "生涯档案", "赛季奖项", "排行榜", "AI 托管"] as const;
type TabName = typeof tabs[number];
const tabIcons = [Home, Dumbbell, ClipboardList, ClipboardList, Archive, Trophy, BarChart3, Sparkles];
const appearanceOptions = { skin: ["浅色", "暖浅", "小麦", "棕色", "深棕", "深色"], face: ["标准", "圆脸", "方脸"], hair: ["光头", "短寸", "侧分", "卷发", "脏辫", "长发", "爆炸头", "莫西干", "丸子头"], hairColor: ["黑色", "棕色", "金色", "银白", "酒红", "雾蓝", "墨绿"], eyes: ["平和", "专注", "锐利", "浓眉", "大眼", "细长", "眨眼", "笑眼"], beard: ["无胡子", "短胡茬", "络腮胡", "小胡子", "山羊胡", "八字胡", "下巴胡", "长络腮胡"] };
const appearanceLabels: Record<keyof Appearance, string> = { skin: "肤色", face: "脸型", hair: "发型", hairColor: "发色", eyes: "眉眼", beard: "胡子" };
type ModalName = "appearance" | "save" | "updates" | "new" | "about" | "contract" | null;
type Wheel = { field: "potential" | "height" | "weight" | "wingspan"; label: string; min: number; max: number; value: number; spinning: boolean; result: boolean };

function Modal({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  useEffect(() => { closeRef.current = onClose; }, [onClose]);
  useEffect(() => {
    const old = document.activeElement as HTMLElement | null;
    const root = ref.current;
    root?.focus();
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") {
        const focusable = root?.querySelectorAll<HTMLElement>('button:not([disabled]),input,textarea,select,[tabindex="0"]');
        if (!focusable?.length) return;
        const first = focusable[0]; const last = focusable[focusable.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === root)) { event.preventDefault(); last.focus(); }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", handler);
    return () => { document.removeEventListener("keydown", handler); old?.focus(); };
  }, []);
  return <div className="kba-overlay" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={"kba-modal " + (wide ? "wide" : "")} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref}><header><h2>{title}</h2><button className="icon-button" aria-label={"关闭" + title} onClick={onClose}><X size={20} /></button></header><div className="modal-body">{children}</div></div></div>;
}

function seasonName(year: number) { return year + "–" + String(year + 1).slice(-2); }
function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min)); }
function isAppearance(value: unknown): value is Appearance {
  if (!value || typeof value !== "object") return false;
  return (Object.keys(appearanceOptions) as (keyof Appearance)[]).every(key => { const v = (value as Record<string, unknown>)[key]; return typeof v === "number" && Number.isInteger(v) && v >= 0 && v < appearanceOptions[key].length; });
}
function readSaves(): SavedCareer[] {
  try { return validSaves(JSON.parse(localStorage.getItem(LEGACY_STORAGE_KEY) || "[]")); } catch { return []; }
}
function validSaves(data: unknown): SavedCareer[] { return Array.isArray(data) ? data.filter((s): s is SavedCareer => !!s && typeof s.id === "string" && typeof s.updated === "string" && isAppearance(s.appearance) && validateCareer(s.career)) : []; }

export function CareerApp() {
  const [aiConfig,setAiConfig]=useState<AiConfig|null>(null);
  const [aiSettings,setAiSettings]=useState(false);
  const [initialReport,setInitialReport]=useState<AiReport|null>(null);
  const generateRequest=useRef<AbortController|null>(null);
  useEffect(()=>()=>generateRequest.current?.abort(),[]);
  const [input, setInput] = useState<PlayerInput>(initialInput);
  const [appearance, setAppearance] = useState<Appearance>(defaultAppearance);
  const [editAppearance, setEditAppearance] = useState<Appearance>(defaultAppearance);
  const [player, setPlayer] = useState<Player | null>(null);
  const [career, setCareer] = useState<Career | null>(null);
  const [saveId, setSaveId] = useState("");
  const [saves, setSaves] = useState<SavedCareer[]>([]);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<TabName>("生涯主页");
  const [modal, setModal] = useState<ModalName>(null);
  const [wheel, setWheel] = useState<Wheel | null>(null);
  const [menu, setMenu] = useState(false);
  const [message, setMessage] = useState("");
  const [storageError, setStorageError] = useState("");
  const [rankBy, setRankBy] = useState<"pts" | "reb" | "ast">("pts");
  const [recruiting, setRecruiting] = useState(false);
  const [generating, setGenerating] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const savesRef = useRef<SavedCareer[]>([]);
  const writeVersion = useRef(0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const legacy = readSaves();
      let local = legacy;
      let activeId: string | null = legacy[0]?.id ?? null;
      try { const loaded = await loadCareers(legacy); local = validSaves(loaded.saves); activeId = loaded.activeId; }
      catch { if (!cancelled) setStorageError('无法读取大容量本机存档，已尝试载入旧版备份。请保留备份并导出当前进度。'); }
      if (cancelled) return;
      savesRef.current = local; setSaves(local);
      const selected = activeId === null ? undefined : local.find(s => s.id === activeId) ?? local[0];
      if (selected) { setCareer(selected.career); setAppearance(selected.appearance); setSaveId(selected.id); }
      else { try { const draft = JSON.parse(localStorage.getItem(DRAFT_KEY) || "null"); if (draft?.input && typeof draft.input.description === "string" && typeof draft.input.name === "string") setInput({ ...initialInput, ...draft.input }); if (isAppearance(draft?.appearance)) setAppearance(draft.appearance); } catch { /* A malformed draft never blocks a fresh career. */ } }
      setReady(true);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const version = ++writeVersion.current;
    let cancelled = false;
    queueMicrotask(() => { if (!cancelled) setSaving(true); });
    let operation: Promise<void>;
    try {
      if (career && saveId) {
        const entry = { id: saveId, updated: new Date().toISOString(), appearance, career };
        savesRef.current = [entry, ...savesRef.current.filter(s => s.id !== saveId)];
        queueMicrotask(() => { if (!cancelled) setSaves(savesRef.current); });
        operation = persistCareer(entry);
      } else { localStorage.setItem(DRAFT_KEY, JSON.stringify({ input, appearance })); operation = persistDraftSelection(); }
    } catch { operation = Promise.reject(new Error('Unable to prepare save')); }
    void operation.then(() => { if (!cancelled && version === writeVersion.current) { setStorageError(''); setSaving(false); } }, () => { if (!cancelled && version === writeVersion.current) { setStorageError(STORAGE_FAILURE_MESSAGE); setSaving(false); } });
    return () => { cancelled = true; };
  }, [career, saveId, appearance, input, ready]);

  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(""), 5000); return () => clearTimeout(timer);
  }, [message]);

  useEffect(() => {
    if (!saving && !storageError) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [saving, storageError]);

  useEffect(() => {
    if (!wheel?.spinning) return;
    const interval = setInterval(() => setWheel(w => w ? { ...w, value: w.min + Math.floor(Math.random() * (w.max - w.min + 1)) } : null), 65);
    const timeout = setTimeout(() => { clearInterval(interval); setWheel(w => w ? { ...w, spinning: false, result: true } : null); }, 1500);
    return () => { clearInterval(interval); clearTimeout(timeout); };
  }, [wheel?.spinning]);

  function updateInput<K extends keyof PlayerInput>(key: K, value: PlayerInput[K]) { setInput(v => ({ ...v, [key]: value })); setPlayer(null); setInitialReport(null); generateRequest.current?.abort(); }
  function normalize(field: "potential" | "height" | "weight" | "wingspan", min: number, max: number) {
    setInput(v => { const value = Math.round(clamp(v[field], min, max)); return { ...v, [field]: value, wingspan: field === "height" ? clamp(v.wingspan, value - 12, value + 26) : field === "wingspan" ? value : v.wingspan }; });
  }
  function openWheel(field: Wheel["field"], label: string, min: number, max: number) { setWheel({field,label,min,max,value:input[field],spinning:false,result:false}); }
  function navigate(next: TabName) { setTab(next); setMenu(false); contentRef.current?.scrollTo({top:0}); }
  function openSave() { setSaves(savesRef.current); setModal("save"); }
  async function generate() {
    if (input.description.trim().length < 12 || generating) return;
    if(!aiConfig){setAiSettings(true);return;}
    const normalized: PlayerInput = { ...input, name: input.name.trim() || "我的新秀", potential: clamp(input.potential,80,100), height:clamp(input.height,160,240),weight:clamp(input.weight,50,200),wingspan:clamp(input.wingspan,clamp(input.height,160,240)-12,clamp(input.height,160,240)+26),number:/^(\d{1,2})$/.test(input.number)?input.number:"0" };
    setInput(normalized); setGenerating(true);
    const controller=new AbortController();generateRequest.current=controller;
    try {const base=generatePlayer(normalized);const report=await generateReport(aiConfig,"profile",base,controller.signal);if(!controller.signal.aborted){setPlayer(base);setInitialReport(report);setMessage("DeepSeek 球探分析已完成。");}}catch(e){if(!controller.signal.aborted)setMessage(e instanceof Error?e.message:"分析失败，请重试。");}finally{setGenerating(false);}
  }
  function startCareer(team: string) { if (!player || !aiConfig) return; setCareer({...createCareer(player,team),aiReports:initialReport?[initialReport]:[]}); setRecruiting(false); setSaveId(crypto.randomUUID()); setTab("生涯主页"); setMessage("欢迎来到大学联赛，你的生涯开始了。"); contentRef.current?.scrollTo({top:0}); }
  function startProCareer() { if (!player || !aiConfig) return; setCareer({...createNbaCareer(player),aiReports:initialReport?[initialReport]:[]}); setRecruiting(false); setSaveId(crypto.randomUUID()); setTab("生涯主页"); setMessage("NBA 新秀生涯已开始，所有赛季免费开放。"); contentRef.current?.scrollTo({top:0}); }
  function exportSave() {
    if (!career) return;
    const blob = new Blob([JSON.stringify({version:1,id:saveId,updated:new Date().toISOString(),appearance,career},null,2)],{type:"application/json"});
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href=url; a.download="KBA-"+career.player.name+"-"+career.season+".json"; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); setMessage("存档已导出。");
  }
  async function importSave(file?: File) {
    if (!file) return;
    if (file.size > 100_000_000) { setMessage("存档文件过大，请选择小于 100 MB 的 JSON 文件。"); return; }
    try {
      const data: unknown = JSON.parse(await file.text());
      if (!data || typeof data !== "object" || !("career" in data) || !validateCareer(data.career) || !("appearance" in data) || !isAppearance(data.appearance)) throw new Error("Invalid save");
      setCareer(data.career); setAppearance(data.appearance); setSaveId(crypto.randomUUID()); setModal(null); navigate("生涯主页"); setMessage("存档已导入，已在本机建立独立副本。");
    } catch { setMessage("无法读取存档。请选择本地版导出的有效 JSON 存档。"); }
  }
  const activePlayer = career?.player || player;
  const disabledCareer = !career;

  if(!aiConfig||aiSettings) return <div className="kba-app"><main className="ai-setup-page"><DeepSeekSetup config={aiConfig} onReady={value=>{setAiConfig(value);if(value)setAiSettings(false);}} onClose={aiConfig?()=>setAiSettings(false):undefined}/></main></div>;
  if(!ready) return <div className="kba-app"><main className="ai-setup-page"><p role="status">正在读取生涯…</p></main></div>;
  return <div className="kba-app">
    <aside className={"sidebar " + (menu ? "open" : "")}>
      <div className="brand"><Image width={52} height={62} src="/sites/lanqiushengya/portrait.png" alt="KBA" /><div><strong>KBA 生涯模式</strong><small>我的篮球生涯</small></div></div>
      <div className="journey-label">YOUR JOURNEY</div>
      <nav aria-label="生涯导航">{tabs.map((name,i)=>{const Icon=tabIcons[i];return <button key={name} disabled={disabledCareer} className={career&&tab===name?"nav-active":""} onClick={()=>navigate(name)}><Icon size={16}/>{name}</button>;})}</nav>
      <div className="sidebar-bottom"><p>从大学，到传奇。</p><p>每一次选择，都在书写你的<br/>下一章。</p><small>MY CAREER · LOCAL EDITION</small></div>
    </aside>
    {menu&&<button className="menu-shade" aria-label="关闭导航" onClick={()=>setMenu(false)}/>}
    <div className="app-column">
      <header className="topbar"><div className="header-first"><div className="mobile-brand brand"><Image width={52} height={62} src="/sites/lanqiushengya/portrait.png" alt="KBA"/><div><strong>KBA 生涯模式</strong><small>我的篮球生涯</small></div></div><div className="breadcrumb">KBA 生涯模式 <ArrowRight size={13}/> <strong>{career?tab:"创建球员"}</strong></div><div className="save-cluster"><button onClick={()=>setAiSettings(true)} aria-label="配置 DeepSeek API">API 设置</button><button className="save-button" onClick={openSave} aria-label="本地存档"><Save size={16}/><span>存档</span></button><span className="save-status">●　{storageError?"保存失败":saving?"保存中…":"已保存到本机"}</span><button className="local-label" onClick={()=>setModal("about")}>AI 托管 · 个人 API</button></div></div><div className="header-second"><div className="header-actions"><button className="mobile-menu" aria-label="打开导航" onClick={()=>setMenu(v=>!v)}><Menu size={18}/></button><button onClick={()=>setModal("updates")}><ClipboardList size={15}/>更新公告</button></div><div className="social"><Image width={25} height={25} src="/sites/lanqiushengya/bilibili.jpg" alt="哔哩哔哩"/><Image width={25} height={25} src="/sites/lanqiushengya/channels.jpg" alt="视频号"/><Image width={25} height={25} src="/sites/lanqiushengya/douyin.jpg" alt="抖音"/><span>：看看可</span></div></div></header>
      <div className="scroll-content" ref={contentRef}><main className="content-inner">
        {storageError&&<div role="alert" className="error-banner">{storageError}<button onClick={exportSave}>导出存档</button></div>}
        {!career ? recruiting && player ? <Recruitment player={player} onJoin={startCareer} onBack={()=>setRecruiting(false)}/> : <>
          <div className="hero-art"><CourtScene number={input.number}/></div>
          <p className="intro-notice">DeepSeek 已连接 · 创建生涯后自动开始逐场托管，可随时暂停。调用使用你的 API 额度。</p>
          <section className="intro"><div className="eyebrow">YOUR GAME, YOUR STORY</div><h1>用你的话，描述你的篮球。</h1><p>从 2026–27 大学赛季出发。身高、体重和位置由你决定，打法交给你自己描述。</p></section>
          <div className="creation-column"><section className="paper-panel player-form"><div className="panel-heading"><h2>你的球员</h2><span className="badge">18 岁 · 大一新生</span></div>
            <label className="field">天赋值（80–100）<input aria-label="潜力值" type="number" min={80} max={100} value={input.potential} onChange={e=>updateInput("potential",Number(e.target.value))} onBlur={()=>normalize("potential",80,100)}/></label>
            <button className="full-button" onClick={()=>openWheel("potential","天赋",80,100)}><span className="pixel-symbol">✥</span>转盘决定天赋</button>
            <p className="hint">天赋影响加点费用；身体与打法决定各项固定上限，训练和休赛期均不突破。NCAA 与 NBA 都可成长；初始总评不超过 70。</p>
            <label className="field">姓名<input aria-label="球员姓名" placeholder="你希望被记住的名字" maxLength={24} value={input.name} onChange={e=>updateInput("name",e.target.value)}/></label>
            <div className="appearance-row"><PixelPlayer appearance={appearance} name={input.name||"我的新秀"} number={input.number} size={56}/><div><small>身体设置</small><strong>自定义球员形象</strong></div><button onClick={()=>{setEditAppearance(appearance);setModal("appearance");}}>捏脸</button></div>
            <div className="body-fields"><label className="field">身高 / cm（160–240）<input aria-label="身高" type="number" min={160} max={240} value={input.height} onChange={e=>updateInput("height",Number(e.target.value))} onBlur={()=>normalize("height",160,240)}/></label><label className="field">体重 / kg（50–200）<input aria-label="体重" type="number" min={50} max={200} value={input.weight} onChange={e=>updateInput("weight",Number(e.target.value))} onBlur={()=>normalize("weight",50,200)}/></label></div>
            <div className="two-buttons"><button onClick={()=>openWheel("height","身高",160,240)}><span className="pixel-symbol">✥</span>转盘生成身高</button><button onClick={()=>openWheel("weight","体重",50,200)}><span className="pixel-symbol">✥</span>转盘生成体重</button></div>
            <label className="field">臂展 / cm（当前身高允许 {input.height-12}–{input.height+26}）<input aria-label="臂展" type="number" min={input.height-12} max={input.height+26} value={input.wingspan} onChange={e=>updateInput("wingspan",Number(e.target.value))} onBlur={()=>normalize("wingspan",input.height-12,input.height+26)}/></label>
            <button className="full-button" onClick={()=>openWheel("wingspan","臂展",input.height-12,input.height+26)}><span className="pixel-symbol">✥</span>转盘生成臂展</button><p className="hint">修改身高时，臂展会限制在合理范围内。转盘各数值等概率，身材特点会影响打法。</p>
            <label className="field">球衣号码（0–99 或 00）<input aria-label="球衣号码" inputMode="numeric" maxLength={2} value={input.number} onChange={e=>updateInput("number",e.target.value.replace(/\D/g,""))}/></label>
            <div className="field">场上位置<div className="position-options">{Object.entries(positions).map(([key,label])=><button key={key} aria-pressed={input.position===key} className={input.position===key?"selected":""} onClick={()=>updateInput("position",key as PlayerInput["position"])}><span className="tiny-icon">▣</span>{key} · {label}</button>)}</div></div>
          </section>
          <section className="paper-panel style-form"><h2>我怎样打球</h2><p className="hint">写写你习惯怎样进攻、怎样防守，以及自己的长处和短板。越具体，生成的球员越有你的特点。</p><textarea aria-label="描述你的打球方式" placeholder="例如：我喜欢打挡拆，突破时先找底角队友，空位三分还不错，但不擅长对抗终结。防守会积极挤掩护，面对大个子比较吃力……" maxLength={1500} value={input.description} onChange={e=>updateInput("description",e.target.value)}/><p className="counter">{input.description.length} / 1500 字 · 至少 12 字</p><p className="hint small">DeepSeek 分析 · 将发送此处填写的游戏球员资料，按你的 API 账户计费。</p><button className="primary full-button" disabled={input.description.trim().length<12||generating} onClick={()=>void generate()}><Sparkles size={21}/>{generating?"正在分析打法…":"生成能力与球员模板"}</button><p className="hint">按身体条件、位置与打法描述生成能力，初始总评不超过 70。AI 分析打法与定位；能力数值仍遵守身体条件、成长上限和开局平衡。</p></section>
          {initialReport&&<AiReportView report={initialReport}/>}
          {player&&<section className="paper-panel generated-player" aria-label="生成的球员模板"><div className="panel-heading"><h2>你的球员模板</h2><span className="overall">{overall(player)} <small>OVR</small></span></div><h3>{player.name} · {player.archetype}</h3><p className="hint">{positions[player.position]} · {player.height} cm / {player.weight} kg · 天赋 {player.potential}</p><div className="rating-grid">{(Object.keys(RATING_LABELS) as RatingKey[]).map(key=><div key={key} className="rating-mini"><span>{RATING_LABELS[key]}</span><strong>{player.ratings[key]}<small> / {player.caps[key]}</small></strong><progress max={100} value={player.ratings[key]}/></div>)}</div><p className="hint">右侧数值为固定能力上限。修改打法后可重新生成。</p><button className="primary full-button" onClick={()=>{setRecruiting(true);contentRef.current?.scrollTo({top:0});}}>接受分析 · 查看大学邀请 <ArrowRight size={18}/></button><button className="full-button" onClick={startProCareer}>直接开启 NBA 生涯 · 免费</button></section>}
          </div>
        </> : <>
          {tab!=="生涯主页"&&<div className="career-heading"><div><div className="eyebrow">{career.phase==="college"?"NCAA · COLLEGE JOURNEY":career.phase==="retired"?"A CAREER TO REMEMBER":"NBA · MY CAREER"}</div><h1>{tab}</h1><p>{seasonName(career.season)} 赛季 · {career.team} · {career.age} 岁</p></div><div className="overall">{overall(career.player)}<small>总评 OVR</small></div></div>}
          <div hidden={tab!=="生涯主页"&&tab!=="AI 托管"}><AiCareerPanel key={saveId} career={career} config={aiConfig} onChange={setCareer} onConfigure={()=>setAiSettings(true)}/></div>
          {tab==="球员能力"&&<><p className="hint">AI 根据能力与剩余训练点自动安排成长，所有升级遵守个人上限。</p><div className="ability-groups">{(Object.keys(GROUP_LABELS) as TrainingGroup[]).map(group=><section key={group} className="paper-panel"><div className="panel-heading"><h2>{GROUP_LABELS[group]}</h2><span className="badge">{career.points[group]} 训练点</span></div>{(Object.keys(RATING_LABELS) as RatingKey[]).filter(key=>RATING_GROUP[key]===group).map(key=><div key={key} className="ability-row"><div><span>{RATING_LABELS[key]}</span><strong>{career.player.ratings[key]}<small> / {career.player.caps[key]}</small></strong><progress max={100} value={career.player.ratings[key]}/></div></div>)}</section>)}</div></>}
          {tab==="比赛记录"&&<><MatchRecords career={career}/>{career.phase!=="college"?<NbaPostseason career={career} controls={null}/>:<TournamentBracket title="NCAA 锦标赛" rounds={["联盟首轮","联盟半决赛","联盟决赛","全国首轮","32 强","16 强","8 强","四强","决赛"]} team={career.team} matches={(career.ncaa?.matchups??[]).map(m=>({...m,round:m.stage==="conference"?m.round-1:m.round+2}))}/>}</>}
          {tab==="球探报告"&&<>{(career.aiReports??[]).filter(r=>["profile","scout","draft"].includes(r.kind)).slice().reverse().map(r=><AiReportView key={r.id} report={r}/>)}<button onClick={()=>navigate("AI 托管")}>查看 AI 分析与托管进度</button></>}
          {tab==="生涯档案"&&<><CareerArchive career={career}/><section className="paper-panel"><div className="button-row"><button onClick={exportSave}><Download size={16}/>导出存档</button><button onClick={()=>setModal("new")}>创建新球员</button></div></section></>}
          {tab==="赛季奖项"&&(career.phase!=="college"?<NbaAwards career={career}/>:<NcaaAwards career={career}/>)}
          {tab==="排行榜"&&<section className="paper-panel"><div className="panel-heading"><h2>个人赛季排行榜</h2><select aria-label="排行数据" value={rankBy} onChange={e=>setRankBy(e.target.value as "pts"|"reb"|"ast")}><option value="pts">场均得分</option><option value="reb">场均篮板</option><option value="ast">场均助攻</option></select></div><p className="hint">比较这份本机存档中的历年表现。</p>{career.history.length?<div className="rankings">{career.history.slice().sort((a,b)=>b[rankBy]-a[rankBy]).map((s,i)=><div key={s.season}><strong className="rank">{String(i+1).padStart(2,"0")}</strong><span>{seasonName(s.season)}<small>{s.team}</small></span><strong>{s[rankBy].toFixed(1)}</strong></div>)}</div>:<Empty title="还没有完整赛季数据" text="打完第一个赛季，看看你的表现。"/>}</section>}
        </>}
        <footer className="page-footer">AI 生涯导演 · 本机存档 · Key 不在本站云端保存<button onClick={()=>setModal("about")}>关于本地版</button></footer>
      </main></div>
    </div>
    {career&&<nav className="bottom-career-nav" aria-label="手机生涯导航">{tabs.map((name,i)=>{const Icon=tabIcons[i];return <button key={name} aria-label={name} aria-current={tab===name?"page":undefined} className={tab===name?"active":""} onClick={()=>navigate(name)}><Icon size={20}/><span>{["生涯","能力","比赛","球探","档案","奖项","排行","AI"][i]}</span></button>;})}</nav>}
    {message&&<div className="toast" role="status"><Check size={17}/>{message}</div>}
    {modal==="appearance"&&<Modal title="捏脸" onClose={()=>setModal(null)}><div className="face-preview"><PixelPlayer appearance={editAppearance} name={activePlayer?.name||input.name||"我的新秀"} number={activePlayer?.number||input.number} size={96}/><div><h3>{activePlayer?.name||input.name||"我的新秀"}</h3><p>选择外观，预览实时变化。<br/>形象随这份生涯保存。</p></div></div>{(Object.keys(appearanceOptions) as (keyof Appearance)[]).map(key=><section className="face-option" key={key}><h3>{appearanceLabels[key]}</h3><div>{appearanceOptions[key].map((label,index)=><button key={label} aria-pressed={editAppearance[key]===index} className={editAppearance[key]===index?"selected":""} onClick={()=>setEditAppearance(a=>({...a,[key]:index}))}>{label}</button>)}</div></section>)}<div className="two-buttons"><button onClick={()=>setEditAppearance(Object.fromEntries(Object.entries(appearanceOptions).map(([k,v])=>[k,Math.floor(Math.random()*v.length)])) as Appearance)}><RotateCw size={15}/>随机形象</button><button onClick={()=>setEditAppearance(defaultAppearance)}>恢复默认</button></div><p className="hint">球衣自动跟随球队颜色。外观不影响能力与天赋。</p><button className="primary full-button" onClick={()=>{setAppearance(editAppearance);setModal(null);}}>保存形象</button></Modal>}
    {wheel&&<Modal title={"转盘决定"+wheel.label} onClose={()=>{if(!wheel.spinning)setWheel(null);}}><p className="hint">{wheel.min}–{wheel.max} 之间，每个数值等概率。</p><div className={"wheel "+(wheel.spinning?"spinning":"")}><div className="wheel-pointer">▼</div><div className="wheel-center"><strong aria-live="polite">{wheel.value}</strong><span>{wheel.label}</span></div></div><button className="primary full-button" disabled={wheel.spinning} onClick={()=>{if(wheel.result){setInput(v=>({...v,[wheel.field]:wheel.value,wingspan:wheel.field==="height"?clamp(v.wingspan,wheel.value-12,wheel.value+26):wheel.field==="wingspan"?wheel.value:v.wingspan}));setPlayer(null);setWheel(null);}else setWheel(w=>w?{...w,spinning:true}:null);}}>{wheel.spinning?"转盘进行中…":wheel.result?"使用这个数值":"开始转盘"}</button></Modal>}
    {modal==="save"&&<Modal title="本地存档" onClose={()=>setModal(null)}><p className="hint">完整比赛记录自动保存在本机大容量存档中。旧版备份会保留；导出 JSON 文件可以备份或在另一台设备导入。</p><div className="button-row"><button disabled={!career} onClick={exportSave}><Download size={16}/>导出当前生涯</button><button onClick={()=>fileRef.current?.click()}><Upload size={16}/>导入存档</button><input ref={fileRef} hidden type="file" accept=".json,application/json" onChange={e=>{void importSave(e.target.files?.[0]);e.target.value="";}}/></div><h3>我的生涯 · {saves.length}</h3>{saves.length?saves.map(s=><div className="save-entry" key={s.id}><PixelPlayer appearance={s.appearance} name={s.career.player.name} number={s.career.player.number} size={40}/><div><strong>{s.career.player.name}</strong><small>{s.career.team} · {seasonName(s.career.season)} · 总评 {overall(s.career.player)}</small></div><button onClick={()=>{setCareer(s.career);setAppearance(s.appearance);setSaveId(s.id);setModal(null);navigate("生涯主页");}}>继续</button></div>):<p className="hint">创建球员并开始生涯后，将自动建立存档。</p>}<button className="full-button" onClick={()=>setModal("new")}>新建生涯</button></Modal>}
    {modal==="new"&&<Modal title="新的篮球故事" onClose={()=>setModal(null)}><p>当前生涯会保留在本机存档。若上方提示保存失败，请先导出备份。准备好创建另一位球员了吗？</p><div className="two-buttons"><button onClick={()=>setModal(null)}>返回</button><button className="primary" onClick={()=>{setCareer(null);setRecruiting(false);setPlayer(null);setInput(initialInput);setAppearance(defaultAppearance);setSaveId("");setModal(null);contentRef.current?.scrollTo({top:0});}}>创建新球员</button></div></Modal>}
    {modal==="updates"&&<Modal title="训练小游戏、能力与生涯更新" onClose={()=>setModal(null)}><div className="eyebrow">本地版 · CAREER UPDATE</div>{[["01 · 七项训练小游戏","投篮、突破、组织、防守、篮板、身体、罚球。每局8秒，按表现评为C、B、A或S，决定训练点奖励与体力消耗。也可跳过领取基础训练点。"],["02 · 训练点自由分配","七个训练板块分别积攒，在球员能力页面升级16项独立能力。剩余点数跨月、跨季保留。"],["03 · 大学到职业生涯","可从大学选秀进入 NBA，也可直接创建职业新秀。82场常规赛、附加赛、七场四胜季后赛、赛季奖项、伤病恢复、合同与交易、成长衰退及退役均免费开放。"],["04 · 免费与离线","游戏展示前必须配置个人 DeepSeek Key，所有生涯由 AI 托管。AI 调用按个人账户计费，Key 不进入存档。"]].map(([title,body])=><section className="update-item" key={title}><h3>{title}</h3><p>{body}</p></section>)}<button className="primary full-button" onClick={()=>setModal(null)}>我已了解 · 关闭公告</button></Modal>}
    {modal==="about"&&<Modal title="关于本地版" onClose={()=>setModal(null)}><h3>KBA 生涯模式 · 本地重制</h3><p>根据 lanqiushengya.com 可见界面重制，保留像素风格、球员创建与生涯玩法。</p><p className="hint">每次打开游戏都必须先验证个人 DeepSeek Key，已有存档也不例外。AI 自动逐场安排比赛与成长、评奖及故事，API 使用按你的账户计费。比分和成长仍经过本地规则校验，所有存档在本机保存，Key 仅存于页面内存。已参考原站的创建、大学招募与生涯页面；付费职业页面尚未解锁核对。</p><p className="hint">参考站品牌与素材归原作者所有。本项目用于本地学习与个人体验。</p><a href="https://lanqiushengya.com/" target="_blank" rel="noreferrer">访问原站 ↗</a></Modal>}
    {!ready&&<div className="loading-line" aria-label="正在读取本机存档"/>}
  </div>;
}

function Empty({title,text}:{title:string;text:string}) { return <div className="empty-state"><Award size={42}/><h3>{title}</h3><p>{text}</p></div>; }

