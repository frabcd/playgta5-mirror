"use client";

import { useState } from "react";
import { overall, type Career } from "@/lib/lanqiushengya/engine";
import { getRoster, getRosterSource } from "@/lib/lanqiushengya/rosters";
import styles from "./nba-dashboard.module.css";

export function TeamRoster({ career, team = career.team }: { career: Career; team?: string }) {
  const [search, setSearch] = useState("");
  const [position, setPosition] = useState("全部");
  const roster = getRoster(team, career.season);
  const source = getRosterSource(team);
  const shown = roster.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) && (position === "全部" || p.position === position));
  return <section className={styles.panel}><div className={styles.heading}><h3>{team} · 球队阵容</h3><span className={styles.badge}>{roster.filter(p => !p.generated).length} 名真实球员</span></div><p className={styles.muted}>{source ? <><a href={source.url} target="_blank" rel="noreferrer">官方名单 · {source.season}</a>　资料日期 {source.retrieved}。能力与细分位置为游戏估计，后续年份按生涯模拟。</> : "该队尚未收录核实名单。"}</p><div className={styles.filters}><input aria-label="搜索球员" placeholder="搜索球员姓名" value={search} onChange={e => setSearch(e.target.value)} /><select aria-label="位置筛选" value={position} onChange={e => setPosition(e.target.value)}>{["全部","PG","SG","SF","PF","C"].map(p => <option key={p}>{p}</option>)}</select></div><div className={styles.tableWrap}><table><thead><tr><th>球员</th><th>号码</th><th>位置</th><th>能力</th><th>身高</th><th>身份</th></tr></thead><tbody>{team === career.team && <tr className={styles.own}><td>{career.player.name} · 你</td><td>#{career.player.number}</td><td>{career.player.position}</td><td>{overall(career.player)}</td><td>{career.player.height} cm</td><td>生涯球员</td></tr>}{shown.map(p => <tr key={p.id}><td>{p.name}</td><td>{p.number ? `#${p.number}` : "—"}</td><td title={p.listedPosition}>{p.position}</td><td>{p.rating}</td><td>{p.height ? `${p.height} cm` : "—"}</td><td>{p.generated ? "模拟新生" : p.classYear || "真实球员"}</td></tr>)}</tbody></table></div>{!shown.length && <p className={styles.muted}>没有符合条件的球员。</p>}</section>;
}
