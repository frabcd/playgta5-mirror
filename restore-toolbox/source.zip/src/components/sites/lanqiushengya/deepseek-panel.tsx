"use client";
import { useEffect, useEffectEvent, useRef, useState } from 'react';
import { nextRegularMatch, SEASON_LENGTH, simulateGames, upgrade, type Career } from '@/lib/lanqiushengya/engine';
import { pendingNbaMatch, playNbaPostseasonGame } from '@/lib/lanqiushengya/nba';
import { pendingNcaaMatch, advanceNcaaPostseason } from '@/lib/lanqiushengya/ncaa';
import { DEFAULT_AI_MODEL, careerFacts, deepseekJson, generateReport, judgeAwards, planMatch, planDevelopment, manageOffseason, type AiConfig, type AiKind, type AiReport } from '@/lib/lanqiushengya/deepseek';
import styles from './nba-dashboard.module.css';

export function DeepSeekSetup({config,onReady,onClose}:{config:AiConfig|null;onReady:(c:AiConfig|null)=>void;onClose?:()=>void}) {
  const [key,setKey]=useState(''),[model,setModel]=useState(config?.model??DEFAULT_AI_MODEL),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const request=useRef<AbortController|null>(null);
  useEffect(()=>()=>request.current?.abort(),[]);
  async function connect(){if(busy||!key.trim())return;setBusy(true);setError('');const controller=new AbortController();request.current=controller;try{const next={key:key.trim(),model};const data=await deepseekJson(next,'这是连接测试。仅输出 JSON {"ok":true}。',{test:true},controller.signal);if(data.ok!==true)throw new Error('连接成功，但模型未通过 JSON 响应测试。');if(controller.signal.aborted)return;onReady(next);setKey('');onClose?.();}catch(e){if(!controller.signal.aborted)setError(e instanceof Error?e.message:'连接失败。');}finally{if(request.current===controller)setBusy(false);}}
  return <section className={styles.panel} aria-label="DeepSeek 配置"><div className={styles.eyebrow}>YOUR OWN AI · DEEPSEEK</div><h2>让 AI 陪你走完篮球生涯</h2><p>游戏展示前必须先配置并验证你的 DeepSeek API，包括已有存档。连接后创建或继续生涯，AI 自动接管逐场模拟、成长与剧情；可以随时暂停。AI 会分析实力与选秀前景、托管比赛方案、匿名评审赛季奖项，并根据真实游戏经历写故事。</p><p className={styles.note}>API Key 不会保存在本网站云端（包括 Cloudflare），也不会写入浏览器持久存储、游戏存档或导出文件。Key 仅保留在当前页面内存，刷新或关闭页面后需要重新填写。调用时，浏览器将 Key 直接发送给 DeepSeek 官方接口用于验证，并发送生成内容所需的游戏资料；这些请求受 DeepSeek 的数据政策约束。费用由你的 DeepSeek 账户承担，测试连接也会产生一次少量调用。</p><label className={styles.label}>你的 API Key<input aria-label="DeepSeek API Key" type="password" autoComplete="off" spellCheck={false} value={key} onChange={e=>setKey(e.target.value)} disabled={busy} maxLength={256}/></label><label className={styles.label}>模型<select aria-label="DeepSeek 模型" value={model} onChange={e=>setModel(e.target.value)} disabled={busy}><option value="deepseek-flash">DeepSeek Flash</option><option value="deepseek-v4-pro">DeepSeek V4 Pro</option></select></label><p><a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noreferrer">去 DeepSeek 创建自己的 Key ↗</a></p><div className={styles.actions}><button className={styles.primary} disabled={busy||!key.trim()} onClick={()=>void connect()}>{busy?'正在测试连接…':'测试连接并启用'}</button>{busy&&<button onClick={()=>{request.current?.abort();setBusy(false);}}>取消</button>}{config&&<button onClick={()=>{request.current?.abort();setKey('');onReady(null);}}>断开并清除 Key</button>}{onClose&&<button onClick={onClose}>返回游戏</button>}</div>{error&&<p role="alert">{error}</p>}<p className={styles.muted}>每次请求独立上下文。奖项评审看匿名候选数据；故事不参与评奖，也不能改变比分和荣誉。</p></section>;
}
export function AiReportView({report}:{report:AiReport}) {
  return <article className={styles.panel}><div className={styles.eyebrow}>DEEPSEEK · {report.season} · 第 {report.game} 场</div><h3>{report.title}</h3><p style={{whiteSpace:'pre-wrap'}}>{report.summary}</p>{report.role&&<p><strong>实力定位：</strong>{report.role}</p>}{report.draft&&<p><strong>选秀 / 职业前景：</strong>{report.draft}</p>}{[['优势',report.strengths],['短板',report.weaknesses],['训练建议',report.training]].map(([title,items])=>Array.isArray(items)&&items.length>0&&<div key={String(title)}><h4>{title}</h4><ul>{items.map((line,i)=><li key={i}>{line}</li>)}</ul></div>)}{report.story&&<div className="ai-story-text">{report.story.split(/\n\s*\n/).map((p,i)=><p key={i} style={{whiteSpace:'pre-wrap'}}>{p}</p>)}</div>}<p className={styles.muted}>AI 生成 · 以游戏记录为事实基础；场景和对话属于原创虚构，预测不等于实际选秀结果。</p></article>;
}
export function AiCareerPanel({career,config,onChange,onConfigure}:{career:Career;config:AiConfig|null;onChange:(c:Career)=>void;onConfigure:()=>void}) {
  const [busy,setBusy]=useState(''),[error,setError]=useState(''),[filter,setFilter]=useState('all');
  const [auto,setAuto]=useState(true);
  const request=useRef<AbortController|null>(null);
  const expected=useRef(career);
  useEffect(()=>()=>request.current?.abort(),[]);
  useEffect(()=>{if(career!==expected.current){request.current?.abort();expected.current=career;}},[career]);
  function commit(next:Career){expected.current=next;onChange(next);}
  const finish=career.phase==='retired'||(career.game>=SEASON_LENGTH[career.phase]&&(career.phase==='college'?career.ncaa?.stage:career.nba?.stage)==='complete');
  async function run(task:AiKind|'host'|'jury'|'offseason'){
    if(!config){onConfigure();return;}if(busy||request.current)return;const controller=new AbortController();request.current=controller;setBusy(task);setError('');
    let next=career;
    try {
      if(task==='host'){
        if(finish)throw new Error('本赛季已结束，请先安排休赛期。');
        const outstanding=(career.phase==='college'?career.ncaa?.awards:career.nba?.awards)?.filter(a=>a.candidates?.length&&!(career.aiJudged??[]).includes(`${career.season}:${a.name}`))??[];
        if(outstanding.length){next=applyJury(career,await judgeAwards(config,outstanding,controller.signal));if(!controller.signal.aborted)commit(next);return;}
        const regular=career.game<SEASON_LENGTH[career.phase];
        const match=regular?nextRegularMatch(career):career.phase==='nba'?pendingNbaMatch(career):pendingNcaaMatch(career);
        if(match){const plan=await planMatch(config,career,match.opponent,match.home,controller.signal);const rating=await planDevelopment(config,career,controller.signal);const prepared={...upgrade(career,rating),simulationPlan:plan};next=regular?simulateGames(prepared,1,plan.tactic):career.phase==='nba'?playNbaPostseasonGame(prepared,plan.tactic):advanceNcaaPostseason(prepared,plan.tactic);delete next.simulationPlan;next={...next,log:[`AI 比赛导演：${plan.reason}`,...next.log].slice(0,100)};}
        else next=career.phase==='nba'?playNbaPostseasonGame(career):advanceNcaaPostseason(career);
        if(controller.signal.aborted)return;
        commit(next);
        const fresh=(next.phase==='college'?next.ncaa?.awards:next.nba?.awards)?.filter(a=>!(career.aiJudged??[]).includes(`${career.season}:${a.name}`))??[];
        if(fresh.some(a=>a.candidates?.length)){
          setBusy('匿名评审奖项');const judged=await judgeAwards(config,fresh,controller.signal);next=applyJury(next,judged);if(!controller.signal.aborted)commit(next);
        }
        setBusy('书写赛后故事');
        // Commit the game even if narration fails; never pretend a failed story was generated.
        try{const report=await generateReport(config,'story',next,controller.signal);next=addReport(next,report);}catch(e){if(controller.signal.aborted)throw e;setAuto(false);setError('比赛已完成，故事生成失败，自动托管已暂停。可单独重试故事。');}
        if(next.game%10===0&&next.game!==career.game){setBusy('更新球探分析');next=addReport(next,await generateReport(config,next.phase==='college'?'draft':'scout',next,controller.signal));}
        const ended=next.game>=SEASON_LENGTH[next.phase]&&(next.phase==='college'?next.ncaa?.stage:next.nba?.stage)==='complete';if(ended){setAuto(false);setBusy('赛季复盘');next=addReport(next,await generateReport(config,'review',next,controller.signal));}
      } else if(task==='offseason'){
        setAuto(false);next=await manageOffseason(config,career,controller.signal);if(controller.signal.aborted)return;commit(next);next=addReport(next,await generateReport(config,'story',next,controller.signal));
      } else if(task==='jury'){
        const awards=(career.phase==='college'?career.ncaa?.awards:career.nba?.awards)?.filter(a=>!(career.aiJudged??[]).includes(`${career.season}:${a.name}`))??[];
        if(!awards.some(a=>a.candidates?.length))throw new Error('没有待评审的赛季奖项。完成赛季后可评审；旧版无候选数据的奖项保留原结果。');
        next=applyJury(career,await judgeAwards(config,awards,controller.signal));
      }else next=addReport(career,await generateReport(config,task,career,controller.signal));
      if(!controller.signal.aborted)commit(next);
    }catch(e){if(!controller.signal.aborted){setAuto(false);setError((e instanceof Error?e.message:'AI 请求失败。')+' 自动托管已暂停，已结算进度保留。');}}finally{if(request.current===controller){request.current=null;setBusy('');}}
  }
  const autoStep=useEffectEvent(()=>{void run('host');});
  useEffect(()=>{if(!auto||busy||finish||!config)return;const timer=setTimeout(()=>autoStep(),3000);return()=>clearTimeout(timer);},[auto,busy,finish,config,career]);
  function pause(){setAuto(false);request.current?.abort();}
  const records=(career.aiReports??[]).filter(r=>filter==='all'||r.kind===filter).slice().reverse();
  return <div className={styles.dashboard}><section className={styles.panel}><div className={styles.heading}><h2>AI 生涯导演</h2><button onClick={onConfigure}>{config?'API 设置 / 清除 Key':'配置 DeepSeek API'}</button></div><p>AI 自动逐场安排战术与能力成长、评审奖项并写故事；每 10 场更新分析。每场通常调用 3 次，评奖与复盘另计，持续使用你的 API 额度。请求失败或赛季结束会暂停，离开游戏会中止后续请求。</p><p className={styles.note}>比赛、评奖、故事使用隔离上下文。AI 不能指定赢家或任意改比分；比赛由可校验的投篮与能力规则结算。匿名评审只接受合格候选，统计王按数据排序，评审完成后锁定，避免反复抽奖。</p><details><summary>本次将发送哪些游戏资料？</summary><p>分析与故事：球员设定、能力、战绩、近 5 场数据、合同伤病和最近经历。故事额外读取最近两篇虚构章节。评奖：匿名出勤、数据和评选分，不发送姓名、玩家标识、剧情或 Key 到提示词。</p><pre className="ai-facts">{JSON.stringify(careerFacts(career),null,2)}</pre></details><p role="status">{career.player.name} · {career.team} · {career.season} 赛季 · 常规赛 {career.game}/{SEASON_LENGTH[career.phase]} · {auto&&!finish?"自动托管中":"已暂停"}</p><div className={styles.actions}><button className={styles.primary} disabled={finish} onClick={()=>{if(auto)pause();else{setError('');setAuto(true);}}}>{finish?'赛季已结束':auto?'暂停自动托管':'继续自动托管'}</button>{finish&&career.phase!=='retired'&&<button disabled={!!busy} onClick={()=>void run('offseason')}>AI 安排休赛期与下一季</button>}{([['host','AI 托管下一场'],['scout','分析实力与定位'],['draft','分析选秀前景'],['story','写一章真实感故事'],['review','赛季深度复盘'],['jury','AI 匿名评审奖项']] as const).map(([task,label])=><button className={task==='host'?styles.primary:''} key={task} disabled={!!busy||(auto&&!finish)||(task==='host'&&finish)} onClick={()=>void run(task)}>{label}</button>)}{busy&&<button onClick={()=>{pause();setError('已取消后续请求；已结算的比赛会保留，尚未完成的 AI 结果不会应用。');}}>取消请求</button>}</div>{busy&&<p role="status">AI 正在处理：{busy}… 每个阶段最多等待 60 秒。</p>}{error&&<p role="alert">{error}</p>}<label>手记筛选<select aria-label="AI 手记筛选" value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">全部</option><option value="story">故事</option><option value="scout">球探分析</option><option value="draft">选秀</option><option value="review">复盘</option></select></label><p className={styles.muted}>最近 60 篇 AI 内容随本机存档保存；API Key 不在本网站云端储存，仅留在当前页面内存。每次点击会使用你的 DeepSeek API 额度。</p></section>{records.map(r=><AiReportView key={r.id} report={r}/>)}{!records.length&&<p className={styles.empty}>你的 AI 生涯手记将从这里开始。</p>}</div>;
}
function addReport(c:Career,report:AiReport):Career{return {...c,aiReports:[...(c.aiReports??[]),report].slice(-60)};}
function applyJury(c:Career,awards:NonNullable<Career['nba']>['awards']):Career{
  const league=c.phase==='college'?c.ncaa:c.nba;if(!league)return c;const labels=awards.map(a=>c.season+' '+a.name);
  const mapped=league.awards.map(a=>({...a,...(awards.find(j=>j.name===a.name)??{})}));
  return {...c,...(c.phase==='college'?{ncaa:{...c.ncaa!,awards:mapped as NonNullable<Career['ncaa']>['awards']}}:{nba:{...c.nba!,awards:mapped}}),honors:[...new Set([...c.honors.filter(h=>!labels.includes(h)),...awards.filter(a=>a.player).map(a=>c.season+' '+a.name)])],aiJudged:[...(c.aiJudged??[]),...awards.map(a=>c.season+':'+a.name)]};
}
