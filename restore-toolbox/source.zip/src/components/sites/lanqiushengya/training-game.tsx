"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import styles from "./training-game.module.css";

type Group = "shooting" | "finishing" | "playmaking" | "defense" | "rebounding" | "physical" | "freeThrow";
type Grade = "C" | "B" | "A" | "S";
const labels: Record<Group, [string, string]> = {
  shooting: ["定点投篮", "在光标进入绿色区域时投篮。按空格或点击投篮。"],
  freeThrow: ["罚球训练", "瞄准中央的窄绿色区域，把握出手节奏。按空格或点击出手。"],
  finishing: ["突破终结", "观察防守者，选择空出的左侧或右侧突破。支持方向键。"],
  playmaking: ["传球视野", "把球传给亮起的队友。点击队友或按数字 1、2、3。"],
  defense: ["防守反应", "等待对手起跳后再封盖！按空格或点击封盖。"],
  rebounding: ["篮板判断", "篮球进入中央篮板区域时起跳。按空格或点击抢板。"],
  physical: ["体能冲刺", "交替点击左右脚，保持跑动节奏。支持左右方向键。"],
};

export function TrainingGame({ group, onFinish, onCancel }: { group: Group; onFinish: (grade: Grade) => void; onCancel: () => void }) {
  const [phase, setPhase] = useState<"ready" | "playing" | "done">("ready");
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState({ hits: 0, attempts: 0 });
  const [feedback, setFeedback] = useState("准备开始");
  const [claimed, setClaimed] = useState(false);
  const started = useRef(0);
  const lastAction = useRef(-1000);
  const lastSide = useRef("");
  const claimedRef = useRef(false);
  const livePhase = useRef(phase);
  const bucket = useRef(-1);
  const position = 50 + Math.sin(elapsed / (group === "freeThrow" ? 340 : 430)) * 45;
  const target = Math.floor(elapsed / 900) % 3;
  const defender = Math.floor(elapsed / 1100) % 2;
  const jumping = elapsed % 1350 >= 780 && elapsed % 1350 < 1200;

  useEffect(() => {
    if (phase !== "playing") return;
    const timer = window.setInterval(() => {
      const time = Math.min(performance.now() - started.current, 8000);
      setElapsed(time);
      if (time >= 8000) { livePhase.current = "done"; setPhase("done"); }
    }, 32);
    return () => window.clearInterval(timer);
  }, [phase]);

  const act = useCallback((input: string) => {
    if (livePhase.current !== "playing") return;
    const time = performance.now() - started.current;
    if (time >= 8000 || time - lastAction.current < 180) return;
    lastAction.current = time;
    let hit = false;
    if (group === "physical") {
      hit = (input === "left" || input === "right") && input !== lastSide.current;
      lastSide.current = input;
    } else if (group === "finishing") {
      hit = input === (Math.floor(time / 1100) % 2 === 0 ? "right" : "left");
    } else if (group === "playmaking") {
      hit = input === String(Math.floor(time / 900) % 3 + 1);
    } else if (group === "defense") {
      const round = Math.floor(time / 1350);
      hit = time % 1350 >= 780 && time % 1350 < 1200 && bucket.current !== round;
      if (hit) bucket.current = round;
    } else {
      const pos = 50 + Math.sin(time / (group === "freeThrow" ? 340 : 430)) * 45;
      hit = Math.abs(pos - 50) <= (group === "freeThrow" ? 9 : group === "rebounding" ? 17 : 14);
    }
    setResult(previous => ({ hits: previous.hits + Number(hit), attempts: previous.attempts + 1 }));
    setFeedback(hit ? "漂亮！ +1" : "调整节奏，再来一次");
  }, [group]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (livePhase.current !== "playing" || event.repeat) return;
      const key = event.key;
      const input = key === "ArrowLeft" || key.toLowerCase() === "a" ? "left" : key === "ArrowRight" || key.toLowerCase() === "d" ? "right" : key;
      const valid = group === "physical" || group === "finishing" ? ["left", "right"].includes(input) : group === "playmaking" ? ["1", "2", "3"].includes(input) : input === " ";
      if (valid) { event.preventDefault(); act(input); }
    };
    window.addEventListener("keydown", keydown);
    return () => window.removeEventListener("keydown", keydown);
  }, [act, group]);

  const ratio = result.hits / Math.max(result.attempts, 1);
  const minimum = group === "physical" ? 12 : group === "defense" ? 3 : 5;
  const grade: Grade = result.hits >= minimum && ratio >= .8 ? "S" : result.hits >= Math.ceil(minimum * .65) && ratio >= .6 ? "A" : result.hits >= 2 && ratio >= .35 ? "B" : "C";
  const claim = (value: Grade) => {
    if (claimedRef.current) return;
    claimedRef.current = true;
    livePhase.current = "done";
    setClaimed(true);
    onFinish(value);
  };
  const start = () => {
    started.current = performance.now();
    livePhase.current = "playing";
    setPhase("playing");
    setFeedback("训练开始！");
  };

  return <section className={styles.game} aria-label={`${labels[group][0]}小游戏`}>
    <div className={styles.heading}><span>本地练习 · 8 秒挑战</span><button onClick={onCancel} aria-label="关闭训练">×</button></div>
    <h2>{labels[group][0]}</h2>
    <p>{labels[group][1]}</p>
    {phase === "ready" ? <div className={styles.ready}><div className={styles.bigBall}>◉</div><p>准备好了吗？训练表现决定本次评级。</p><button className={styles.primary} onClick={start}>开始训练</button><button onClick={() => claim("C")} disabled={claimed}>跳过挑战 · C 级</button></div> : <>
      <div className={styles.stats}><strong>剩余 {Math.ceil((8000 - elapsed) / 1000)} 秒</strong><span>成功 {result.hits} / 尝试 {result.attempts}</span></div>
      <div className={styles.clock}><div style={{ width: `${100 - elapsed / 80}%` }} /></div>
      <div className={styles.court}>
        <div className={styles.hoop}>▱<span>└─┘</span></div>
        {(group === "shooting" || group === "freeThrow") && <div className={styles.meter}><div className={styles.target} style={{ left: group === "freeThrow" ? "41%" : "36%", width: group === "freeThrow" ? "18%" : "28%" }} /><div className={styles.marker} style={{ left: `${position}%` }} /> <small>瞄准绿色区域</small></div>}
        {group === "rebounding" && <><div className={styles.catchZone}>篮板区域</div><div className={styles.movingBall} style={{ left: `${position}%` }}>●</div></>}
        {group === "finishing" && <div className={styles.lanes}><span>{defender === 0 ? "▟ 防守" : "↑ 空位"}</span><span>{defender === 1 ? "防守 ▙" : "空位 ↑"}</span></div>}
        {group === "playmaking" && <div className={styles.teammates}>{[0, 1, 2].map(index => <button key={index} className={target === index ? styles.open : ""} disabled={phase !== "playing"} onClick={() => act(String(index + 1))}><span>♟</span>{index + 1} 号{target === index ? " · 空位" : ""}</button>)}</div>}
        {group === "defense" && <div className={`${styles.opponent} ${jumping ? styles.jumping : ""}`}><span>●</span><strong>♟</strong><b>{jumping ? "现在封盖！" : "等待起跳…"}</b></div>}
        {group === "physical" && <div className={styles.runner}>♟<div>{Array.from({ length: Math.min(result.hits, 20) }, (_, i) => <span key={i}>▰</span>)}</div><small>左右交替，保持节奏</small></div>}
      </div>
      <div className={styles.feedback} role="status">{phase === "done" ? "训练结束" : feedback}</div>
      {phase === "playing" && <div className={styles.controls}>{group === "physical" || group === "finishing" ? <><button onClick={() => act("left")}>← {group === "physical" ? "左脚" : "向左突破"}</button><button onClick={() => act("right")}>{group === "physical" ? "右脚" : "向右突破"} →</button></> : group !== "playmaking" && <button className={styles.primary} onClick={() => act(" ")}>{group === "defense" ? "起跳封盖" : group === "rebounding" ? "起跳抢板" : "出手投篮"} <small>空格</small></button>}</div>}
      {phase === "done" && <div className={styles.result}><strong>{grade}</strong><span>{grade === "S" ? "完美发挥！" : grade === "A" ? "表现出色！" : grade === "B" ? "稳步进步！" : "继续努力！"}</span><button className={styles.primary} disabled={claimed} onClick={() => claim(grade)}>领取训练成果</button></div>}
    </>}
  </section>;
}
