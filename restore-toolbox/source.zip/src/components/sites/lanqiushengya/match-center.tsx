"use client";

import { useState } from "react";
import type { GameResult } from "@/lib/lanqiushengya/engine";
import styles from "./match-center.module.css";

export type MatchTactic = "balanced" | "scoring" | "playmaking" | "defense";
const tactics: [MatchTactic, string, string][] = [["balanced", "均衡发挥", "维持攻防平衡"], ["scoring", "主动得分", "增加个人出手，争取突破"], ["playmaking", "组织串联", "更多传球，创造队友机会"], ["defense", "防守优先", "专注抢断、篮板与护筐"]];
export function MatchBoxScore({ game }: { game: GameResult }) {
  const [side, setSide] = useState<"team" | "opponent">("team");
  if (!game.boxScore) return null;
  return <section className={styles.box}><h3>双方球员数据</h3><div className={styles.actions}><button aria-pressed={side === "team"} onClick={() => setSide("team")}>{game.team ?? "本队"}</button><button aria-pressed={side === "opponent"} onClick={() => setSide("opponent")}>{game.opponent}</button></div><div className={styles.tableScroll}><table><thead><tr><th>球员</th><th>位置</th><th>分钟</th><th>得分</th><th>篮板</th><th>助攻</th><th>抢断</th><th>盖帽</th><th>失误</th><th>投篮</th><th>三分</th><th>罚球</th></tr></thead><tbody>{game.boxScore[side].map(p => <tr key={p.id} className={p.isUser ? styles.userRow : ""}><td>{p.name}{p.isUser ? " · 你" : ""}<small>{p.started ? "首发" : "替补"}{p.generated ? " · 模拟球员" : ""}</small></td><td>{p.position}</td><td>{p.min}</td><td>{p.pts}</td><td>{p.reb}</td><td>{p.ast}</td><td>{p.stl}</td><td>{p.blk}</td><td>{p.to}</td><td>{p.fgm}/{p.fga}</td><td>{p.tpm}/{p.tpa}</td><td>{p.ftm}/{p.fta}</td></tr>)}</tbody></table></div><p className={styles.note}>名单参考官方资料；所有本场统计由生涯游戏模拟。未收录真实名单的球队显示模拟球员。</p></section>;
}
export function MatchTimeline({ game, showPeriods = true }: { game: GameResult; showPeriods?: boolean }) {
  return <>{showPeriods && <div className={styles.periods}>{game.periods?.map((p, i) => <div key={i}><span>{p.label}</span><b>{p.team} : {p.opponent}</b></div>)}</div>}{!!game.playByPlay?.length && <details className={styles.feed}><summary>比赛进程 · {game.playByPlay.length} 条记录</summary>{game.playByPlay.map((event, i) => <p key={i}><small>{event.period} · {event.clock}</small><b>{event.teamScore}–{event.opponentScore}</b><span>{event.text}</span></p>)}</details>}</>;
}
export function MatchCenter({ team, opponent, label, home = true, onPlay, onClose }: { team: string; opponent: string; label: string; home?: boolean; onPlay: (tactic: MatchTactic) => GameResult | undefined; onClose: () => void }) {
  const [tactic, setTactic] = useState<MatchTactic>("balanced");
  const [result, setResult] = useState<GameResult>();
  const [step, setStep] = useState(0);
  const periods = result?.periods ?? [];
  const finished = !!result && step >= periods.length;
  const shown = periods.slice(0, step);
  const score = result ? [finished ? result.teamScore : shown.reduce((s, p) => s + p.team, 0), finished ? result.opponentScore : shown.reduce((s, p) => s + p.opponent, 0)] : null;
  return <div className={styles.overlay}><section className={styles.modal} role="dialog" aria-modal="true" aria-label="比赛中心"><header><span>{label} · {home ? "主场" : "客场"}</span><button onClick={onClose}>{result && !finished ? "保存并返回" : "关闭"}</button></header><h2>比赛中心</h2><div className={styles.scoreboard}><strong>{team}</strong><b>{score ? `${score[0]} : ${score[1]}` : "VS"}</b><strong>{opponent}</strong></div>
    {!result ? <><h3>本场战术</h3><div className={styles.tactics}>{tactics.map(([key, name, description]) => <button key={key} aria-pressed={tactic === key} className={tactic === key ? styles.active : ""} onClick={() => setTactic(key)}><b>{name}</b><small>{description}</small></button>)}</div><p className={styles.note}>选择本场打法后开始模拟。每次只结算这一场比赛，赛后数据自动保存。</p><button className={styles.primary} onClick={() => { const game = onPlay(tactic); if (game) { setResult(game); setStep(1); } }}>开始本场比赛 →</button></> : <><p className={styles.status}>{finished ? `${result.won ? "比赛胜利" : "比赛失利"} · 终场` : `${periods[step - 1]?.label ?? "比赛"}结束`}</p><div className={styles.periods}>{shown.map((p, i) => <div key={i}><span>{p.label}</span><b>{p.team} : {p.opponent}</b></div>)}</div>{!finished ? <><p className={styles.note}>比赛已结算并保存，按节查看比赛过程。</p><div className={styles.actions}><button className={styles.primary} onClick={() => setStep(step + 1)}>查看下一节 →</button><button onClick={() => setStep(periods.length)}>查看终场回顾</button></div></> : <><div className={styles.stats}>{[["得分",result.pts],["篮板",result.reb],["助攻",result.ast],["抢断",result.stl],["盖帽",result.blk],["失误",result.to ?? "—"]].map(([name, value]) => <div key={name}><span>{name}</span><b>{value}</b></div>)}</div><p className={styles.note}>{result.min} 分钟 · 投篮 {result.fgm}/{result.fga} · 三分 {result.tpm}/{result.tpa} · 罚球 {result.ftm}/{result.fta}</p><MatchTimeline game={result} showPeriods={false} /><MatchBoxScore game={result} /><button className={styles.primary} onClick={onClose}>返回赛季旅程</button></>}</>}
  </section></div>;
}
