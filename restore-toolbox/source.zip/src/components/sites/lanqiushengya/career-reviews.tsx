"use client";

import { useState } from "react";
import type { Career, GameResult } from "@/lib/lanqiushengya/engine";
import { MatchTimeline, MatchBoxScore } from "./match-center";
import styles from "./career-reviews.module.css";

type ReviewGame = GameResult & { to?: number; started?: boolean; phase?: "college" | "nba"; stage?: string; shots?: { x: number; y: number; made: boolean; three: boolean }[] };
const stats = [["pts", "得分"], ["reb", "篮板"], ["ast", "助攻"], ["stl", "抢断"], ["blk", "盖帽"], ["to", "失误"]] as const;
const seasonName = (season: number) => `${season}–${String(season + 1).slice(-2)}`;
const percent = (made: number, attempted: number) => attempted ? `${(100 * made / attempted).toFixed(1)}%` : "—";
const stageName = (game: ReviewGame) => game.stage === "playoffs" ? "季后赛" : game.stage === "playin" ? "附加赛" : game.stage === "conference" ? "联盟锦标赛" : game.stage === "national" ? "全国锦标赛" : "常规赛";
function allGames(career: Career): ReviewGame[] {
  const games = [...career.games, ...(career.nba?.playoffGames ?? []), ...(career.nbaHistory ?? []).flatMap(record => record.playoffGames), ...(career.ncaa?.postseasonGames ?? []), ...(career.ncaaHistory ?? []).flatMap(record => record.postseasonGames)];
  return Array.from(new Map(games.map(game => [game.id, game])).values());
}
function competition(career: Career, game: ReviewGame) {
  return game.phase ?? career.history.find(record => record.season === game.season)?.phase ?? (career.phase === "college" ? "college" : "nba");
}
function SumStats({ games, totals = false }: { games: ReviewGame[]; totals?: boolean }) {
  games = games.filter(game => game.min > 0);
  const sum = (key: keyof ReviewGame) => games.reduce((total, game) => total + Number(game[key] ?? 0), 0);
  const value = (key: keyof ReviewGame) => totals ? sum(key) : (sum(key) / Math.max(1, games.length)).toFixed(1);
  const hasTurnovers = games.every(game => game.to !== undefined);
  const multi = (game: ReviewGame) => [game.pts, game.reb, game.ast, game.stl, game.blk].filter(n => n >= 10).length;
  return <>
    <div className={styles.stats}>{stats.map(([key, label]) => <div key={key}><span>{totals ? "总" : "场均"}{label}</span><strong>{key === "to" && !hasTurnovers ? "—" : value(key)}</strong></div>)}</div>
    <div className={styles.metrics}><span>出场 <b>{games.length}</b></span><span>首发 <b>{games.every(game => game.started !== undefined) ? games.filter(game => game.started).length : "—"}</b></span><span>{totals ? "总" : "场均"}分钟 <b>{value("min")}</b></span><span>投篮 <b>{sum("fgm")}/{sum("fga")} · {percent(sum("fgm"), sum("fga"))}</b></span><span>三分 <b>{sum("tpm")}/{sum("tpa")} · {percent(sum("tpm"), sum("tpa"))}</b></span><span>罚球 <b>{sum("ftm")}/{sum("fta")} · {percent(sum("ftm"), sum("fta"))}</b></span><span>两双 <b>{games.filter(game => multi(game) >= 2).length}</b></span><span>三双 <b>{games.filter(game => multi(game) >= 3).length}</b></span></div>
  </>;
}
function ShotChart({ games }: { games: ReviewGame[] }) {
  const [mode, setMode] = useState<"attempts" | "heat">("attempts");
  const shots = games.flatMap(game => game.shots ?? []);
  if (!shots.length) return null;
  const bins = Array.from({ length: 25 }, (_, index) => {
    const x = (index % 5) * 20;
    const y = Math.floor(index / 5) * 20;
    const samples = shots.filter(shot => shot.x >= x && shot.x < x + 20 && shot.y >= y && shot.y < y + 20);
    const made = samples.filter(shot => shot.made).length;
    return { x, y, count: samples.length, made, color: samples.length < 5 ? "#c0b7a5" : made / samples.length >= .5 ? "#819a69" : made / samples.length >= .35 ? "#d2b46b" : "#c78771" };
  });
  return <details className={styles.scrapbook}><summary>投篮分布 · {shots.length} 次已记录出手</summary>
    <div className={styles.tabs}><button aria-pressed={mode === "attempts"} onClick={() => setMode("attempts")}>逐次出手</button><button aria-pressed={mode === "heat"} onClick={() => setMode("heat")}>命中率热区</button></div>
    <svg className={styles.court} viewBox="0 0 100 100" role="img" aria-label={`${mode === "attempts" ? "逐次出手" : "命中率热区"}投篮图`}>
      <rect x=".5" y=".5" width="99" height="99" fill="#eee0be" stroke="#ad946c" />
      {mode === "heat" && bins.filter(bin => bin.count).map(bin => <g key={`${bin.x}-${bin.y}`}><rect x={bin.x + .5} y={bin.y + .5} width="19" height="19" fill={bin.color} opacity=".72"><title>{bin.made}/{bin.count} 命中 · {percent(bin.made, bin.count)}{bin.count < 5 ? " · 样本不足" : ""}</title></rect><text x={bin.x + 10} y={bin.y + 11} textAnchor="middle" fontSize="4" fill="#554831">{bin.count < 5 ? `${bin.count}次` : percent(bin.made, bin.count)}</text></g>)}
      <g fill="none" stroke="#ae946b" strokeWidth=".6"><path d="M34 0 V40 H66 V0 M43 8 H57 M7 0 V18 C7 77 93 77 93 18 V0" /><circle cx="50" cy="40" r="12" /><circle cx="50" cy="12" r="2" /><path d="M36 100 A14 14 0 0 1 64 100" /></g>
      {mode === "attempts" && shots.map((shot, index) => <circle key={index} cx={shot.x} cy={shot.y} r="1.1" fill={shot.made ? "#4e7449" : "#a8533e"} opacity=".75"><title>{shot.three ? "三分" : "两分"} · {shot.made ? "命中" : "未中"}</title></circle>)}
    </svg><p className={styles.muted}>{mode === "attempts" ? "绿色为命中，红色为未中。" : "热区：绿 ≥50%，黄 35–49.9%，红 <35%；不足 5 次为灰色。"}仅展示存档中已记录的出手；旧比赛未记录的位置不补造。</p>
  </details>;
}
function GameReview({ game, career, onClose }: { game: ReviewGame; career: Career; onClose: () => void }) {
  const team = game.team ?? career.history.find(record => record.season === game.season)?.team ?? career.team;
  return <section className={styles.review} aria-label="单场比赛回顾">
    <div className={styles.heading}><h3>单场比赛回顾</h3><button onClick={onClose}>收起回顾</button></div>
    <p className={styles.kicker}>{seasonName(game.season)} · {stageName(game)} · {game.home ? "主场" : "客场"}</p>
    <div className={styles.score}><span>{team}</span><strong>{game.teamScore} : {game.opponentScore}</strong><span>{game.opponent}</span></div>
    <p className={game.won ? styles.win : styles.loss}>{game.won ? "胜利" : "失利"} · {game.min} 分钟{game.started === undefined ? "" : game.started ? " · 首发" : " · 替补"}</p>
    <SumStats games={[game]} totals />
    <MatchTimeline game={game} /><MatchBoxScore game={game} />
    <ShotChart games={[game]} />
    <p className={styles.muted}>投篮 {game.fgm}/{game.fga}，其中两分 {game.fgm - game.tpm}/{game.fga - game.tpa}、三分 {game.tpm}/{game.tpa}；罚球 {game.ftm}/{game.fta}。</p>
  </section>;
}
export function MatchRecords({ career }: { career: Career }) {
  const games = allGames(career);
  const seasons = Array.from(new Set([career.season, ...games.map(game => game.season)])).sort((a, b) => b - a);
  const [season, setSeason] = useState(career.season);
  const [stage, setStage] = useState("all");
  const [result, setResult] = useState("all");
  const [selected, setSelected] = useState<string | null>(null);
  const [totals, setTotals] = useState(false);
  const filtered = games.filter(game => game.season === season && (stage === "all" || (game.stage ?? "regular") === stage) && (result === "all" || game.won === (result === "win")));
  const current = filtered.find(game => game.id === selected);
  return <section className={styles.root}>
    <div className={styles.heading}><div><p className={styles.kicker}>GAME LOG</p><h2>比赛记录</h2></div><span className={styles.badge}>{filtered.filter(game => game.won).length} 胜 · {filtered.filter(game => !game.won).length} 负</span></div>
    <div className={styles.filters}><label>赛季<select value={season} onChange={event => { setSeason(Number(event.target.value)); setSelected(null); }}>{seasons.map(year => <option key={year} value={year}>{seasonName(year)}{year === career.season ? " · 本赛季" : ""}</option>)}</select></label><label>阶段<select value={stage} onChange={event => setStage(event.target.value)}><option value="all">全部比赛</option><option value="regular">常规赛</option><option value="conference">联盟锦标赛</option><option value="national">全国锦标赛</option><option value="playin">附加赛</option><option value="playoffs">季后赛</option></select></label><label>结果<select value={result} onChange={event => setResult(event.target.value)}><option value="all">全部结果</option><option value="win">胜利</option><option value="loss">失利</option></select></label><button aria-pressed={totals} onClick={() => setTotals(!totals)}>{totals ? "查看场均" : "查看总计"}</button></div>
    {filtered.length ? <><SumStats games={filtered} totals={totals} /><ShotChart games={filtered} /><p className={styles.muted}>统计对应当前筛选；未出场比赛不计入场均，命中率按总命中 / 总出手计算。三双同时计入两双。旧存档未记录的数据以「—」显示。</p>{current && <GameReview game={current} career={career} onClose={() => setSelected(null)} />}<div className={styles.tableWrap}><table><caption>点击「回顾」查看完整单场数据</caption><thead><tr><th>比赛</th><th>对手 / 阶段</th><th>比分</th><th>分钟</th>{stats.map(([key, label]) => <th key={key}>{label}</th>)}<th>投篮</th><th>三分</th><th>罚球</th></tr></thead><tbody>{[...filtered].reverse().map((game, index) => <tr key={game.id} className={selected === game.id ? styles.selected : undefined}><td><button aria-pressed={selected === game.id} onClick={() => setSelected(game.id)}>回顾 #{filtered.length - index}</button></td><td>{game.home ? "主场" : "客场"} · {game.opponent}<small>{stageName(game)}</small></td><td className={game.won ? styles.win : styles.loss}>{game.won ? "胜" : "负"} {game.teamScore}–{game.opponentScore}</td><td>{game.min}</td>{stats.map(([key]) => <td key={key}>{game[key] ?? "—"}</td>)}<td>{game.fgm}/{game.fga}</td><td>{game.tpm}/{game.tpa}</td><td>{game.ftm}/{game.fta}</td></tr>)}</tbody></table></div></> : <p className={styles.empty}>暂无符合条件的比赛。回到生涯主页，开启你的下一场比赛。</p>}
  </section>;
}
export function CareerArchive({ career }: { career: Career }) {
  const [league, setLeague] = useState<"college" | "nba">(career.phase === "college" ? "college" : "nba");
  const [totals, setTotals] = useState(false);
  const [season, setSeason] = useState<number | null>(null);
  const games = allGames(career).filter(game => competition(career, game) === league);
  const seasons = Array.from(new Set([...games.map(game => game.season), ...career.history.filter(record => record.phase === league).map(record => record.season)])).sort((a, b) => b - a);
  const chosen = season !== null && seasons.includes(season) ? season : null;
  const shown = games.filter(game => chosen === null || game.season === chosen);
  const highs = stats.filter(([key]) => key !== "to").map(([key, label]) => ({ key, label, game: games.reduce<ReviewGame | undefined>((best, game) => !best || game[key]! > best[key]! ? game : best, undefined) }));
  const firstStart = games.find(game => game.started);
  const honors = career.honors.filter(honor => (chosen === null || honor.includes(String(chosen))) && seasons.some(year => honor.includes(String(year))));
  const milestones = league === "nba" ? [...(career.nbaHistory ?? []), ...(career.nba ? [career.nba] : [])].filter(record => chosen === null || record.season === chosen).flatMap(record => record.milestones.map(entry => `${record.season} · ${entry}`)) : [];
  return <section className={styles.root}>
    <div className={styles.heading}><div><p className={styles.kicker}>CAREER ARCHIVE</p><h2>{career.player.name} · 生涯档案</h2></div><span className={styles.badge}>{career.player.position} · #{career.player.number}</span></div>
    <div className={styles.tabs}>{(["college", "nba"] as const).map(item => <button key={item} aria-pressed={league === item} onClick={() => { setLeague(item); setSeason(null); }}>{item === "college" ? "NCAA 大学生涯" : "NBA 职业生涯"}</button>)}<button aria-pressed={totals} onClick={() => setTotals(!totals)}>{totals ? "查看场均" : "查看总计"}</button></div>
    <div className={styles.filters}><label>赛季范围<select value={chosen ?? "all"} onChange={event => setSeason(event.target.value === "all" ? null : Number(event.target.value))}><option value="all">生涯合计</option>{seasons.map(year => <option key={year} value={year}>{seasonName(year)}</option>)}</select></label></div>
    {shown.length ? <SumStats games={shown} totals={totals} /> : <p className={styles.empty}>这段生涯尚未留下比赛记录。</p>}
    <div className={styles.tableWrap}><table><caption>赛季回顾 · 点击赛季筛选上方统计</caption><thead><tr><th>赛季 / 球队</th><th>出场</th><th>战绩</th><th>得分</th><th>篮板</th><th>助攻</th><th>投篮 / 三分 / 罚球</th></tr></thead><tbody>{seasons.map(year => { const seasonGames = games.filter(game => game.season === year); const appearances = seasonGames.filter(game => game.min > 0).length; const record = career.history.find(item => item.season === year); const sum = (key: keyof ReviewGame) => seasonGames.reduce((n, game) => n + Number(game[key] ?? 0), 0); const stat = (key: "pts" | "reb" | "ast") => seasonGames.length ? (totals ? sum(key) : (sum(key) / Math.max(1, appearances)).toFixed(1)) : record ? (totals ? "—" : record[key]) : "—"; return <tr key={year} className={chosen === year ? styles.selected : undefined}><td><button onClick={() => setSeason(year)}>{seasonName(year)}</button><small>{record?.team ?? career.team}{year === career.season ? " · 本赛季" : ""}</small></td><td>{seasonGames.length ? appearances : record?.games || 0}</td><td>{seasonGames.length ? `${seasonGames.filter(game => game.won).length}–${seasonGames.filter(game => !game.won).length}` : `${record?.wins ?? 0}–${record?.losses ?? 0}`}</td><td>{stat("pts")}</td><td>{stat("reb")}</td><td>{stat("ast")}</td><td>{percent(sum("fgm"), sum("fga"))} / {percent(sum("tpm"), sum("tpa"))} / {percent(sum("ftm"), sum("fta"))}</td></tr>; })}</tbody></table></div>
    <div className={styles.columns}><section className={styles.card}><h3>荣誉墙</h3>{honors.length ? <ul className={styles.honors}>{honors.map((honor, index) => <li key={`${honor}-${index}`}>★ {honor}</li>)}</ul> : <p className={styles.muted}>继续比赛，争取你的第一项赛季荣誉。</p>}</section><section className={styles.card}><h3>个人纪录</h3><div className={styles.highs}>{highs.map(({ key, label, game }) => <div key={key}><span>单场{label}</span><strong>{game?.[key] ?? "—"}</strong><small>{game ? `${game.season} · 对阵${game.opponent}` : "暂无记录"}</small></div>)}</div></section></div>
    <details className={styles.scrapbook}><summary>生涯剪贴簿 · 首发与代表作</summary>{firstStart && <p>首次有记录的首发：{firstStart.season} · 对阵{firstStart.opponent} · {firstStart.pts} 分 {firstStart.reb} 篮板 {firstStart.ast} 助攻。</p>}{highs[0]?.game && <p>得分代表作：{highs[0].game.season} · 对阵{highs[0].game.opponent} · {highs[0].game.pts} 分 {highs[0].game.reb} 篮板 {highs[0].game.ast} 助攻 {highs[0].game.stl} 抢断 {highs[0].game.blk} 盖帽，{highs[0].game.teamScore}–{highs[0].game.opponentScore}。</p>}<p className={styles.muted}>比赛记录和个人纪录保存在本地存档中，可导出备份。</p></details>
    <details className={styles.scrapbook}><summary>生涯里程碑与近期动态</summary><ul>{Array.from(new Set([...milestones, ...career.log])).slice(0, 35).map((entry, index) => <li key={index}>{entry}</li>)}</ul></details>
  </section>;
}

