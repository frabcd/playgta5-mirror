"use client";

import { useState } from "react";
import { COLLEGES, NBA_TEAMS, GROUP_LABELS, ROLE_LABELS, SEASON_LENGTH, challengeCareer,  overall, rest, simulateGames, nextRegularMatch, allSeasonGames, type Career, type ChallengeRoute, type TrainingGroup } from "@/lib/lanqiushengya/engine";
import { ensureNcaa, pendingNcaaMatch, advanceNcaaPostseason } from "@/lib/lanqiushengya/ncaa";
import { MatchCenter } from "./match-center";
import { TournamentBracket } from "./tournament-bracket";
import { TeamRoster } from "./team-roster";
import { StoryPanel } from "./career-story";
import { SeasonDetail } from "./season-detail";
import { OffseasonDesk } from "./offseason-desk";
import { CourtScene, PixelPlayer, type Appearance } from "./pixel-art";
import styles from "./career-dashboard.module.css";

type Props = { career: Career; appearance: Appearance; onChange: (career: Career) => void; onTraining: (group: TrainingGroup) => void; onContract: () => void; onAppearance: () => void; onArchive: () => void };
const groups = Object.keys(GROUP_LABELS) as TrainingGroup[];
const routes: [ChallengeRoute, string, string][] = [["scoring","得分手路线","5 场场均得分达到 18"],["playmaking","组织者路线","5 场场均助攻达到 6"],["inside","内线支柱路线","5 场场均篮板达到 9"]];
const tabs = ["赛季旅程", "联盟观察", "球队阵容", "薪资与交易", "锦标赛对阵", "生涯故事", "赛季手册", "休赛期"];

export function CareerDashboard({ career, appearance, onChange, onTraining, onContract, onAppearance, onArchive }: Props) {
  const c = ensureNcaa(career);
  const [matchInfo, setMatchInfo] = useState<{opponent:string;home:boolean;label:string} | null>(null);
  const [tab, setTab] = useState(0);
  const [potential, setPotential] = useState(false);
  const [challenge, setChallenge] = useState(false);
  const [filter, setFilter] = useState("");
  const [sort, setSort] = useState("战绩");
  const games = allSeasonGames(c);
  const avg = (key: "pts" | "reb" | "ast" | "stl" | "blk") => games.length ? (games.reduce((sum, game) => sum + game[key], 0) / games.length).toFixed(1) : "0.0";
  const regularDone = c.game >= SEASON_LENGTH[c.phase];
  const finished = regularDone && c.ncaa?.stage === "complete";
  const pending = pendingNcaaMatch(c);
  const preview = regularDone ? pending : nextRegularMatch(c);
  const openMatch = () => { if(preview) setMatchInfo({...preview,label:regularDone ? pending?.label ?? "锦标赛" : `常规赛 · 第 ${c.game+1} 场 / 30`}); };
  const retired = c.phase === "retired";
  const teams = c.phase === "college" ? COLLEGES : NBA_TEAMS;
  const standings = teams.map((team, i) => ({ team, wins: team === c.team ? c.wins : Math.round(c.game * (.35 + (i * 7 % 13) / 35)), rating: 64 + i * 3 % 17 })).filter(item => item.team.includes(filter)).sort((a,b)=>sort === "实力" ? b.rating-a.rating : b.wins-a.wins);
  const canChallenge = !retired && !c.challengeGoal && (c.role ?? 2) < 4 && c.games.length >= (c.challengeCooldown ?? 0) && SEASON_LENGTH[c.phase] - c.game >= 5;
  return <div className={styles.dashboard}>
    <div className={styles.hero}><CourtScene name={c.player.name} number={c.player.number}/></div>
    <div className={styles.eyebrow}>{c.phase === "college" ? "NCAA" : c.phase === "nba" ? "NBA" : "CAREER ARCHIVE"} · {c.season}–{String(c.season+1).slice(-2)}</div>
    <p className={styles.seasonLine}>{c.player.name} · {c.team} · {c.age} 岁 · {c.phase === "college" ? `大学第 ${Math.min(4, c.age-17)} 年` : "职业生涯"}</p>
    <div className={styles.tabs} role="tablist" aria-label="生涯首页内容">{tabs.map((label,i)=><button key={label} role="tab" aria-selected={tab===i} className={tab===i ? styles.active : ""} onClick={()=>{setTab(i);setFilter("");}}>{["▦","▣","♜","⇄","♧","✎","▤","☀"][i]} {label}</button>)}</div>
    {tab===0 && <>
      <div className={styles.columns}>
        <section className={`${styles.panel} paper-panel`}>
          <div className={styles.profile}><button onClick={onAppearance} className={styles.portrait} aria-label="修改球员外观"><PixelPlayer appearance={appearance} number={c.player.number} name={c.player.name} size={60}/></button><div><h2>{c.player.name} · #{c.player.number}</h2><p>{c.age} 岁 · {c.player.position} · {c.player.height} cm / {c.player.weight} kg · 臂展 {c.player.wingspan} cm</p></div><span className={styles.badge}>总评 {overall(c.player)}</span></div>
          <div className={styles.sectionHeading}><h2>{c.phase === "college" ? "大学赛季" : "职业赛季"}</h2><span className={styles.badge}>{games.filter(g=>g.min>0).length} 场出场 · {games.every(g=>g.started!==undefined)?games.filter(g=>g.started).length:"—"} 场首发</span></div>
          <div className={styles.stats}>{[["场均得分",avg("pts")],["场均篮板",avg("reb")],["场均助攻",avg("ast")],["场均抢断",avg("stl")],["场均盖帽",avg("blk")],["场均失误",games.every(g=>g.to!==undefined)?(games.reduce((sum,g)=>sum+(g.to??0),0)/Math.max(1,games.length)).toFixed(1):"—"]].map(([label,value])=><div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
          <div className={styles.record}><span>球队战绩 <b>{games.filter(g=>g.won).length} 胜 {games.filter(g=>!g.won).length} 负</b></span><span>常规赛 <b>{c.game} / {SEASON_LENGTH[c.phase]}</b></span></div>
          <div className={styles.sectionHeading}><h2>你的成长潜力</h2><button onClick={()=>setPotential(!potential)} aria-expanded={potential}>{potential ? "收起详情 −" : "潜力详情 +"}</button></div>
          <p className={styles.muted}>天赋 {c.player.potential} · {c.player.archetype} · {ROLE_LABELS[c.role ?? 2]}</p>
          {potential && <div className={styles.note}>天赋决定成长效率；技术上限取决于创建时的球员设定。训练积累专项点数，在「球员能力」中提升属性。{c.player.description && <p>{c.player.description}</p>}</div>}
        </section>
        <section className={`${styles.panel} paper-panel`}><h2>当下的你</h2>{[["体力",c.energy],["信心",c.confidence ?? 75],["教练信任",c.trust ?? 50]].map(([label,value])=><div className={styles.condition} key={label}><strong>{label}</strong><span>{value}</span><div role="meter" aria-label={String(label)} aria-valuenow={Number(value)} aria-valuemin={0} aria-valuemax={100}><i style={{width:`${value}%`}}/></div></div>)}<button className={styles.wide} disabled={retired || c.energy>=100} onClick={()=>onChange(rest(c))}>休息恢复 · 体力 +35</button><p className={styles.muted}>安排好训练与恢复，为下一场比赛做好准备。</p></section>
      </div>
      <StoryPanel career={c} onChange={onChange} />
      <section className={`${styles.panel} paper-panel`}><div className={styles.sectionHeading}><h2>日常训练</h2><span className={styles.muted}>每次消耗 15 体力</span></div><div className={styles.training}>{groups.map((group,i)=><button key={group} disabled={retired||c.energy<15} onClick={()=>onTraining(group)}><span>{["◎","↗","⇄","▥","↟","ϟ","◉"][i]}</span><b>{GROUP_LABELS[group]}</b><small>{c.points[group]} 训练点</small></button>)}</div></section>
      <section className={`${styles.panel} paper-panel`}><div className={styles.sectionHeading}><h2>球队地位</h2><span className={styles.badge}>{ROLE_LABELS[c.role ?? 2]}</span></div><p className={styles.muted}>{c.challenge || "用场上的表现赢得教练的信任，争取更重要的球队角色。"}</p><button disabled={!canChallenge} onClick={()=>setChallenge(!challenge)}>{c.challengeGoal ? "挑战进行中" : "发起地位挑战"}</button>{challenge&&canChallenge&&<div className={styles.challenge}>{routes.map(([route,label,description])=><button key={route} onClick={()=>{onChange(challengeCareer(c,route));setChallenge(false);}}><b>{label}</b><small>{description}</small></button>)}</div>}</section>
      <section className={`${styles.panel} paper-panel`}><div className={styles.sectionHeading}><h2>赛季旅程</h2><span className={styles.badge}>常规赛 → 联盟锦标赛 → 全国 64 强</span></div>{retired ? <><p>球鞋挂起，故事仍在。查看完整生涯记录。</p><button onClick={onArchive}>查看生涯档案</button></> : finished ? <><p>本赛季已结束：{games.filter(g=>g.won).length} 胜 {games.filter(g=>!g.won).length} 负，共 {games.length} 场。{c.ncaa?.finish}。全国冠军：{c.ncaa?.champion}。</p><div className={styles.buttons}><button className={styles.primary} onClick={()=>setTab(7)}>安排休赛期与下一季</button>{c.phase==="college"&&<button onClick={()=>setTab(7)}>选秀与转学选择</button>}<button onClick={onArchive}>查看赛季档案</button></div></> : regularDone ? <><p>{pending ? `${pending.label} · ${c.team} vs ${pending.opponent}` : "本队本轮暂无比赛，继续关注锦标赛晋级。"}</p><div className={styles.buttons}><button className={styles.primary} onClick={()=>pending ? openMatch() : onChange(advanceNcaaPostseason(c))}>{pending ? "进入本场比赛 →" : "推进下一轮 →"}</button><button onClick={()=>setTab(4)}>查看锦标赛对阵图</button><button onClick={onArchive}>查看赛季档案</button></div><p className={styles.muted}>联盟锦标赛最多 3 场，全国锦标赛最多 6 场；总计最多 39 场。淘汰后可继续查看其他球队争冠。</p></> : <>
        <p className={styles.muted}>每场比赛前可以查看对手球探，选择战术；新的剧情会随着赛季进度出现。</p>
        <button className={styles.primary} onClick={openMatch}>进入下一场比赛 →</button><button onClick={()=>setTab(6)}>查看完整赛程与球探</button>
        <div className={styles.buttons}><button onClick={openMatch}>准备本场比赛</button><button onClick={()=>onChange(simulateGames(c,5))}>模拟 5 场</button><button onClick={()=>onChange(simulateGames(c,SEASON_LENGTH[c.phase]-c.game))}>快速完成常规赛</button></div>
      </>}</section>
      <section className={`${styles.panel} paper-panel`}><h2>生涯动态</h2><div className={styles.log}>{c.log.slice(0,8).map((line,i)=><p key={`${i}-${line}`}>· {line}</p>)}</div></section>
    </>}
    {tab===1&&<section className={`${styles.panel} paper-panel`}><div className={styles.sectionHeading}><h2>联盟观察</h2><span className={styles.badge}>其他球队为本地模拟</span></div><div className={styles.filters}><input aria-label="搜索球队" placeholder="搜索球队" value={filter} onChange={e=>setFilter(e.target.value)}/><select aria-label="排名排序" value={sort} onChange={e=>setSort(e.target.value)}><option>战绩</option><option>实力</option></select></div><div className={styles.tableWrap}><table><thead><tr><th>排名</th><th>球队</th><th>胜</th><th>负</th><th>实力</th></tr></thead><tbody>{standings.map((team,i)=><tr key={team.team}><td>{i+1}</td><td>{team.team}{team.team===c.team ? " · 我的球队" : ""}</td><td>{team.wins}</td><td>{c.game-team.wins}</td><td>{team.rating}</td></tr>)}</tbody></table></div>{!standings.length&&<p className={styles.muted}>没有找到匹配的球队。</p>}</section>}
    {tab===2&&<TeamRoster career={c} />}
    {tab===3&&<section className={`${styles.panel} paper-panel`}><h2>薪资与交易</h2>{c.phase==="college"?<><p>你目前效力于 {c.team}。完成大学赛季后可以参加 NBA 选秀，开启职业合同生涯。</p><p className={styles.muted}>大学阶段暂无职业薪资与自由球员签约。</p></>:<><div className={styles.contract}><div><span>年薪</span><strong>${(c.contract.salary/10000).toFixed(0)} 万</strong></div><div><span>剩余合同</span><strong>{c.contract.years} 年</strong></div></div><button className={styles.primary} disabled={retired || c.contract.years > 0} onClick={onContract}>{c.contract.years > 0 ? "合同履行中" : "选择球队并签约"}</button>{c.contract.years > 0 && <p className={styles.muted}>当前合同还剩 {c.contract.years} 年，合同到期后可以选择球队并签订新合同。</p>}</>}</section>}
    {tab===4&&<section className={styles.panel}><div className={styles.sectionHeading}><h2>NCAA 锦标赛</h2><span className={styles.badge}>{c.ncaa?.champion ? "全国冠军 · "+c.ncaa.champion : "单场淘汰 · 通往全国冠军"}</span></div>{!regularDone ? <p>常规赛结束后公布联盟种子与晋级对阵。</p> : <div className={styles.buttons}>{!finished&&<button className={styles.primary} onClick={()=>pending ? openMatch() : onChange(advanceNcaaPostseason(c))}>{pending ? "进入本场比赛 →" : "推进下一轮 →"}</button>}<button onClick={onArchive}>赛季与比赛回顾</button></div>}
      {c.ncaa?.stage === "national" && c.ncaa.qualified === false && <p className={styles.note}>本赛季未获得全国锦标赛资格。你仍可以逐轮查看 64 支球队的争冠过程，结束后进入休赛期。</p>}
      <TournamentBracket title="联盟锦标赛" rounds={["四分之一决赛","半决赛","联盟决赛"]} team={c.team} matches={(c.ncaa?.matchups.filter(m=>m.stage==="conference")??[]).map(m=>({...m,round:m.round-1,detail:m.winner ? "晋级："+m.winner : "单场淘汰赛",results:m.game?[{label:"个人表现",score:m.game.pts+" 分 / "+m.game.reb+" 篮板 / "+m.game.ast+" 助攻"}]:[]}))} />
      {["东部","西部","南部","中西部"].map(region=><TournamentBracket key={region} title={"全国锦标赛 · "+region} rounds={["64 强","32 强","甜蜜 16 强","精英 8 强"]} team={c.team} matches={(c.ncaa?.matchups.filter(m=>m.stage==="national"&&m.region===region)??[]).map(m=>({...m,round:m.round-1}))} />)}
      <TournamentBracket title="最终四强" rounds={["全国半决赛","全国决赛"]} team={c.team} matches={(c.ncaa?.matchups.filter(m=>m.stage==="national"&&m.round>=5)??[]).map(m=>({...m,round:m.round-5}))} />
    </section>}
    {tab===5&&<StoryPanel career={c} onChange={onChange}/>}
    {tab===6&&<SeasonDetail career={c} onChange={onChange} onPlay={openMatch}/>}
    {tab===7&&<OffseasonDesk career={c} onChange={onChange}/>}
    {matchInfo&&<MatchCenter team={c.team} {...matchInfo} onClose={()=>setMatchInfo(null)} onPlay={tactic=>{const next=regularDone?advanceNcaaPostseason(c,tactic):simulateGames(c,1,tactic);onChange(next);return regularDone?next.ncaa?.postseasonGames.at(-1):next.games.at(-1);}} />}

  </div>;
}

