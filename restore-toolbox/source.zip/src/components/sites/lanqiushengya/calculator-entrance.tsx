"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import styles from "./calculator-entrance.module.css";

// A small arithmetic parser keeps calculator input out of executable JavaScript.
function calculate(expression: string): number {
  const tokens = expression.match(/(?:\d+(?:\.\d*)?|\.\d+)|[+\-*/]/g);
  if (!tokens || tokens.join("") !== expression) throw new Error("请输入完整算式");
  let index = 0;
  function number(): number {
    let sign = 1;
    if (tokens![index] === "-" || tokens![index] === "+") sign = tokens![index++] === "-" ? -1 : 1;
    const token = tokens![index++];
    if (!token || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token)) throw new Error("请输入完整算式");
    return sign * Number(token);
  }
  function term(): number {
    let value = number();
    while (tokens![index] === "*" || tokens![index] === "/") {
      const operator = tokens![index++], right = number();
      value = operator === "*" ? value * right : value / right;
    }
    return value;
  }
  let value = term();
  while (index < tokens.length) {
    const operator = tokens[index++];
    if (operator !== "+" && operator !== "-") throw new Error("请输入完整算式");
    const right = term();
    value = operator === "+" ? value + right : value - right;
  }
  if (!Number.isFinite(value)) throw new Error("无法计算这个算式");
  return Number(value.toPrecision(12));
}

export function CalculatorEntrance() {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState("");
  const [error, setError] = useState(false);
  const router = useRouter();
  const [hint, setHint] = useState(false);
  function equals() {
    const normalized = expression.replace(/\s/g, "").replace(/×/g, "*").replace(/÷/g, "/");
    if (normalized === "7+8+9+1") { router.push('/calculator/games-career'); return; }
    try { const value=calculate(normalized); if(value===25){router.push('/calculator/games-career');return;} setResult(String(value)); setError(false); }
    catch (e) { setResult(e instanceof Error ? e.message : "请输入完整算式"); setError(true); }
  }
  function key(value: string) {
    if (value === "=") { equals(); return; }
    setError(false); setResult("");
    if (value === "AC") setExpression("");
    else if (value === "⌫") setExpression(expression.slice(0, -1));
    else setExpression((expression + value).slice(0, 80));
  }
  return <main className={styles.page}>
    <header className={styles.header}><Link href="/" className={styles.logo} aria-label="返回工具箱">f.</Link><span>fran<span className={styles.muted}> / everyday tools</span></span><Link href="/" className={styles.edition}>← 工具箱</Link></header>
    <section className={styles.layout}>
      <div className={styles.intro}><p className={styles.eyebrow}>A LITTLE EVERYDAY MAGIC</p><h1>先算一算。<br /><span>再来点不一样的。</span></h1><p className={styles.description}>一个简单的计算器。<br />有时，一道算式也能打开另一段旅程。</p><button className={styles.hint} onClick={() => setHint(!hint)} aria-expanded={hint}>{hint ? "五的平方藏着一扇门。试试算出 25，再按 =。" : "给我一点提示 ↗"}</button></div>
      <div className={styles.calculator}><div className={styles.topline}><span>CALCULATOR</span><span className={styles.light}>●</span></div>
        <form onSubmit={e => { e.preventDefault(); equals(); }}><label className={styles.label} htmlFor="calculator-expression">输入算式</label><input id="calculator-expression" aria-label="计算器算式" className={styles.display} value={expression} placeholder="0" maxLength={80} autoComplete="off" spellCheck={false} onChange={e => { setExpression(e.target.value.replace(/[^0-9+\-*/×÷.\s]/g, "")); setResult(""); setError(false); }} onKeyDown={e => { if (e.key === "=") { e.preventDefault(); equals(); } if (e.key === "Escape") key("AC"); }} /><output aria-live="polite" className={`${styles.result} ${error ? styles.error : ""}`}>{result || "准备好了吗？"}</output></form>
        <div className={styles.keys}>{["AC", "⌫", "÷", "×", "7", "8", "9", "−", "4", "5", "6", "+", "1", "2", "3", "=", "0", "."].map(value => <button type="button" key={value} aria-label={value === "⌫" ? "退格" : value === "AC" ? "清除" : value === "=" ? "等于" : value} className={`${value === "=" ? styles.equals : ""} ${value === "0" ? styles.zero : ""} ${["÷", "×", "−", "+"].includes(value) ? styles.operator : ""}`} onClick={() => key(value === "−" ? "-" : value)}>{value}</button>)}</div>
        <p className={styles.keynote}>支持键盘输入 · Enter 计算 · Esc 清除</p>
        <a className={styles.gameEntry} href="/calculator/gta-v/">洛圣都 · 密码入口 ↗</a>
      </div>
    </section><footer className={styles.footer}><span>MADE FOR A LITTLE FUN.</span><span>FRAN — ABCD — ABCD</span></footer>
  </main>;
}

