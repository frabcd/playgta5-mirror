"use client";

import { useRef, useState } from "react";
import type { Player } from "@/lib/lanqiushengya/engine";
import styles from "./recruitment.module.css";
import { getRoster, getRosterSource, type RosterPlayer } from "@/lib/lanqiushengya/rosters";

const schools = [
  { name: "佛罗里达大学", english: "Florida Gators", short: "F", color: "#42699a", minutes: "30–34", role: "争取首发" },
  { name: "伊利诺伊大学", english: "Illinois Fighting Illini", short: "I", color: "#b77246", minutes: "30–34", role: "争取首发" },
  { name: "维拉诺瓦大学", english: "Villanova Wildcats", short: "V", color: "#60768a", minutes: "30–34", role: "争取首发" },
  { name: "杜克大学", english: "DUKE", short: "D", color: "#436798", minutes: "30–34", role: "争取首发" },
  { name: "印第安纳大学", english: "Indiana Hoosiers", short: "IU", color: "#934c43", minutes: "30–34", role: "争取首发" },
  { name: "休斯敦大学", english: "Houston Cougars", short: "UH", color: "#9b5149", minutes: "29", role: "培养轮换" },
  { name: "阿肯色大学", english: "Arkansas Razorbacks", short: "A", color: "#8d4e45", minutes: "30–34", role: "争取首发" },
  { name: "威斯康星大学", english: "Wisconsin Badgers", short: "W", color: "#9d534a", minutes: "30–34", role: "争取首发" },
];
export function Recruitment({ player, onJoin, onBack }: { player: Player; onJoin: (team: string) => void; onBack: () => void }) {
  const [selected, setSelected] = useState(0);
  const [viewed, setViewed] = useState<RosterPlayer | null>(null);
  const joining = useRef(false);
  const school = schools[selected];
  const roster = getRoster(school.name);
  const source = getRosterSource(school.name);
  return <div className={styles.recruitment}>
    <span className={styles.eyebrow}>COLLEGE RECRUITMENT</span>
    <h1>下一站，大学球馆。</h1>
    <p className={styles.intro}>{player.name}，你收到了 8 所大学的招募邀请。选择一个能让你成长的地方。</p>
    <p className={styles.hint}>预计角色会随表现改变。学校风格与招募条件属于游戏设定。</p>
    <div className={styles.schools} aria-label="选择招募学校">{schools.map((item, index) => <button key={item.name} type="button" aria-pressed={selected === index} className={`${styles.school} ${selected === index ? styles.selected : ""}`} onClick={() => {setSelected(index);setViewed(null);}}>
      <span className={styles.schoolTop}><span className={styles.logo} style={{ color: item.color }}>{item.short}</span><span><strong>{item.name}</strong><small>{item.english}</small></span><span className={styles.radio} aria-hidden="true">{selected === index ? "●" : "○"}</span></span>
      <span className={styles.projection}><span>预计角色 <b>{item.role}</b></span><span>预计时间 <b>{item.minutes} 分钟</b></span></span>
      {selected === index && <span className={styles.details}><span>同位置竞争 <b>{roster.filter(mate => mate.position === player.position).length} 人</b></span><span>通过比赛表现和训练争取更多出场时间。</span><span className={styles.tags}><i>真实大学球员名单</i><i>球探曝光稳定</i></span></span>}
    </button>)}</div>
    <section className={`${styles.roster} paper-panel`}>
      <div className={styles.rosterHeading}><div><h2>球队阵容</h2><p>点击球员姓名，查看球员资料</p></div><span className="badge">{school.name} · {roster.length} 人</span></div>
      <p className={styles.hint}>{source?.season} 历史名单作为开局球员池 · <a href={source?.url} target="_blank" rel="noreferrer">学校官网来源</a>。能力值和细分位置为游戏估计。</p>
      <div className={styles.tableWrap}><table><thead><tr><th>球员</th><th>号码</th><th>位置</th><th>能力</th><th>身高</th><th>年级</th></tr></thead><tbody>{roster.map(mate => <tr key={mate.id}><td><button onClick={() => setViewed(mate)}>{mate.name}</button></td><td>#{mate.number || "—"}</td><td>{mate.position}</td><td><b>{mate.rating}</b></td><td>{mate.height ? `${mate.height} cm` : "—"}</td><td>{mate.classYear || "—"}</td></tr>)}</tbody></table></div>
      {viewed && <section className={styles.playerDetail} aria-label={`${viewed.name}球员资料`}><div><h3>{viewed.name}</h3><button aria-label="关闭球员资料" onClick={() => setViewed(null)}>×</button></div><p>{school.name} · #{viewed.number || "—"} · 官网位置 {viewed.listedPosition} · 游戏位置 {viewed.position} · 能力估计 {viewed.rating}{viewed.height ? ` · ${viewed.height} cm` : ""}</p><span>2026–27 本地模拟赛季</span><div className={styles.emptyStats}>{["出场","得分","篮板","助攻"].map(label=><div key={label}><b>—</b><small>{label}</small></div>)}</div><p>新赛季尚未开始，暂无比赛数据。</p></section>}
    </section>
    <div className={styles.actions}><button onClick={onBack}>返回球员资料</button><button className={styles.join} onClick={() => { if (joining.current) return; joining.current = true; onJoin(school.name); }}>加入{school.name} · 开启大学赛季 →</button></div>
  </div>;
}

