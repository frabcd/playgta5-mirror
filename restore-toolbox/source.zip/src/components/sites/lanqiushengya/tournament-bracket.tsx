"use client";

import { useState } from "react";
import styles from "./tournament-bracket.module.css";

export type BracketMatch = { id: string; round: number; home: string; away: string; homeSeed?: number; awaySeed?: number; homeScore?: number; awayScore?: number; winner?: string; detail?: string; homePlaceholder?: string; awayPlaceholder?: string; results?: { label: string; score: string }[] };

export function TournamentBracket({ title, rounds, matches, team }: { title: string; rounds: string[]; matches: BracketMatch[]; team: string }) {
  const [selected, setSelected] = useState<string | null>(null);
  const columns = rounds.map((_, i) => matches.filter(m => m.round === i));
  const height = Math.max(1, ...columns.map(c => c.length)) * 116;
  const width = rounds.length * 246 - 30;
  const y = (column: number, index: number) => (index + .5) * height / Math.max(1, columns[column].length);
  const current = matches.find(m => m.id === selected);
  return <section className={styles.root} aria-label={title}>
    <div className={styles.heading}><h3>{title}</h3><span>点击对阵查看详情 · 横向滑动查看晋级路线</span></div>
    {!matches.length ? <p className={styles.empty}>对阵尚未公布，完成前一阶段后揭晓。</p> : <div className={styles.scroll} tabIndex={0} aria-label={`${title}晋级对阵图`}>
      <div className={styles.labels} style={{ width }}>{rounds.map(label => <strong key={label}>{label}</strong>)}</div>
      <div className={styles.canvas} style={{ height, width }}>
        <svg width={width} height={height} className={styles.lines} aria-hidden="true">{columns.slice(0, -1).flatMap((column, ci) => column.map((m, mi) => {
          const nextCount = columns[ci + 1].length;
          if (!nextCount) return null;
          const target = Math.min(nextCount - 1, Math.floor(mi * nextCount / column.length));
          const start = ci * 246 + 216, end = (ci + 1) * 246, cy = y(ci, mi), ny = y(ci + 1, target);
          return <path key={m.id} d={`M${start},${cy} H${start + 15} V${ny} H${end}`} />;
        }))}</svg>
        {columns.flatMap((column, ci) => column.map((m, mi) => <button key={m.id} className={`${styles.match} ${[m.home, m.away].includes(team) ? styles.own : ""} ${selected === m.id ? styles.selected : ""}`} style={{ left: ci * 246, top: y(ci, mi) - 42 }} onClick={() => setSelected(selected === m.id ? null : m.id)} aria-expanded={selected === m.id}>
          <span className={styles.caption}>{m.winner ? "已结束" : m.home && m.away ? "待赛 / 进行中" : "等待晋级"}</span>
          <span className={m.winner && m.winner === m.home ? styles.winner : ""}><small>{m.homeSeed || "·"}</small><b>{m.home || m.homePlaceholder || "上轮胜者"}</b><em>{m.homeScore ?? "—"}</em></span>
          <span className={m.winner && m.winner === m.away ? styles.winner : ""}><small>{m.awaySeed || "·"}</small><b>{m.away || m.awayPlaceholder || "上轮胜者"}</b><em>{m.awayScore ?? "—"}</em></span>
        </button>))}
      </div>
    </div>
    }
    {current && <div className={styles.detail} role="region" aria-label="对阵详情"><div className={styles.heading}><h4>{current.home || "待定"} vs {current.away || "待定"}</h4><button onClick={() => setSelected(null)}>收起详情</button></div><p>{current.detail ?? (current.winner ? `晋级：${current.winner}` : "晋级球队确定后即可进行比赛。")}</p>{current.results?.map((result, i) => <p key={i}><b>{result.label}</b>　{result.score}</p>)}</div>}
  </section>;
}
