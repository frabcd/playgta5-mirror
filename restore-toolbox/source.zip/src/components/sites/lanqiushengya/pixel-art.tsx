export type Appearance = {
  skin: number;
  face: number;
  hair: number;
  hairColor: number;
  eyes: number;
  beard: number;
};

export const defaultAppearance: Appearance = { skin: 2, face: 0, hair: 1, hairColor: 0, eyes: 0, beard: 0 };

const skins = ["#f4d1a4", "#dbac7f", "#c28e64", "#a76e4c", "#815034", "#543522"];
const hairColors = ["#29251f", "#68462d", "#c69a50", "#b6b6ad", "#783c42", "#416981", "#4e7653"];

export function PixelPlayer({ appearance = defaultAppearance, number = "0", name = "球员", size = 144, jerseyColor = "#376c53" }: {
  appearance?: Appearance;
  number?: string | number;
  name?: string;
  size?: number;
  jerseyColor?: string;
}) {
  const skin = skins[appearance.skin % skins.length];
  const hair = hairColors[appearance.hairColor % hairColors.length];
  const faceInset = appearance.face === 1 ? 1 : appearance.face === 2 ? -1 : 0;
  const eyeY = 17 + (appearance.eyes % 2);
  return <svg width={size} height={size * 1.25} viewBox="4 -2 40 50" role="img" aria-label={`${name}的球员形象`} shapeRendering="crispEdges">
    <rect y="-2" width="48" height="50" fill="#e1e8dc" />
    <path d="M8 48V37h5v-4h8v-5h7v5h8v4h5v11" fill="#3a2b25" />
    <path d="M10 48V39h5v-4h6v-6h7v6h6v4h5v9" fill={skin} />
    <path d="M17 35h4v3h7v-3h4v13H17z" fill={jerseyColor} />
    <path d="M19 35v5h11v-5h2v7H17v-7z" fill="#e8e7c9" />
    <path d={`M${15 + faceInset} 8h${18 - faceInset * 2}v5h3v12h-3v5h-4v3H19v-3h-4v-5h-3V13h3z`} fill="#3a2b25" />
    <path d={`M${16 + faceInset} 10h${16 - faceInset * 2}v5h3v8h-4v5h-3v3h-8v-3h-3v-5h-4v-8h3z`} fill={skin} />
    <path d="M14 17h2v5h-2zm19 0h2v5h-2z" fill="#be8058" />
    {appearance.hair % 9 !== 0 && <g fill={hair}>
      {appearance.hair % 9 !== 7 && <path d="M14 9h3V6h14v3h3v8h-3v-5H17v5h-3z" />}
      {appearance.hair % 9 === 1 && <path d="M17 7h14v5H17z" />}
      {appearance.hair % 9 === 2 && <path d="M16 6h12v3h6v6h-6v-4h-3v4h-9z" />}
      {appearance.hair % 9 === 3 && <path d="M12 9h24v7h-4v-4H16v4h-4zm3-5h5v7h-5zm7-2h5v8h-5zm7 2h5v7h-5z" />}
      {appearance.hair % 9 === 4 && <path d="M11 9h3v20h-3zm5-5h3v10h-3zm6-2h3v11h-3zm6 2h3v10h-3zm6 5h3v22h-3z" />}
      {appearance.hair % 9 === 5 && <path d="M11 10h5v22h-5zm22 0h5v22h-5zM16 3h17v7H16z" />}
      {appearance.hair % 9 === 6 && <path d="M10 8h4V3h20v5h4v13h-6v-7H16v7h-6z" />}
      {appearance.hair % 9 === 7 && <path d="M21 2h7v12h-7z" />}
      {appearance.hair % 9 === 8 && <path d="M20 1h9v7h-9zM15 8h18v5H15z" />}
    </g>}
    <g fill="#3a2b25">
      <rect x="18" y={eyeY} width={appearance.eyes % 4 === 2 ? 4 : 3} height={appearance.eyes % 4 === 1 ? 1 : 2} />
      <rect x="27" y={eyeY} width={appearance.eyes % 4 === 2 ? 4 : 3} height={appearance.eyes % 4 === 1 ? 1 : 2} />
      {appearance.eyes % 4 === 3 && <path d={`M17 ${eyeY - 1}h2v1h-2zm13 0h2v1h-2z`} />}
      {appearance.eyes >= 4 && <path d={`M17 ${eyeY - 3}h5v1h-5zm10 0h5v1h-5z`} />}
      <path d="M21 26h7v1h-7z" />
    </g>
    <path d="M23 20h2v4h3v1h-5z" fill="#9a6948" />
    {appearance.beard > 0 && <g fill={hair}>
      <path d={appearance.beard % 3 === 1 ? "M20 25h9v2h-9z" : appearance.beard % 3 === 2 ? "M21 28h7v3h-7z" : "M17 25h3v3h9v-3h3v4h-4v3h-8v-3h-3z"} />
      {appearance.beard >= 4 && <path d="M17 23h2v6h-2zm13 0h2v6h-2z" />}
      {appearance.beard >= 6 && <path d="M20 29h9v4h-9z" />}
    </g>}
    <text x="24.5" y="48" textAnchor="middle" fontFamily="monospace" fontSize="7" fontWeight="bold" fill="#ece6c6">{number}</text>
  </svg>;
}

export function CourtScene({ number = "0", name = "我的篮球生涯" }: { number?: string | number; name?: string }) {
  return <svg viewBox="0 0 586 192" width="100%" role="img" aria-label={`${name}，校园篮球场`} shapeRendering="crispEdges">
    <rect width="586" height="192" fill="#7aabb6" />
    <path d="M40 29h12v-9h22v9h11v8H40zm166-13h12V8h22v8h12v8h-46zm237 11h12v-9h22v9h12v8h-46z" fill="#e9ecd6" />
    <path d="M201 101V69h15v32h4V45h27v62h8V75h28v30h6V54h28v52h8V69h28v36h8V42h28v70h11v16H187v-27z" fill="#73949c" />
    <g fill="#a1beb9">{[225,237,294,305,366,378].map((x, i) => [54,66,78,90].map(y => <rect key={`${x}-${y}`} x={x} y={y + (i === 2 || i === 3 ? 9 : 0)} width="5" height="6" />))}{[261,274,330,342].map(x => [82,94].map(y => <rect key={`${x}-${y}`} x={x} y={y} width="5" height="6" />))}</g>
    <rect y="106" width="586" height="24" fill="#bdd0b5" />
    <rect y="131" width="586" height="61" fill="#98a68f" />
    <path d="M0 127h586v5H0z" fill="#48664f" />
    <g stroke="#65866b" strokeWidth="1">
      {Array.from({length:20},(_,i)=><path key={i} d={`M${195+i*10} 103v35`} />)}
      <path d="M193 110h203m-203 15h203m-203 10h203" />
    </g>
    <path d="M400 52h145v83H400z" fill="#ae8965" />
    <path d="M402 63h143v5H402zm0 17h143v4H402zm0 17h143v4H402zm0 17h143v4H402zm0 16h143v4H402z" fill="#b99770" />
    <g stroke="#be9f79" strokeWidth="3">{[410,433,457,481,505,529].map(x=><path key={x} d={`M${x} 69v10m11 7v10m-11 6v10m11 8v9`} />)}</g>
    <path d="M415 45h117v6H415zM404 51h135v7H404z" fill="#705740" />
    <path d="M392 57h151v7H392z" fill="#ecdbab" />
    <path d="M436 67h82v22h-82z" fill="#d6bb88" />
    <path d="M440 70h74v16h-74z" fill="#eedeb1" />
    <path d="M453 95h50v40h-50z" fill="#496247" />
    <path d="M458 100h18v31h-18zm23 0h17v31h-17z" fill="#597e60" />
    <path d="M467 114h3v12h-3zm16 0h3v12h-3z" fill="#e8dca9" />
    <path d="M415 80h18v29h-18zm108 0h18v29h-18z" fill="#e7d9a7" />
    <path d="M418 83h12v23h-12zm108 0h12v23h-12z" fill="#719696" />
    <path d="M423 84h2v22h-2zm108 0h2v22h-2z" fill="#b8c9b0" />
    <path d="M400 132h153v4H400z" fill="#736b50" />
    <path d="M28 86h9v53h-9zm529-3h10v51h-10z" fill="#7b6142" />
    <path d="M12 46h30v7h12v12h7v27H49v13H28v-7H14V87H4V58h8z" fill="#426746" />
    <path d="M16 49h24v12h11v15H37v13H17V78H7V63h9z" fill="#72934e" />
    <path d="M17 52h19v11H17zm-8 18h12v10H9zm20 5h11v9H29z" fill="#93a75f" />
    <path d="M545 49h25v7h13v12h3v26h-14v12h-24v-6h-14V86h-8V62h19z" fill="#4d7348" />
    <path d="M545 53h22v13h11v17h-17v11h-22V83h-9V68h15z" fill="#79984e" />
    <path d="M550 55h14v12h-14zm-15 16h11v10h-11zm22 11h15v8h-15z" fill="#a0ae61" />
    <path d="M225 142h169v44H225z" fill="#77979a" />
    <path d="M228 145h163v38H228zm3 2h157v33H231z" fill="none" stroke="#d3d9bb" strokeWidth="1" />
    <path d="M248 158h26v14h-26m110-14h-25v14h25m-47-25v33" fill="none" stroke="#d3d9bb" strokeWidth="1" />
    <path d="M358 104h5v44h-5z" fill="#4a6151" />
    <path d="M335 73h45v34h-45z" fill="#42554a" />
    <path d="M339 77h37v26h-37z" fill="#e8e4c2" />
    <path d="M347 82h20v20h-20z" fill="#73a4a3" />
    <path d="M351 86h12v15h-12z" fill="#e6e3bd" />
    <path d="M350 99h16v4h-16z" fill="#ac7547" />
    <path d="M352 103v8h10v-8m-7 1v7m4-7v7" fill="none" stroke="#ece8c7" strokeWidth="2" />
    <path d="M29 62h166v7H29zm-4 7h176v66H25z" fill="#466147" />
    <path d="M53 132h8v27h-8zm122 0h8v27h-8z" fill="#81684c" />
    <path d="M31 71h164v57H31z" fill="#725e3f" />
    <path d="M37 75h152v47H37z" fill="#d9c991" />
    <path d="M41 79h144v41H41z" fill="#e9dba8" />
    <path d="M43 80h140v3H43z" fill="#f4e9c4" />
    <text x="113" y="100" textAnchor="middle" fontSize="14" fontWeight="900" fontFamily="CareerPixel, monospace" fill="#3f4832">我的篮球生涯</text>
    <text x="113" y="109" textAnchor="middle" fontSize="6" letterSpacing="1" fontWeight="bold" fontFamily="CareerPixel, monospace" fill="#4c4b32">MY CAREER</text>
    <path d="M290 121h17v6h3v13h-4v5h-16v-5h-4v-13h4z" fill="#3d3a2c" />
    <path d="M294 118h15v10h-18v-6h3z" fill="#4c4837" />
    <path d="M291 126h17v4h-17z" fill="#5c5842" />
    <path d="M294 143h11v6h-11z" fill="#bf9665" />
    <path d="M288 149h24v27h-24z" fill="#397464" />
    <path d="M288 148h24v4h-24zm2 3h3v8h-3zm18 0h3v8h-3z" fill="#eddfb2" />
    <path d="M284 151h5v12h-5zm28 0h5v12h-5z" fill="#c69b68" />
    <text x="300" y="169" textAnchor="middle" fontFamily="CareerPixel, monospace" fontSize="11" fontWeight="bold" fill="#e5d8b0">{number}</text>
    <path d="M289 175h23v5h-9v-4h-5v4h-9z" fill="#3b7362" />
    <path d="M289 180h7v6h-7zm16 0h7v6h-7z" fill="#ca9e68" />
    <path d="M287 185h11v4h-11zm17 0h11v4h-11z" fill="#eee0b6" />
    <path d="M316 154h12v11h-12z" fill="#b0773e" />
    <path d="M319 154v11m5-11v11m-8-7h12" stroke="#6f5632" strokeWidth="1" />
    <g fill="#71934e">{Array.from({length:37},(_,i)=> i>12&&i<25 ? null : <path key={i} d={`M${5+i*16} 192v-${i%2?11:7}h6v${i%2?11:7}z`} />)}</g>
    <g fill="#8ca65b">{Array.from({length:37},(_,i)=> i>12&&i<25 ? null : <path key={i} d={`M${11+i*16} 192v-${i%2?7:12}h5v${i%2?7:12}z`} />)}</g>
  </svg>;
}
