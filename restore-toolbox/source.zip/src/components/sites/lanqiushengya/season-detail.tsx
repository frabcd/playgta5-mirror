"use client";

import { useEffect, useRef, useState } from "react";
import { allSeasonGames, nextRegularMatch, overall, SEASON_LENGTH, type Career, type GameResult } from "@/lib/lanqiushengya/engine";
import { getRoster, getRosterSource, ROSTER_NOTE } from "@/lib/lanqiushengya/rosters";
import { MatchBoxScore, MatchTimeline } from "./match-center";
import styles from "./season-detail.module.css";

type Props = { career: Career; onChange: (career: Career) => void; onPlay?: () => void };
type DetailTab = "schedule" | "scout" | "goals";
const stageLabels: Record<string, string> = { regular: "常规赛", conference: "联盟锦标赛", national: "全国锦标赛", playin: "附加赛", playoffs: "季后赛" };
const boxLabels = [["pts", "得分"], ["reb", "篮板"], ["ast", "助攻"], ["stl", "抢断"], ["blk", "盖帽"], ["to", "失误"]] as const;
const rate = (made: number, attempted: number) => attempted ? `${(100 * made / attempted).toFixed(1)}%` : "—";
const doubleDouble = (game: GameResult) => [game.pts, game.reb, game.ast, game.stl, game.blk].filter(value => value >= 10).length >= 2;

function CompleteReview({ game, onClose }: { game: GameResult; onClose: () => void }) {
  return <section className={styles.review} aria-label="赛程比赛回顾"><div className={styles.heading}><h3>完整比赛回顾</h3><button onClick={onClose}>收起</button></div><p className={styles.eyebrow}>{stageLabels[game.stage ?? "regular"]} · {game.home ? "主场" : "客场"} · {game.won ? "胜利" : "失利"}</p><div className={styles.score}><span>{game.team ?? "本队"}</span><strong>{game.teamScore} : {game.opponentScore}</strong><span>{game.opponent}</span></div><div className={styles.stats}>{boxLabels.map(([key, label]) => <div key={key}><span>{label}</span><b>{game[key] ?? "—"}</b></div>)}</div><p>{game.min > 0 ? `${game.min} 分钟${game.started === undefined ? "" : game.started ? " · 首发" : " · 替补"}` : "未出场"} · 投篮 {game.fgm}/{game.fga}（{rate(game.fgm, game.fga)}）· 三分 {game.tpm}/{game.tpa}（{rate(game.tpm, game.tpa)}）· 罚球 {game.ftm}/{game.fta}（{rate(game.ftm, game.fta)}）</p><MatchTimeline game={game} /><MatchBoxScore game={game} />{!game.boxScore && <p className={styles.muted}>这场旧比赛未保存双方球员数据，保留原有个人比赛记录。</p>}</section>;
}

export function SeasonDetail({ career, onPlay }: Props) {
  const [tab, setTab] = useState<DetailTab>("schedule");
  const [selectedId, setSelectedId] = useState<string>();
  const [filter, setFilter] = useState("all");
  const [scoutIndex, setScoutIndex] = useState<number>();
  const rootRef = useRef<HTMLElement>(null);
  useEffect(() => {
    if (selectedId && tab === "schedule") rootRef.current?.querySelector('[aria-label="赛程比赛回顾"]')?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [selectedId, tab]);
  const regular = career.games.filter(game => game.season === career.season && (!game.stage || game.stage === "regular"));
  const length = career.phase === "retired" ? (regular[0]?.phase === "college" ? 30 : 82) : SEASON_LENGTH[career.phase];
  const games = allSeasonGames(career);
  const postseason = games.filter(game => game.stage && game.stage !== "regular");
  const selected = games.find(game => game.id === selectedId);
  const fixtures = Array.from({ length }, (_, index) => ({ index, game: regular[index], ...nextRegularMatch({ ...career, game: index }) }));
  const upcoming = career.phase !== "retired" && career.game < length;
  const targetIndex = Math.min(length - 1, Math.max(career.game, scoutIndex ?? career.game));
  const target = fixtures[targetIndex];
  const opponent = target?.game?.opponent ?? target?.opponent ?? "";
  const opponentRoster = getRoster(opponent, career.season);
  const teamRoster = getRoster(career.team, career.season);
  const topFive = opponentRoster.slice(0, 5);
  const source = getRosterSource(opponent);
  const averageRating = (roster: typeof opponentRoster) => roster.length ? (roster.slice(0, 8).reduce((sum, player) => sum + player.rating, 0) / Math.min(8, roster.length)).toFixed(1) : "—";
  const appearances = games.filter(game => game.min > 0);
  const recent = appearances.slice(-5);
  const mean = (rows: GameResult[], key: "pts" | "reb" | "ast") => rows.length ? (rows.reduce((sum, game) => sum + game[key], 0) / rows.length).toFixed(1) : "—";
  const peak = appearances.reduce<GameResult | undefined>((best, game) => !best || game.pts > best.pts ? game : best, undefined);
  const wins = regular.filter(game => game.won).length;
  const goals = [
    { label: "站稳轮换", detail: "累计出场 10 场", value: appearances.length, target: 10 },
    { label: "得分爆发", detail: "单场取得 20 分", value: peak?.pts ?? 0, target: 20 },
    { label: "全面贡献", detail: "赛季累计 5 次两双", value: appearances.filter(doubleDouble).length, target: 5 },
    { label: "争取胜率过半", detail: `赢下 ${Math.floor(length / 2) + 1} 场常规赛`, value: wins, target: Math.floor(length / 2) + 1 },
  ];
  return <section className={styles.root} ref={rootRef}><div className={styles.heading}><div><p className={styles.eyebrow}>SEASON NOTEBOOK</p><h2>赛季手册</h2></div><span className={styles.badge}>{career.season}–{String(career.season + 1).slice(-2)} · {career.team}</span></div><div className={styles.tabs}>{([["schedule", "赛程"], ["scout", "赛前球探"], ["goals", "赛季目标"]] as const).map(([value, label]) => <button key={value} aria-pressed={tab === value} onClick={() => setTab(value)}>{label}</button>)}</div>
    {tab === "schedule" && <><div className={styles.banner}><div><b>常规赛 {regular.length} / {length} 场</b><p>{wins} 胜 · {regular.length - wins} 负{postseason.length ? ` · 已进行 ${postseason.length} 场淘汰阶段比赛` : ""}</p></div>{upcoming && <button className={styles.primary} disabled={!onPlay} onClick={onPlay}>准备第 {career.game + 1} 场 →</button>}</div><div className={styles.filters}><label>显示比赛<select value={filter} onChange={event => setFilter(event.target.value)}><option value="all">完整常规赛</option><option value="played">已完成</option><option value="upcoming">待进行</option></select></label><p className={styles.muted}>按场次查看赛季旅程；未来对阵以当前球队为准。</p></div>{selected && <CompleteReview game={selected} onClose={() => setSelectedId(undefined)} />}<div className={styles.tableWrap}><table><thead><tr><th>场次</th><th>主 / 客</th><th>对手</th><th>结果</th><th>个人表现</th><th>操作</th></tr></thead><tbody>{fixtures.filter(fixture => filter === "all" || (filter === "played" ? !!fixture.game : !fixture.game)).map(fixture => <tr key={fixture.index} className={fixture.index === career.game && upcoming ? styles.next : undefined}><td>第 {fixture.index + 1} 场{fixture.index === career.game && upcoming && <small>下一场</small>}</td><td>{(fixture.game?.home ?? fixture.home) ? "主场" : "客场"}</td><td>{fixture.game?.opponent ?? fixture.opponent}</td><td className={fixture.game ? fixture.game.won ? styles.win : styles.loss : undefined}>{fixture.game ? `${fixture.game.won ? "胜" : "负"} ${fixture.game.teamScore}–${fixture.game.opponentScore}` : "待进行"}</td><td>{fixture.game ? fixture.game.min ? `${fixture.game.pts}分 ${fixture.game.reb}板 ${fixture.game.ast}助` : "未出场" : "—"}</td><td>{fixture.game ? <button onClick={() => setSelectedId(fixture.game!.id)}>比赛回顾</button> : <button onClick={() => { setScoutIndex(fixture.index); setTab("scout"); }}>查看对手</button>}</td></tr>)}</tbody></table></div>{postseason.length > 0 && <><h3>锦标赛 / 季后赛记录</h3><div className={styles.postseason}>{postseason.map(game => <button key={game.id} onClick={() => setSelectedId(game.id)}><span>{stageLabels[game.stage ?? "playoffs"]}</span><b>{game.opponent}</b><small className={game.won ? styles.win : styles.loss}>{game.won ? "胜" : "负"} {game.teamScore}–{game.opponentScore} · 查看回顾</small></button>)}</div></>}</>}
    {tab === "scout" && <>{upcoming ? <><div className={styles.banner}><div><span className={styles.eyebrow}>常规赛 · 第 {targetIndex + 1} 场</span><h3>{career.team} vs {opponent}</h3><p>{target?.home ? "主场迎战" : "客场挑战"} · {topFive[0] ? `重点关注 ${topFive[0].name}` : "对手名单尚未收录"}</p></div>{targetIndex === career.game && <button className={styles.primary} disabled={!onPlay} onClick={onPlay}>进入本场比赛 →</button>}</div><div className={styles.comparison}><div><span>本队前八人平均能力</span><b>{averageRating(teamRoster)}</b></div><div><span>对手前八人平均能力</span><b>{averageRating(opponentRoster)}</b></div><div><span>你的当前综合能力</span><b>{overall(career.player)}</b></div></div><p className={styles.muted}>球队强度为名单前八人能力值的本地估计，不是官方实力评级，也不代表保证胜率。</p><h3>重点球员 · 能力前五</h3>{topFive.length ? <div className={styles.players}>{topFive.map(player => <article key={player.id}><span>{player.position} · #{player.number ?? "—"}</span><h4>{player.name}</h4><b>{player.rating}</b><small>{player.height ? `${player.height} cm · ` : ""}{player.generated ? "模拟发展球员" : "资料名单球员"}</small></article>)}</div> : <p className={styles.muted}>没有已收录的球员资料。</p>}<h3>位置对照</h3><div className={styles.tableWrap}><table><thead><tr><th>位置</th><th>本队重点球员</th><th>对手重点球员</th><th>能力差</th></tr></thead><tbody>{(["PG", "SG", "SF", "PF", "C"] as const).map(position => { const own = career.player.position === position ? { name: `${career.player.name}（你）`, rating: overall(career.player) } : teamRoster.find(player => player.position === position); const other = opponentRoster.find(player => player.position === position); const difference = own && other ? own.rating - other.rating : null; return <tr key={position}><td>{position}</td><td>{own ? `${own.name} · ${own.rating}` : "无位置资料"}</td><td>{other ? `${other.name} · ${other.rating}` : "无位置资料"}</td><td>{difference === null ? "—" : `${difference > 0 ? "+" : ""}${difference}`}</td></tr>; })}</tbody></table></div><p className={styles.muted}>位置对照选取本队同位置能力最高的队友与你，以及对手同位置能力最高的球员，供赛前参考；不预测实际首发。</p><p className={styles.muted}>{ROSTER_NOTE}{source && <> <a href={source.url} target="_blank" rel="noreferrer">查看{opponent}名单来源</a>（{source.season}）</>}</p></> : <p className={styles.empty}>本赛季常规赛已结束。请到淘汰赛页面查看下一轮对阵，或开启下一赛季。</p>}</>}
    {tab === "goals" && <><p className={styles.muted}>个人赛季里程碑根据已保存的比赛更新。下列目标用于追踪成长，不额外发放训练点或保证赛季奖项。</p><div className={styles.goals}>{goals.map(goal => <article key={goal.label}><div className={styles.heading}><h3>{goal.label}</h3><span className={goal.value >= goal.target ? styles.win : styles.muted}>{goal.value >= goal.target ? "已达成 ✓" : "进行中"}</span></div><p>{goal.detail}</p><progress max={goal.target} value={Math.min(goal.value, goal.target)} aria-label={goal.label} /><b>{goal.value} / {goal.target}</b></article>)}</div><h3>近期五场 · 出场表现</h3><div className={styles.comparison}>{([["pts", "场均得分"], ["reb", "场均篮板"], ["ast", "场均助攻"]] as const).map(([key, label]) => <div key={key}><span>{label}</span><b>{mean(recent, key)}</b><small>赛季 {mean(appearances, key)}</small></div>)}</div><div className={styles.trend}>{recent.map(game => <div key={game.id}><b className={game.won ? styles.win : styles.loss}>{game.won ? "胜" : "负"}</b><span>{game.pts} 分</span><small>{game.opponent}</small></div>)}</div><p className={styles.muted}>最近 {recent.length} 场有出场时间的比赛，包含锦标赛和季后赛；未出场比赛不计入场均。</p><div className={styles.banner}><div><h3>本赛季得分代表作</h3><p>{peak ? `对阵${peak.opponent} · ${peak.pts} 分 ${peak.reb} 篮板 ${peak.ast} 助攻 · ${peak.teamScore}–${peak.opponentScore}` : "完成比赛后记录将出现在这里。"}</p></div>{peak && <button onClick={() => { setSelectedId(peak.id); setTab("schedule"); }}>查看完整回顾</button>}</div></>}
  </section>;
}
