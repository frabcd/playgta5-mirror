"use client";

import { useState } from "react";
import { GROUP_LABELS, RATING_LABELS, type Career } from "@/lib/lanqiushengya/engine";
import { chooseStory, getAvailableStory, getStoryState } from "@/lib/lanqiushengya/story";
import styles from "./career-story.module.css";

type Props = { career: Career; onChange: (career: Career) => void };
type StoryRecord = ReturnType<typeof getStoryState>["history"][number];
const meterLabels = { chemistry: "球队默契", reputation: "球员声望", pressure: "心理压力", academics: "学业状态", leadership: "领袖影响" };
const effectLabels: Record<string, string> = { ...meterLabels, ...GROUP_LABELS, ...RATING_LABELS, energy: "体力", confidence: "信心", trust: "教练信任", salary: "年薪", role: "球队地位" };

function effectParts(value: unknown, path: string[] = []): string[] {
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  return Object.entries(value).flatMap(([key, change]) => {
    if (typeof change === "object") return effectParts(change, [...path, key]);
    if (typeof change !== "number" || !change) return [];
    const suffix = path.includes("points") ? "训练点" : "";
    return [`${effectLabels[key] ?? key}${suffix} ${change > 0 ? "+" : ""}${Number(change.toFixed(1))}`];
  });
}

function Effects({ effects }: { effects: unknown }) {
  const parts = effectParts(effects);
  return <>{parts.length ? parts.join(" · ") : "记录你的选择"}</>;
}

function actualChanges(before: unknown, after: unknown, path: string[] = []): string[] {
  if (!before || !after || typeof before !== "object" || typeof after !== "object") return [];
  const previous = before as Record<string, unknown>;
  return Object.entries(after).flatMap(([key, value]) => {
    if (typeof value === "object") return actualChanges(previous[key], value, [...path, key]);
    const old = previous[key];
    if (typeof value !== "number" || typeof old !== "number" || value === old || !effectLabels[key]) return [];
    const difference = Number((value - old).toFixed(1));
    const suffix = path.includes("points") ? "训练点" : "";
    return [`${effectLabels[key]}${suffix} ${Number(old.toFixed(1))} → ${Number(value.toFixed(1))}（${difference > 0 ? "+" : ""}${difference}）`];
  });
}

function SavedEffects({ record }: { record: StoryRecord }) {
  const changes = actualChanges(record.before, record.after);
  return <>{changes.length ? changes.join(" · ") : "选择已保存，当前数值没有变化。"}</>;
}

function HistoryList({ career }: { career: Career }) {
  const state = getStoryState(career);
  const [selectedSeason, setSelectedSeason] = useState("all");
  const seasons = [...new Set(state.history.map(record => record.season))].sort((a, b) => b - a);
  const visibleSeason = seasons.includes(Number(selectedSeason)) ? selectedSeason : "all";
  const selected = state.history.filter(record => visibleSeason === "all" || record.season === Number(visibleSeason)).slice().reverse();
  return <>
    <div className={styles.archiveHead}><h3>生涯手记 <span className={styles.count}>· {state.history.length} 个选择</span></h3><select aria-label="按赛季筛选生涯故事" value={visibleSeason} onChange={e => setSelectedSeason(e.target.value)}><option value="all">所有赛季</option>{seasons.map(season => <option key={season} value={season}>{season}–{String(season + 1).slice(-2)} 赛季</option>)}</select></div>
    {selected.length ? <ol className={styles.history}>{selected.map(record => <li key={record.key}><details className={styles.entry}><summary><span className={styles.entryDate}>{record.season}<br />第 {record.game} 场</span><span><span className={styles.entryTitle}>{record.title}</span><br /><span>{record.choiceLabel}</span></span></summary><div className={styles.entryContent}><p>{record.phase === "college" ? "大学生涯" : "职业生涯"} · {record.context}</p><p>{record.body}</p><p className={styles.entryChoice}>你的选择：{record.choiceLabel}</p><p>{record.outcome}</p><p><SavedEffects record={record} /></p></div></details></li>)}</ol> : <p className={styles.hint}>每一次决定，都会成为你的篮球故事。完成第一个选择后，记录会出现在这里。</p>}
  </>;
}

export function StoryArchive({ career }: { career: Career }) {
  return <section className={styles.panel}><HistoryList career={career} /></section>;
}

export function StoryPanel({ career, onChange }: Props) {
  const state = getStoryState(career);
  const event = getAvailableStory(career);
  const [showArchive, setShowArchive] = useState(false);
  const [dismissed, setDismissed] = useState<string | null>(null);
  const [chosenKey, setChosenKey] = useState<string | null>(null);
  const seasonHistory = state.history.filter(record => record.season === career.season);
  const latest = seasonHistory.find(record => record.key === chosenKey) ?? seasonHistory.at(-1);
  const result = latest && latest.key !== dismissed ? latest : undefined;
  const meters = ["chemistry", "reputation", "pressure", career.phase === "college" ? "academics" : "leadership"] as const;
  const choose = (eventId: string, choiceId: string) => {
    const next = chooseStory(career, eventId, choiceId);
    const before = new Set(state.history.map(record => record.key));
    const record = getStoryState(next).history.find(item => !before.has(item.key));
    if (record) { setChosenKey(record.key); setDismissed(null); }
    onChange(next);
  };
  return <section className={styles.panel} aria-label="生涯故事">
    <div className={styles.heading}><div><div className={styles.eyebrow}>{career.phase === "college" ? "CAMPUS DIARY" : "COURTSIDE DIARY"} · {career.season}–{String(career.season + 1).slice(-2)}</div><h2>球场之外，也有你的故事</h2></div><span className={styles.tag}>本季 {seasonHistory.length} 段经历</span></div>
    {result && <ChoiceResult record={result} onDismiss={() => setDismissed(result.key)} />}
    {event && career.phase !== "retired" ? <><article className={styles.scene}><p className={styles.sceneMeta}>第 {seasonHistory.length + 1} 章 · {event.context}</p><h3>{event.title}</h3><p>{event.body}</p></article><div className={styles.choices}>{event.choices.map((choice, index) => <button key={choice.id} className={styles.choice} onClick={() => choose(event.id, choice.id)}><span className={styles.choiceIndex}>{String.fromCharCode(65 + index)}</span><span><strong>{choice.label}</strong><small>{choice.description}</small><small><Effects effects={getStoryState(chooseStory(career, event.id, choice.id)).history.at(-1)?.effects ?? choice.effects} /></small></span><span className={styles.arrow}>→</span></button>)}</div></> : <div className={styles.quiet}><strong>{career.phase === "retired" ? "每一页，都是来时的路" : "把这一刻，留在球场上"}</strong>{career.phase === "retired" ? "翻阅生涯手记，重温你做过的决定。" : "这一阶段的故事已经记录。继续推进赛季，新的经历会随旅程展开。"}</div>}
    <div className={styles.meters}>{meters.map(key => <div key={key}><div className={styles.meterLabel}><span>{meterLabels[key]}</span><strong>{state.meters[key]}</strong></div><div className={`${styles.track} ${key === "pressure" ? styles.pressure : ""}`} role="meter" aria-label={meterLabels[key]} aria-valuenow={state.meters[key]} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${Math.max(0, Math.min(100, state.meters[key]))}%` }} /></div></div>)}</div>
    <p className={styles.hint}>默契影响配合，声望与压力影响得分发挥，领袖影响防守；这些影响幅度较小，比赛仍由能力、状态与战术共同决定。选择和实际变化会永久记入本机生涯手记。数值范围为 0–100；剧情为原创虚构。</p>
    <button className={styles.archiveToggle} onClick={() => setShowArchive(!showArchive)} aria-expanded={showArchive}>{showArchive ? "收起生涯手记 −" : `翻阅生涯手记 · ${state.history.length} 个选择 ＋`}</button>
    {showArchive && <div className={styles.embeddedArchive}><HistoryList career={career} /></div>}
  </section>;
}

function ChoiceResult({ record, onDismiss }: { record: StoryRecord; onDismiss: () => void }) {
  return <div className={styles.result} role="status"><h3>✓ 已记入生涯手记 · {record.title}</h3><p><strong>{record.choiceLabel}</strong></p><p>{record.outcome}</p>{record.followUp && <p className={styles.hint}>这次选择留下了后续线索。最早再推进 2 场比赛后，新的片段会在符合条件时出现。</p>}<p className={styles.resultEffects}><SavedEffects record={record} /></p><button className={styles.closeResult} onClick={onDismiss}>收好这一页</button></div>;
}
