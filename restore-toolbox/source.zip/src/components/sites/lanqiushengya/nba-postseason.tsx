"use client";
import { useState, type ReactNode } from 'react';
import type { Career } from '@/lib/lanqiushengya/engine';
import { playoffSeed, type NbaSeries, type NbaState } from '@/lib/lanqiushengya/nba';
import { TournamentBracket } from './tournament-bracket';
import s from './nba-dashboard.module.css';

function seed(n: NbaState, team: string, playoff: boolean) {
  if(playoff) return playoffSeed(n,team);
  return n.standings.find(t=>t.team===team)?.seed;
}
export function seriesStatus(row: NbaSeries) {
  if(row.winner) return `${row.winner} ${Math.max(row.homeWins,row.awayWins)}–${Math.min(row.homeWins,row.awayWins)} ${row.round===4?'夺冠':'晋级'}`;
  if(!row.home||!row.away) return '等待前轮结果';
  if(row.round===0) return '单场定胜负';
  if(row.homeWins===3&&row.awayWins===3) return '抢七大战 · 胜者晋级';
  if(row.homeWins===3||row.awayWins===3) return `${row.homeWins===3?row.home:row.away}握有赛点`;
  return `系列赛 ${row.homeWins}–${row.awayWins} · 下一场 G${row.homeWins+row.awayWins+1}`;
}
export function NbaPostseason({career,controls}:{career:Career;controls:ReactNode}) {
  const [year,setYear]=useState(career.season);
  const seasons=[career.nba,...(career.nbaHistory??[])].filter((n):n is NbaState=>!!n).sort((a,b)=>b.season-a.season);
  const n=seasons.find(n=>n.season===year)??career.nba;
  if(!n)return null;
  const ownTeam=n.playoffGames.find(g=>g.team)?.team??career.history.find(h=>h.season===n.season)?.team??career.team;
  const own=n.series.filter(row=>row.home===ownTeam||row.away===ownTeam);
  const eliminated=own.find(row=>row.round>0&&row.winner&&row.winner!==ownTeam);
  const qualified=n.series.some(row=>row.round===1&&(row.home===ownTeam||row.away===ownTeam));
  const played=n.playoffGames.filter(g=>g.stage!=='playin'&&g.min>0);
  const final=n.series.find(row=>row.round===4), fmvp=n.awards.find(a=>a.name==='总决赛 MVP');
  const match=(row:NbaSeries,i:number,round:number)=>({id:row.id??`${row.conference}-${row.round}-${i}`,round,home:row.home,away:row.away,homeSeed:seed(n,row.home,row.round>0),awaySeed:seed(n,row.away,row.round>0),homeScore:row.homeWins,awayScore:row.awayWins,winner:row.winner,homePlaceholder:row.round===0?'7/8 败者':'上轮胜者',awayPlaceholder:row.round===0?'9/10 胜者':'上轮胜者',detail:seriesStatus(row),results:row.scores?.map(g=>({label:`G${g.game} · ${g.home}主场`,score:`${g.home} ${g.homeScore}–${g.awayScore} ${g.away}`}))});
  return <section className={s.panel}><div className={s.heading}><h3>通往总冠军</h3><select aria-label="季后赛赛季" value={n.season} onChange={e=>setYear(Number(e.target.value))}>{seasons.map(n=><option key={n.season} value={n.season}>{n.season}–{String(n.season+1).slice(-2)}</option>)}</select></div>
    <p className={s.muted}>前六直接晋级；7/8 胜者成为第七种子，败者与 9/10 胜者争第八。四轮七场四胜，主场顺序 2–2–1–1–1。对阵图显示实际季后赛种子。</p>
    {n.season===career.season&&<div className={s.actions}>{controls}</div>}
    {!n.series.length?<p className={s.empty}>常规赛结束后公布对阵。</p>:<>
      <div className={s.note}><strong>{ownTeam} · {n.champion===ownTeam?'总冠军':eliminated?`止步${['','首轮','分区半决赛','分区决赛','总决赛'][eliminated.round]}`:qualified?'季后赛之旅':n.stage==='playin'?'等待附加赛结果':'未晋级季后赛'}</strong><p>个人季后赛出场 {played.length} 场 · 场均 { (played.reduce((v,g)=>v+g.pts,0)/Math.max(1,played.length)).toFixed(1)} 分 / {(played.reduce((v,g)=>v+g.reb,0)/Math.max(1,played.length)).toFixed(1)} 篮板 / {(played.reduce((v,g)=>v+g.ast,0)/Math.max(1,played.length)).toFixed(1)} 助攻（不含附加赛）</p></div>
      {final?.winner&&<div className={s.award}><h3>🏆 {final.winner}</h3><p>总决赛：{final.home} {final.homeWins}–{final.awayWins} {final.away}</p><p>总决赛 MVP：{fmvp?.winner??'未记录'}</p></div>}
      <h4>你的晋级路线</h4>{own.map((row,i)=><p key={row.id??i}>{['附加赛','首轮','分区半决赛','分区决赛','总决赛'][row.round]} · {row.home} vs {row.away} · {seriesStatus(row)}</p>)}
      {['东部','西部'].map(conf=><div key={conf}><TournamentBracket title={`${conf}附加赛`} rounds={['7/8 · 9/10','第八种子争夺']} team={ownTeam} matches={n.series.filter(r=>r.round===0&&r.conference===conf).map((r,i)=>match(r,i,i<2?0:1))}/><TournamentBracket title={`${conf}季后赛`} rounds={['首轮','分区半决赛','分区决赛']} team={ownTeam} matches={n.series.filter(r=>r.round>0&&r.conference===conf).map((r,i)=>match(r,i,r.round-1))}/></div>)}
      <TournamentBracket title="NBA 总决赛" rounds={['东西部冠军争冠']} team={ownTeam} matches={final?[match(final,0,0)]:[]}/>
    </>}
  </section>;
}
