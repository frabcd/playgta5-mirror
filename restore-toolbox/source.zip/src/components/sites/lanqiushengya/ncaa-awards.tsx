"use client";

import { useState } from "react";
import type { Career } from "@/lib/lanqiushengya/engine";
import { ensureNcaa, type NcaaAward } from "@/lib/lanqiushengya/ncaa";
import { getRoster, getRosterSource } from "@/lib/lanqiushengya/rosters";
import styles from "./nba-dashboard.module.css";

const categories = [["all", "全部荣誉"], ["conference", "联盟荣誉"], ["national", "全国荣誉"], ["tournament", "锦标赛荣誉"]] as const;
const rules: [string, NcaaAward['category'], string][] = [
  ["联盟年度最佳球员", "conference", "常规赛场均得分 + 篮板 + 助攻 ≥ 27"],
  ["联盟最佳防守球员", "conference", "常规赛场均抢断 + 盖帽 ≥ 3.2"],
  ["联盟最佳新秀", "conference", "大学第一年；常规赛场均得分 + 篮板 + 助攻 ≥ 18"],
  ["联盟最佳阵容一队", "conference", "常规赛场均得分 + 篮板 + 助攻 ≥ 22"],
  ["联盟最佳新秀阵容", "conference", "大学第一年；常规赛场均得分 + 篮板 + 助攻 ≥ 14"],
  ["联盟最佳防守阵容", "conference", "常规赛场均抢断 + 盖帽 ≥ 2.4"],
  ["奈史密斯年度最佳球员", "national", "常规赛场均得分 + 篮板 + 助攻 ≥ 32"],
  ["伍登奖", "national", "常规赛场均得分 + 篮板 + 助攻 ≥ 33"],
  ["奈史密斯最佳防守球员", "national", "常规赛场均抢断 + 盖帽 ≥ 4.5"],
  ["提斯代尔最佳新秀", "national", "大学第一年；常规赛场均得分 + 篮板 + 助攻 ≥ 27"],
  ["全美最佳阵容", "national", "常规赛场均得分 + 篮板 + 助攻 ≥ 29"],
  ["联盟锦标赛冠军", "tournament", "联盟锦标赛三连胜"],
  ["联盟锦标赛最杰出球员 MOP", "tournament", "联盟冠军；锦标赛三场平均得分 + 篮板 + 助攻 ≥ 20"],
  ["全国锦标赛冠军", "tournament", "赢得全国锦标赛全部六轮单场淘汰赛"],
  ["最终四强最杰出球员 MOP", "tournament", "全国冠军；最终四强两场平均得分 + 篮板 + 助攻 ≥ 20"],
];

export function NcaaAwards({ career }: { career: Career }) {
  const ready = ensureNcaa(career);
  const records = [...(ready.ncaaHistory ?? []), ...(ready.ncaa ? [ready.ncaa] : [])];
  const seasons = [...new Set([...(career.phase === 'college' ? [career.season] : []), ...records.map(n => n.season), ...career.history.filter(s => s.phase === 'college').map(s => s.season)])].sort((a, b) => b - a);
  const [selectedSeason, setSelectedSeason] = useState(seasons[0] ?? career.season);
  const [category, setCategory] = useState<string>('all');
  const [ownOnly, setOwnOnly] = useState(false);
  const year = seasons.includes(selectedSeason) ? selectedSeason : seasons[0];
  const record = records.findLast(n => n.season === year);
  const seasonRecord = career.history.find(s => s.season === year && s.phase === 'college');
  const team = seasonRecord?.team ?? career.team;
  const regular = career.games.filter(g => g.season === year && (!g.stage || g.stage === 'regular') && g.min > 0);
  const avg = (key: 'pts' | 'reb' | 'ast' | 'stl' | 'blk' | 'min') => regular.reduce((n, g) => n + g[key], 0) / Math.max(1, regular.length);
  const awards = record?.awards ?? [];
  const positionAward = `${({ PG: '鲍勃·库西', SG: '杰里·韦斯特', SF: '朱利叶斯·欧文', PF: '卡尔·马龙', C: '卡里姆·贾巴尔' })[career.player.position]}位置奖`;
  const catalog = [...rules, [positionAward, 'national', '对应位置；常规赛场均得分 + 篮板 + 助攻 ≥ 28'] as typeof rules[number]];
  const additional = awards.filter(a => !catalog.some(r => r[0] === a.name)).map(a => [a.name, a.category, a.detail] as typeof rules[number]);
  const shown = [...catalog, ...additional].filter(([name, kind]) => (category === 'all' || category === kind) && (!ownOnly || awards.some(a => a.name === name && a.player)));
  const ownAwards = awards.filter(a => a.player);
  const legacy = career.honors.filter(h => h.startsWith(`${year} `) && !awards.some(a => h === `${year} ${a.name}`));
  const unannounced = !record || record.stage === 'regular';
  const earnedBy = (name: string) => awards.filter(a => a.name === name);
  return <div className={styles.dashboard}><section className={styles.panel}>
    <div className={styles.heading}><div><div className={styles.eyebrow}>{year ? `${year}–${String(year + 1).slice(-2)}` : ''} · NCAA HONORS</div><h2>大学赛季荣誉榜</h2></div><span className={styles.badge}>个人荣誉 {ownAwards.length}</span></div>
    {seasons.length > 0 && <div className={styles.filters}><label>奖项赛季 <select aria-label="大学奖项赛季" value={year} onChange={e => setSelectedSeason(Number(e.target.value))}>{seasons.map(s => <option key={s} value={s}>{s}–{String(s + 1).slice(-2)}{s === career.season ? ' · 本赛季' : ''}</option>)}</select></label></div>}
    <p className={styles.muted}>常规赛结束后结算联盟与全国个人奖项；锦标赛荣誉随赛事结束结算。属于你的奖项以金色标记。以下采用本地游戏评选规则。</p>
    <div className={styles.tabs}>{categories.map(([key, label]) => <button key={key} aria-pressed={category === key} className={category === key ? styles.active : ''} onClick={() => setCategory(key)}>{label}</button>)}<button aria-pressed={ownOnly} className={ownOnly ? styles.active : ''} onClick={() => setOwnOnly(!ownOnly)}>★ {ownOnly ? '仅我的荣誉' : '筛选我的荣誉'}</button></div>
    <div className={styles.stats}><div><span>常规赛实际出场 · 至少 21 场</span><strong>{regular.length}</strong></div><div><span>场均分钟 · 至少 10 分钟</span><strong>{avg('min').toFixed(1)}</strong></div><div><span>得分 + 篮板 + 助攻</span><strong>{(avg('pts') + avg('reb') + avg('ast')).toFixed(1)}</strong></div></div>
    <details className={styles.note}><summary>查看评选口径与资格</summary><p>常规赛个人奖项要求实际出场至少 21 场、场均至少 10 分钟；统计不包含锦标赛。新秀奖项只限大学生涯第一年，转学不重置资格。</p><p>你的常规赛场均防守贡献：{(avg('stl') + avg('blk')).toFixed(1)}（抢断 + 盖帽）。奖项判断采用未四舍五入的数据。</p><p>此页面展示存档已记录的得主。名单来源只验证真实球员身份；这里的奖项和统计均属于本地模拟赛季。</p></details>
    {shown.length ? <div className={styles.awardGrid}>{shown.map(([name, kind, rule]) => {
      const winners = earnedBy(name);
      const earned = winners.some(a => a.player);
      const pending = unannounced || (kind === 'tournament' && (name.startsWith('联盟') ? !record?.conferenceChampion : record?.stage !== 'complete'));
      return <article key={name} className={`${styles.award} ${earned ? styles.earned : ''}`}><h4>{earned ? '★ ' : ''}{name}</h4>{winners.length ? winners.map((winner, i) => {
        const roster = getRoster(winner.team, year).find(p => p.name === winner.winner);
        const source = roster && !roster.generated ? getRosterSource(winner.team) : undefined;
        return <div key={`${winner.winner}-${i}`}><p><b>{winner.winner}</b> · {winner.team}{winner.player ? ' · 你' : ''}</p><p className={styles.muted}>{winner.detail}</p>{winner.members&&<p>入选阵容：{winner.members.map(p=>p.name+(p.player?'（你）':'')).join('、')}</p>}{winner.candidates&&<details><summary>查看候选人排名</summary>{winner.candidates.map((p,index)=><p key={p.id}>{index+1}. {p.name} · {p.team} · {p.games} 场 · {p.pts.toFixed(1)} 分 / {p.reb.toFixed(1)} 板 / {p.ast.toFixed(1)} 助</p>)}</details>}{source && <p className={styles.muted}><a href={source.url} target="_blank" rel="noreferrer">球员名单来源 · {source.season}</a></p>}</div>;
      }) : <p className={styles.muted}>{pending ? '尚未结算' : '你未获得此项荣誉；存档暂无其他得主记录。'}</p>}<p className={styles.muted}>评选条件：{kind==='tournament'?rule:'按合格候选人的赛季表现排名；防守奖侧重抢断、盖帽与篮板，新秀奖限第一年。'}</p></article>;
    })}</div> : <p className={styles.empty}>{ownOnly ? '这个赛季尚无符合筛选的个人荣誉。' : '尚无大学赛季记录。'}</p>}
    {legacy.length > 0 && <details className={styles.note}><summary>旧存档荣誉记录 · {legacy.length} 项</summary>{legacy.map(h => <p key={h}>★ {h}</p>)}<p className={styles.muted}>旧存档未保存完整评选详情。</p></details>}
    {(record?.conferenceChampion || record?.champion) && <div className={styles.note}>{record.conferenceChampion && <p>联盟锦标赛冠军：{record.conferenceChampion}</p>}{record.champion && <p>全国锦标赛冠军：{record.champion}</p>}<p>{team} · {record.finish ?? '赛季进行中'}</p></div>}
  </section></div>;
}
