"use client";
import { useState } from "react";
import { NBA_TEAMS, RATING_LABELS, type Career, type RatingKey } from "@/lib/lanqiushengya/engine";
import { DEVELOPMENT_PLANS, collegeOffers, isOffseason, resolveOffseason, seasonDebrief, teamFit, type DevelopmentFocus } from "@/lib/lanqiushengya/offseason";
import styles from "./offseason-desk.module.css";

export function OffseasonDesk({career:c,onChange}:{career:Career;onChange:(c:Career)=>void}) {
  const [focus,setFocus]=useState<DevelopmentFocus>('shooting');
  const [destination,setDestination]=useState(c.team);
  const [draft,setDraft]=useState(false);
  const ready=isOffseason(c), summary=seasonDebrief(c);
  const college=c.phase==='college';
  const finalCollegeYear=college&&new Set([...c.history.filter(s=>s.phase==='college').map(s=>s.season),c.season]).size>=4;
  const freeAgent=!college&&c.contract.years<=1;
  const offers=college?collegeOffers(c):freeAgent?NBA_TEAMS:[c.team];
  const selected=offers.includes(destination)?destination:c.team;
  const fit=teamFit(c,selected);
  const previous=c.offseasons?.at(-1);
  return <div className={styles.root}><section className={styles.panel}><div className={styles.heading}><div><small>THE NEXT CHAPTER</small><h2>{college?'大学休赛期 · 下一步去哪':'职业休赛期 · 再向前一步'}</h2></div><span>{ready?'休赛期开放':'赛季进行中'}</span></div><p className={styles.note}>{ready?'回顾这个赛季，然后选择训练重点和下一站。确认后结算自然成长与专项训练，进入下一年。':'完成本赛季全部赛事后，可以在这里安排专项训练与下一季去向。你的当前比赛进度不会被跳过。'}</p><div className={styles.stats}>{[['出场',summary.games],['赛季战绩',`${summary.wins}–${summary.losses}`],['场均得分',summary.pts.toFixed(1)],['场均篮板',summary.reb.toFixed(1)],['场均助攻',summary.ast.toFixed(1)],['本季荣誉',summary.honors.length]].map(([label,value])=><div key={label}><span>{label}</span><b>{value}</b></div>)}</div>{summary.best&&<p className={styles.memory}>赛季代表作：对阵 {summary.best.opponent}，{summary.best.pts} 分、{summary.best.reb} 篮板、{summary.best.ast} 助攻。</p>}{summary.honors.length>0&&<details><summary>查看本季荣誉</summary><ul>{summary.honors.map(h=><li key={h}>{h}</li>)}</ul></details>}</section>
    {ready&&<><section className={styles.panel}><h3>01 · 选择休赛期训练</h3><p className={styles.note}>在自然成长之外，为下列三个属性各增加 2 点（恢复计划为各 1 点）；不会突破个人上限，每个休赛期只能结算一次。</p><div className={styles.plans}>{DEVELOPMENT_PLANS.map(plan=><button key={plan.id} aria-pressed={focus===plan.id} onClick={()=>setFocus(plan.id)} className={focus===plan.id?styles.active:''}><strong>{plan.title}</strong><span>{plan.description}</span><small>{plan.keys.map(k=>RATING_LABELS[k]).join(' / ')} · {plan.id==='recovery'?'体力恢复至100':'新赛季体力90'}</small></button>)}</div></section>
    <section className={styles.panel}><h3>02 · {college?'留校、转学，或挑战 NBA':'决定下一季去向'}</h3>{college&&<div className={styles.actions}><button aria-pressed={!draft&&!finalCollegeYear} disabled={finalCollegeYear} onClick={()=>setDraft(false)}>继续大学生涯</button><button aria-pressed={draft||finalCollegeYear} onClick={()=>setDraft(true)}>报名 NBA 选秀</button></div>}{finalCollegeYear?<p>四年大学生涯已完成。这次休赛期将参加 NBA 选秀。</p>:college&&draft?<p>告别大学篮球，参加本地模拟选秀。顺位与球队由当前能力和潜力决定，选秀结果写入生涯档案。</p>:<><p className={styles.note}>{college?'邀请按当前位置、阵容竞争和球队实力模拟。转学后教练信任从40起步，旧球队的成绩保留。':freeAgent?'本合同即将到期，可选择下一份三年合同。报价由当前能力决定。':'合同仍在履行，本休赛期继续留队。交易申请可在下季交易窗口内进行。'}</p><label>下一季球队<select aria-label="休赛期球队" value={selected} onChange={e=>setDestination(e.target.value)}>{offers.map(team=><option key={team} value={team}>{team}{team===c.team?' · 留队':''}</option>)}</select></label><div className={styles.fit}><h4>{selected}</h4><p>{college?'预计角色':'阵容适配'}：{fit.label} · 参考时间 {fit.minutes} 分钟</p><p>同位置竞争：{fit.rivals.slice(0,3).map(p=>`${p.name} (${p.rating})`).join('、')||'名单暂未收录'}</p><small>位置、能力和参考时间为本地估计，实际出场由能力、角色和身体状态决定。</small></div></>}</section>
    <section className={styles.confirm}><p>确定训练计划：<b>{DEVELOPMENT_PLANS.find(p=>p.id===focus)?.title}</b>。{college&&(draft||finalCollegeYear)?'下一步：NBA 选秀。':`下一站：${selected}。`}</p><button onClick={()=>onChange(resolveOffseason(c,focus,selected,draft||finalCollegeYear))}>确认安排 · 开启下一季 →</button></section></>}
    {previous&&<section className={styles.panel}><h3>上一次休赛期 · {previous.season}–{String(previous.season+1).slice(-2)}</h3><p>{previous.summary}</p><div className={styles.growth}>{(Object.keys(RATING_LABELS) as RatingKey[]).map(key=><div key={key}><span>{RATING_LABELS[key]}</span><b>{previous.before[key]} → {previous.after[key]}</b><small>{previous.after[key]-previous.before[key]>=0?'+':''}{previous.after[key]-previous.before[key]}</small></div>)}</div><p className={styles.note}>变化包含自然成长、年龄变化与本次专项训练。</p></section>}
  </div>;
}
