import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  output: "export",
  distDir: process.env.NEXT_BUILD_DIR || ".next",
  images: { unoptimized: true },
  devIndicators: false,
};

export default nextConfig;
