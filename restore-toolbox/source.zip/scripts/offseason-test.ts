import assert from 'node:assert/strict';
// @ts-expect-error Native Node TypeScript runner.
import { createCareer, generatePlayer, simulateGames, validateCareer, simulateMatch } from '../src/lib/lanqiushengya/engine.ts';
// @ts-expect-error Native Node TypeScript runner.
import { advanceNcaaPostseason } from '../src/lib/lanqiushengya/ncaa.ts';
// @ts-expect-error Native Node TypeScript runner.
import { createNbaCareer, advanceNbaPostseason } from '../src/lib/lanqiushengya/nba.ts';
// @ts-expect-error Native Node TypeScript runner.
import { collegeOffers, isOffseason, resolveOffseason } from '../src/lib/lanqiushengya/offseason.ts';
const player=generatePlayer({name:'休赛期验证',potential:96,height:198,weight:92,wingspan:215,number:'9',position:'SG',description:'擅长三分传球和防守，有稳定的罚球'});
let college=createCareer(player,'杜克大学');
assert.equal(resolveOffseason(college,'shooting'),college);
college=simulateGames(college,30);
for(let i=0;i<9;i++)college=advanceNcaaPostseason(college);
assert.ok(isOffseason(college));
const prior=JSON.stringify(college), destination=collegeOffers(college).find(team=>team!==college.team)!;
const transferred=resolveOffseason(college,'defense',destination);
assert.equal(JSON.stringify(college),prior);
assert.equal(transferred.season,college.season+1);
assert.equal(transferred.team,destination);
assert.equal(transferred.game,0);
assert.equal(transferred.offseasons?.at(-1)?.route,'transfer');
assert.equal(transferred.ncaaHistory?.at(-1)?.season,college.season);
assert.equal(transferred.history.find(s=>s.season===college.season)?.team,college.team);
assert.ok(validateCareer(transferred));
assert.equal(resolveOffseason(transferred,'defense',destination),transferred);
assert.equal(resolveOffseason(college,'defense','不存在的大学'),college);
const drafted=resolveOffseason(college,'recovery',college.team,true);
assert.equal(drafted.phase,'nba');assert.equal(drafted.energy,100);assert.equal(drafted.offseasons?.at(-1)?.route,'draft');assert.ok(validateCareer(drafted));
for(const record of drafted.offseasons??[]) for(const key of Object.keys(record.after) as (keyof typeof record.after)[])assert.ok(record.after[key]<=drafted.player.caps[key]);
let nba=createNbaCareer(player);nba={...nba,contract:{...nba.contract,years:1}};nba=simulateGames(nba,82);
for(let i=0;i<40&&nba.nba?.stage!=='complete';i++)nba=advanceNbaPostseason(nba);
const signed=resolveOffseason(nba,'playmaking','金州勇士');assert.equal(signed.team,'金州勇士');assert.equal(signed.contract.years,3);assert.equal(signed.offseasons?.at(-1)?.route,'freeagency');assert.ok(validateCareer(signed));
const random=Math.random;Math.random=()=>.5;
const bench=simulateMatch({...transferred,role:1,trust:40},'杜克大学',true),starter=simulateMatch({...transferred,role:3,trust:80},'杜克大学',true);
Math.random=random;assert.ok(starter.min>bench.min);assert.equal(bench.started,false);assert.equal(starter.started,true);
assert.ok(!validateCareer({...signed,offseasons:[{...signed.offseasons![0],after:{}}]}));
console.log('Offseason checks passed: transfer and draft, free agency, single settlement, preserved archives, bounded growth, role minutes and malformed saves.');
