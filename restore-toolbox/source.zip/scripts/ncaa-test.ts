import assert from 'node:assert/strict';
// @ts-expect-error local TypeScript runner extension.
import {createCareer,generatePlayer,simulateGames,nextSeason,enterDraft,validateCareer,allSeasonGames,simulateMatch} from '../src/lib/lanqiushengya/engine.ts';
// @ts-expect-error local TypeScript runner extension.
import {ensureNcaa,advanceNcaaPostseason,pendingNcaaMatch,NCAA_TEAMS} from '../src/lib/lanqiushengya/ncaa.ts';
assert.equal(new Set(NCAA_TEAMS).size,64);
const p=generatePlayer({name:'锦标赛测试',potential:100,height:216,weight:118,wingspan:238,number:'0',position:'C',description:'内线防守 盖帽 篮板'});
let c=simulateGames(createCareer(p,'佛罗里达大学'),30);
assert.equal(ensureNcaa(c).ncaa?.stage,'conference');
assert.equal(c.ncaa?.matchups.length,7);
assert.equal(c.game,30);
assert.equal(nextSeason(c),c);
assert.equal(enterDraft(c),c);
const save=JSON.stringify(c); const tactics=['balanced','scoring','playmaking','defense'] as const;
for(const tactic of tactics){const g=simulateMatch(c,'杜克大学',true,tactic);assert.equal(g.tactic,tactic);assert.equal(g.periods?.reduce((s,p)=>s+p.team,0),g.teamScore);assert.equal(g.periods?.reduce((s,p)=>s+p.opponent,0),g.opponentScore);assert.equal(g.playByPlay?.at(-1)?.teamScore,g.teamScore);assert.equal(g.playByPlay?.at(-1)?.opponentScore,g.opponentScore);assert.equal(g.shots?.filter(s=>s.made).length,g.fgm);assert.equal(g.pts,2*g.fgm+g.tpm+g.ftm);}
assert.equal(JSON.stringify(c),save);
for(let round=0;round<9;round++){const before:number=c.ncaa!.postseasonGames.length;const pending=pendingNcaaMatch(c);c=advanceNcaaPostseason(c,'defense');assert.equal(c.ncaa!.postseasonGames.length-before,pending?1:0);assert.ok(validateCareer(c));}
assert.equal(c.ncaa?.stage,'complete');assert.equal(c.ncaa?.matchups.length,70);assert.ok(c.ncaa?.matchups.every(m=>m.winner));assert.ok(c.ncaa?.champion);assert.ok(c.ncaa!.postseasonGames.length>=1&&c.ncaa!.postseasonGames.length<=9);assert.equal(advanceNcaaPostseason(c),c);
const old=c;c=nextSeason(c);assert.equal(c.season,old.season+1);assert.equal(c.ncaaHistory?.length,1);assert.equal(c.history[0].games,allSeasonGames(old).length);assert.equal(c.game,0);assert.ok(validateCareer(c));
// Existing saves at the old 30-game endpoint gain a pending tournament rather than skip it.
const legacy={...old,ncaa:undefined};assert.equal(ensureNcaa(legacy).ncaa?.stage,'conference');assert.equal(nextSeason(legacy),legacy);
// Forced strong and weak outcomes exercise champion, elimination and non-qualification paths.
const random=Math.random;
try{
  let strong=simulateGames(createCareer(p,'佛罗里达大学'),30);strong.wins=30;strong.losses=0;for(const g of strong.games)g.won=true;
  for(const key of Object.keys(strong.player.ratings) as (keyof typeof strong.player.ratings)[])strong.player.ratings[key]=99;
  for(const key of Object.keys(strong.player.caps) as (keyof typeof strong.player.caps)[])strong.player.caps[key]=100;
  strong.ncaa=undefined;Math.random=()=>.99;
  for(let round=0;round<9;round++)strong=advanceNcaaPostseason(strong);
  assert.equal(strong.ncaa?.champion,strong.team);assert.equal(strong.ncaa?.postseasonGames.length,9);assert.equal(allSeasonGames(strong).length,39);assert.ok(strong.honors.some(a=>a.includes('全国锦标赛冠军')));
  Math.random=random;let weak=simulateGames(createCareer(p,'佛罗里达大学'),30);weak.wins=0;weak.losses=30;weak.ncaa=undefined;for(const g of weak.games)g.won=false;
  for(const key of Object.keys(weak.player.ratings) as (keyof typeof weak.player.ratings)[])weak.player.ratings[key]=25;
  Math.random=()=>0;
  for(let round=0;round<9;round++)weak=advanceNcaaPostseason(weak);
  assert.equal(weak.ncaa?.qualified,false);assert.equal(weak.ncaa?.finish,'未获全国锦标赛资格');assert.equal(weak.ncaa?.postseasonGames.length,1);assert.equal(weak.ncaa?.stage,'complete');assert.ok(weak.ncaa?.champion);
}finally{Math.random=random;}
console.log('NCAA checks passed: 64 teams, complete seeded bracket, one own match per step, elimination/qualification, 39-game championship path, coherent scores, save migration and archival.');
