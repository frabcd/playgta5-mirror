import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
// @ts-expect-error Node test runner loads TypeScript directly.
import { buildNbaAwards, seriesMvp } from '../src/lib/lanqiushengya/nba-awards.ts';
// @ts-expect-error Node test runner loads TypeScript directly.
import { generatePlayer, simulateGames, nextSeason, validateCareer } from '../src/lib/lanqiushengya/engine.ts';
// @ts-expect-error Node test runner loads TypeScript directly.
import { createNbaCareer, advanceNbaPostseason, initializeNbaPostseason, pendingNbaMatch, playNbaPostseasonGame, requestTrade } from '../src/lib/lanqiushengya/nba.ts';
// @ts-expect-error Node test runner loads TypeScript directly.
import { getRoster } from '../src/lib/lanqiushengya/rosters.ts';
let c = createNbaCareer(generatePlayer({name:'职业测试',position:'C',height:216,weight:115,wingspan:230,potential:98,number:'8',description:'篮板 盖帽'}));
const before = JSON.stringify(c);
let played = simulateGames(c, 10);
assert.equal(JSON.stringify(c), before);
assert.equal(played.game, 10);
const traded = requestTrade(played, '金州勇士');
assert.equal(traded.wins, traded.nba!.standings.find(t => t.team === '金州勇士')!.wins);
assert.equal(requestTrade(traded, '芝加哥公牛'), traded);
c = simulateGames(traded, 100);
assert.equal(c.game, 82);
assert.equal(c.nba!.stage, 'playin');
assert.equal(c.nba!.series.length, 21, 'Full bracket must exist before a postseason game');
assert.equal(c.nba!.series.filter(s => s.winner).length, 0);
assert.equal(c.nba!.series.filter(s => s.scores?.length).length, 0);
assert.equal(nextSeason(c), c);
assert.equal(c.nba!.standings.reduce((v,t) => v+t.wins,0),1230);
for (const row of c.nba!.standings) assert.equal(row.wins+row.losses,82);
// Select a play-in participant in the test fixture to exercise the two-step path.
const chosen = c.nba!.standings.find(t => t.conference === '东部' && t.seed === 7)!;
c = {...c, team: chosen.team, wins: chosen.wins, losses: chosen.losses};
const pending = pendingNbaMatch(c)!;
assert.equal(pending.round, 0);
assert.equal(pending.gameNumber, 1);
const original = JSON.stringify(c);
c = playNbaPostseasonGame(c, 'defense');
assert.equal(JSON.parse(original).nba.playoffGames.length, 0);
assert.equal(c.nba!.playoffGames.length, 1);
assert.equal(c.nba!.series.filter(s => s.round === 0 && s.winner).length, 4, 'Day one cannot also simulate the final play-in match');
assert.equal(c.nba!.stage, 'playin');
c = playNbaPostseasonGame(c);
assert.equal(c.nba!.stage, 'playoffs');
assert.equal(c.nba!.round, 1);
assert.equal(c.nba!.series.filter(s => s.round === 0 && s.winner).length, 6);
assert.equal(c.nba!.series.filter(s => s.round === 1 && s.status === 'ready').length, 8);
assert.ok(validateCareer(JSON.parse(JSON.stringify(c))), 'A pending playoff bracket must survive save validation');
const tacticTeam = c.nba!.standings.find(t => t.conference === '东部' && t.seed === 1)!;
const tacticFixture = { ...c, team: tacticTeam.team, wins: tacticTeam.wins, losses: tacticTeam.losses, energy: 100, nba: { ...c.nba!, injury: undefined } };
const oldRandom = Math.random;
try {
  Math.random = () => .5;
  const balanced = playNbaPostseasonGame(tacticFixture, 'balanced');
  const scoring = playNbaPostseasonGame(tacticFixture, 'scoring');
  const playmaking = playNbaPostseasonGame(tacticFixture, 'playmaking');
  const defense = playNbaPostseasonGame(tacticFixture, 'defense');
  assert.ok(scoring.nba!.playoffGames.at(-1)!.fga > balanced.nba!.playoffGames.at(-1)!.fga);
  assert.ok(playmaking.nba!.playoffGames.at(-1)!.ast > balanced.nba!.playoffGames.at(-1)!.ast);
  assert.ok(defense.nba!.playoffGames.at(-1)!.fga < balanced.nba!.playoffGames.at(-1)!.fga);
  assert.ok(scoring.energy < balanced.energy);
} finally { Math.random = oldRandom; }
let days = 2;
while (c.nba!.stage !== 'complete' && days < 40) {
  const last = c.nba!.playoffGames.length;
  const scores = new Map(c.nba!.series.map(s => [s.id, s.homeWins + s.awayWins]));
  const old = JSON.stringify(c);
  const next = advanceNbaPostseason(c, 'playmaking');
  assert.equal(JSON.stringify(c), old, 'Advancement is immutable');
  c = next;
  assert.ok(c.nba!.playoffGames.length-last <= 1, 'Each click can play at most one user game');
  for (const s of c.nba!.series) {
    assert.ok(s.homeWins+s.awayWins-(scores.get(s.id)??0) <= 1, 'Each series advances at most one game');
    if (s.round > 0 && s.winner) assert.equal(Math.max(s.homeWins,s.awayWins),4);
  }
  days++;
}
assert.equal(c.nba!.stage,'complete');
assert.ok(days >= 18 && days <= 30);
assert.equal(c.nba!.series.length,21);
assert.equal(c.nba!.series.filter(s => s.round === 4).length,1);
assert.equal(c.nba!.awards.length,18);
for (const award of c.nba!.awards.filter(a => !a.player && a.name !== '总冠军' && !a.winner.includes('模拟新秀') && a.winner !== '本季无人符合资格')) assert.ok(getRoster(award.team,c.season).some(p => p.name === award.winner), `${award.winner} must belong to ${award.team}`);
for (const [name, count] of [['最佳阵容',15],['最佳防守阵容',10],['最佳新秀阵容',10],['全明星',24]] as const) {
  const award=c.nba!.awards.find(a=>a.name===name)!;
  assert.equal(award.members!.length,count);
  assert.equal(new Set(award.members!.map(p=>p.id)).size,count);
  assert.equal(award.player,award.members!.some(p=>p.player));
}
for(const award of c.nba!.awards) {
  const scores=award.candidates?.map(p=>p.score)??[];
  assert.deepEqual(scores,[...scores].sort((a,b)=>b-a));
}
assert.equal(c.nba!.awards.find(a=>a.name==='总决赛 MVP')!.team,c.nba!.champion);
const actualSeries=c.nba!.series.find(s=>s.games.some(g=>g.boxScore))!;
const winnerBoxes=actualSeries.games.flatMap(g=>g.team===actualSeries.winner?g.boxScore?.team??[]:g.boxScore?.opponent??[]).filter(p=>p.min>0);
const scores=new Map<string,number>();
for(const p of winnerBoxes) scores.set(p.id,(scores.get(p.id)??0)+p.pts+p.reb*1.2+p.ast*1.5+(p.stl+p.blk)*2);
const voted=seriesMvp(c,actualSeries,'测试 MVP');
assert.ok(Math.abs(voted.candidates![0].score-Math.max(...scores.values()))<.00001,'Series MVP compares actual winner-team box scores');
const limited={...c,games:c.games.filter(g=>g.season!==c.season).concat(c.games.filter(g=>g.season===c.season&&g.min>0).slice(0,40).map(g=>({...g,pts:100,reb:30,ast:30})))};
assert.ok(!buildNbaAwards(limited).find(a=>a.name==='常规赛 MVP')!.candidates!.some(p=>p.player),'Insufficient attendance excludes even a dominant player');
const starters={...c,games:c.games.map(g=>({...g,started:true}))};
assert.ok(!buildNbaAwards(starters).find(a=>a.name==='最佳第六人')!.candidates!.some(p=>p.player),'Sixth man uses actual starts rather than current role');
for(const conf of ['东部','西部']) assert.equal(c.nba!.awards.find(a=>a.name===conf+'决赛 MVP')!.team,c.nba!.series.find(s=>s.round===3&&s.conference===conf)!.winner);
assert.equal(c.history.find(s => s.season === c.season)!.games,[...c.games.filter(g => g.season === c.season),...c.nba!.playoffGames].filter(g => g.min > 0).length);
for (const s of c.nba!.series) {
  assert.equal(Math.max(s.homeWins,s.awayWins),s.round === 0 ? 1 : 4);
  assert.equal(s.winner,s.homeWins > s.awayWins ? s.home : s.away);
  assert.equal(s.scores!.length,s.homeWins+s.awayWins);
  s.scores!.forEach((g, i) => {
    assert.equal(g.homeWon,g.homeScore > g.awayScore);
    assert.equal(g.home,s.round === 0 || [0,1,4,6].includes(i) ? s.home : s.away);
    assert.notEqual(g.homeScore,g.awayScore);
  });
  for (const g of s.games) {
    assert.equal(g.pts,2*g.fgm+g.tpm+g.ftm);
    assert.equal(g.won,g.teamScore > g.opponentScore);
    assert.ok(g.fgm <= g.fga && g.tpm <= g.tpa);
    assert.equal(typeof g.started,'boolean');
    assert.ok(g.boxScore);
    assert.equal(g.boxScore!.team.reduce((v,p) => v+p.pts,0),g.teamScore);
    assert.equal(g.boxScore!.opponent.reduce((v,p) => v+p.pts,0),g.opponentScore);
    assert.equal(g.boxScore!.team.find(p => p.isUser)!.pts,g.pts);
    for (const row of g.boxScore!.team.filter(p => !p.isUser && !p.generated)) assert.ok(getRoster(g.team!,g.season).some(p => p.name === row.name));
    for (const row of g.boxScore!.opponent.filter(p => !p.generated)) assert.ok(getRoster(g.opponent,g.season).some(p => p.name === row.name));
    assert.equal(g.periods!.reduce((v,p) => v+p.team,0),g.teamScore);
    assert.equal(g.periods!.reduce((v,p) => v+p.opponent,0),g.opponentScore);
    assert.equal(g.playByPlay!.at(-1)!.teamScore,g.teamScore);
    assert.equal(g.playByPlay!.at(-1)!.opponentScore,g.opponentScore);
  }
}
for (const g of [...c.games,...c.nba!.playoffGames]) {
  assert.equal(g.shots!.length,g.fga);
  assert.equal(g.shots!.filter(s => s.made).length,g.fgm);
  assert.equal(g.shots!.filter(s => s.three).length,g.tpa);
  assert.equal(g.shots!.filter(s => s.three && s.made).length,g.tpm);
}
for (let round=2;round<=4;round++) {
  const previous=c.nba!.series.filter(s=>s.round===round-1).map(s=>s.winner);
  const participants=c.nba!.series.filter(s=>s.round===round).flatMap(s=>[s.home,s.away]);
  assert.deepEqual([...participants].sort(),[...previous].sort());
  assert.equal(new Set(participants).size,participants.length);
}
assert.equal(advanceNbaPostseason(c),c);
const previous=c.nba!;
played=nextSeason(c);
assert.equal(played.game,0);
assert.deepEqual(played.nbaHistory![0],previous);
assert.ok(validateCareer(played));
assert.ok(!validateCareer({...played,nbaHistory:[{...previous,awards:[{...previous.awards[0],candidates:[{id:'bad'}]}]}]}));
if(process.env.NBA_UI_FIXTURE) writeFileSync(process.env.NBA_UI_FIXTURE,JSON.stringify({version:1,appearance:{skin:2,face:0,hair:1,hairColor:0,eyes:0,beard:0},career:played}));
assert.ok(!validateCareer({...played,nba:{...played.nba,standings:[]}}));
assert.equal(played.nba!.standings.reduce((v,t)=>v+t.wins,0),0);
let injured=createNbaCareer(c.player);
injured.nba!.injury={name:'测试伤病',remaining:1};
injured=simulateGames(injured,1);
assert.equal(injured.games[0].min,0);
assert.equal(injured.games[0].shots!.length,0);
assert.equal(injured.nba!.injury,undefined);
injured=simulateGames(injured,1);
assert.ok(injured.games[1].min>0);
const legacy={...c,nba:{...c.nba!,bracketVersion:undefined,series:c.nba!.series.map(s=>({...s,id:undefined,sources:undefined,status:undefined,scores:undefined}))}};
const migrated=initializeNbaPostseason(legacy);
assert.equal(migrated.nba!.stage,'complete');
assert.equal(migrated.nba!.champion,c.nba!.champion);
assert.deepEqual(migrated.nba!.playoffGames,c.nba!.playoffGames);
assert.equal(migrated.nba!.series.filter(s=>s.winner).length,21);
console.log('NBA checks passed: upfront bracket, two-day play-in, one game per action, best-of-seven clinches, home schedule, NPC scores, quarter/timeline totals, shots, injuries, archives, legacy migration.');
