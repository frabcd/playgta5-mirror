import assert from 'node:assert/strict';
// @ts-expect-error local TypeScript runner.
import {generatePlayer,createCareer} from '../src/lib/lanqiushengya/engine.ts';
// @ts-expect-error local TypeScript runner.
import {createNbaCareer} from '../src/lib/lanqiushengya/nba.ts';
// @ts-expect-error local TypeScript runner.
import {getAvailableStory,getStoryState,chooseStory,getStoryModifiers,validateStory,type StoryState,type StoryEvent} from '../src/lib/lanqiushengya/story.ts';
// @ts-expect-error local TypeScript runner.
import {STORY_EVENTS} from '../src/lib/lanqiushengya/story-data.ts';
const p=generatePlayer({name:'剧情测试',potential:95,height:198,weight:90,wingspan:210,number:'8',position:'SF',description:'投篮和传球'});
assert.ok(STORY_EVENTS.length>=36);
assert.equal(new Set(STORY_EVENTS.map(e=>e.id)).size,STORY_EVENTS.length);
for(const e of STORY_EVENTS){assert.ok(e.choices.length>=2&&e.choices.length<=3);assert.equal(new Set(e.choices.map(c=>c.id)).size,e.choices.length);for(const choice of e.choices)if(choice.followUp)assert.ok(STORY_EVENTS.some(next=>next.id===choice.followUp&&next.followUpOnly));}
for(const original of [createCareer(p,'佛罗里达大学'),createNbaCareer(p,'洛杉矶湖人')]){
  const serialized=JSON.stringify(original);
  assert.ok(validateStory(getStoryState(original)));
  const available=getAvailableStory(original)!;
  assert.ok(available.fictional);assert.ok(available.context.includes('原创虚构剧情'));
  assert.equal(JSON.stringify(getAvailableStory(original)),JSON.stringify(available));
  assert.equal(JSON.stringify(original),serialized);
  assert.equal(chooseStory(original,'missing','bad'),original);
  assert.equal(chooseStory(original,available.id,'missing'),original);
  let c=chooseStory(original,available.id,available.choices[0].id);
  assert.notEqual(c,original);assert.equal(JSON.stringify(original),serialized);
  assert.equal(chooseStory(c,available.id,available.choices[0].id),c);
  assert.equal(getStoryState(c).history.length,1);
  const record=getStoryState(c).history[0];
  assert.equal(record.before.energy,original.energy);assert.equal(record.after.energy,c.energy);
  assert.equal(record.effects.energy,record.after.energy-record.before.energy);
  assert.ok(!record.body.includes('{teammate}'));
  // Passing milestones never chooses stories automatically; pending scenes are explicitly catch-up scenes.
  c={...c,game:c.phase==='college'?30:82};
  assert.equal(getStoryState(c).history.length,1);
  const pendingAtEnd=getAvailableStory(c)!;
  assert.ok(!pendingAtEnd.context.includes('季前准备'));
  assert.equal(pendingAtEnd.scheduledGame,c.phase==='college'?30:82);
  for(let guard=0;guard<30;guard++){
    const event:StoryEvent|undefined=getAvailableStory(c);if(!event)break;
    c=chooseStory(c,event.id,event.choices[0].id);
    assert.ok(validateStory(getStoryState(c)));
    for(const n of Object.values(getStoryModifiers(c)))assert.ok(n>=-.06&&n<=.06);
  }
  const records=getStoryState(c).history;
  const main=records.filter(r=>!STORY_EVENTS.find(e=>e.id===r.eventId)?.followUpOnly);
  assert.equal(main.length,c.phase==='college'?12:16);
  assert.equal(new Set(records.map(r=>r.key)).size,records.length);
  assert.equal(getAvailableStory(c),undefined);
  const prior=JSON.stringify(getStoryState(c));
  const next={...c,season:c.season+1,game:0};
  assert.ok(getAvailableStory(next));assert.equal(JSON.stringify(getStoryState(c)),prior);
  const retired={...c,phase:'retired' as const};assert.equal(getAvailableStory(retired),undefined);
}
// Branches unlock a specific later scene and can never award it twice.
let branch=createCareer(p,'佛罗里达大学');let found=false;
for(let i=0;i<1000;i++){branch={...branch,player:{...p,name:`同室测试${i}`}};if(getAvailableStory(branch)?.id==='campus-roommate'){found=true;break;}}
assert.ok(found);
branch=chooseStory(branch,'campus-roommate','film');assert.notEqual(getAvailableStory(branch)?.id,'campus-film-follow');
branch={...branch,game:2};assert.equal(getAvailableStory(branch)?.id,'campus-film-follow');
branch=chooseStory(branch,'campus-film-follow','simple');assert.equal(getStoryState(branch).history.length,2);assert.equal(chooseStory(branch,'campus-film-follow','simple'),branch);
const extreme:StoryState={...getStoryState(branch),meters:{chemistry:100,reputation:100,pressure:100,academics:0,leadership:100}};
assert.ok(Object.values(getStoryModifiers({...branch,story:extreme})).every(n=>n>=-.06&&n<=.06));
assert.ok(!validateStory({...extreme,meters:{...extreme.meters,pressure:NaN}}));
assert.ok(!validateStory({...extreme,history:[extreme.history[0],extreme.history[0]]}));
assert.ok(!validateStory({...extreme,flags:{bad:'yes'}}));
assert.ok(!validateStory({...extreme,history:[{...extreme.history[0],after:{...extreme.history[0].after,energy:-1}}]}));
console.log(`Story checks passed: ${STORY_EVENTS.length} unique fictional scenes, deterministic scheduling, 12/16 season slots, branching follow-ups, bounded effects/modifiers, immutable snapshots, no repeated rewards, old-save defaults and validation.`);
