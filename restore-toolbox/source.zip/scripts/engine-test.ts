import assert from 'node:assert/strict';
// @ts-expect-error Node's strip-types runner requires a direct TypeScript extension.
import { generatePlayer, createCareer, simulateGames, nextSeason, enterDraft, train, rest, upgrade, upgradeCost, overall, validateCareer, COLLEGES, NBA_TEAMS, signTeam, seasonEvent, challengeCareer, simulateMonth } from '../src/lib/lanqiushengya/engine.ts';

// @ts-expect-error Node's strip-types runner requires a direct TypeScript extension.
import { advanceNbaPostseason } from '../src/lib/lanqiushengya/nba.ts';
// @ts-expect-error direct TypeScript extension for local runner.
import { advanceNcaaPostseason } from '../src/lib/lanqiushengya/ncaa.ts';
// @ts-expect-error direct TypeScript extension for local runner.
import { allSeasonGames } from '../src/lib/lanqiushengya/engine.ts';
const player = generatePlayer({ name: '测试球员', potential: 100, height: 198, weight: 90, wingspan: 215, number: '8', position: 'SG', description: '三分出色，传球弱，不会盖帽，对抗差' });
assert.ok(overall(player) <= 70);
assert.equal(player.caps.pass, 70);
assert.equal(player.caps.block, 50);
assert.equal(player.caps.strength, 70);
assert.equal(player.caps.three, 98);
let c = createCareer(player, COLLEGES[0]);
assert.ok(validateCareer(c));
assert.ok(!validateCareer({ ...c, games: [null] }));
assert.ok(!validateCareer({ ...c, player: { ...player, ratings: {} } }));
assert.equal(enterDraft(c), c);
const original = JSON.stringify(c);
const trained = train(c, 'shooting', 'S');
assert.equal(JSON.stringify(c), original);
assert.equal(trained.energy, 75);
assert.equal(rest(trained).energy, 100);
assert.equal(upgrade(trained, 'mid').player.ratings.mid, player.ratings.mid + 1);
assert.ok(upgradeCost({ ...player, potential: 80 }, 'three') >= upgradeCost(player, 'three'));
let stories = seasonEvent(seasonEvent(seasonEvent(seasonEvent(c))));
assert.equal(stories.eventStep, 4);
assert.equal(seasonEvent(stories), stories);
assert.deepEqual(seasonEvent(c), seasonEvent(c));
stories = challengeCareer(stories, 'scoring');
assert.ok(stories.challengeGoal);
stories = simulateGames(stories, 5);
assert.equal(stories.challengeGoal, undefined);
assert.equal(challengeCareer(stories, 'inside'), stories);
assert.equal(simulateMonth(c).game, 10);
assert.equal(simulateMonth(simulateMonth(c)).game, 20);
c = simulateGames(c, 1000);
assert.equal(c.game, 30);
assert.equal(c.wins + c.losses, 30);
assert.equal(c.history.length, 1);
assert.equal(simulateGames(c, 2), c);
for (const g of c.games) {
  assert.equal(g.pts, (g.fgm - g.tpm) * 2 + g.tpm * 3 + g.ftm);
  assert.ok(g.fgm <= g.fga && g.tpm <= g.tpa && g.ftm <= g.fta);
  assert.equal(g.won, g.teamScore > g.opponentScore);
  assert.notEqual(g.teamScore, g.opponentScore);
}
for (let i = 0; i < 3; i++) {
  assert.equal(nextSeason(c), c);
  for(let r=0;r<9;r++) c=advanceNcaaPostseason(c);
  assert.equal(c.ncaa?.stage, 'complete');
  c = simulateGames(nextSeason(c), 1000);
}
for(let r=0;r<9;r++) c=advanceNcaaPostseason(c);
c = nextSeason(c);
assert.equal(c.phase, 'nba');
assert.equal(c.age, 22);
assert.equal(c.history.length, 4);
assert.equal(c.games.length, 120);
assert.ok(c.contract.salary >= 2500000);
const youngSpeed = c.player.ratings.speed;
for (let i = 0; i < 25; i++) {
  c = simulateGames(c, 1000);
  assert.equal(nextSeason(c), c);
  for (let round = 0; round < 50 && c.nba?.stage !== 'complete'; round++) c = advanceNbaPostseason(c);
  assert.equal(c.nba?.stage, 'complete');
  c = nextSeason(c);
  assert.ok(validateCareer(c));
  if (i === 2) { assert.equal(c.contract.years, 0); c = signTeam(c, NBA_TEAMS[0]); assert.equal(c.team, NBA_TEAMS[0]); }
}
assert.equal(c.phase, 'retired');
assert.equal(c.history.length, 29);
assert.equal(c.games.length, 120 + 25 * 82);
assert.ok(c.player.ratings.speed < youngSpeed);
for (const season of c.history) {
  const games = allSeasonGames(c, season.season);
  assert.equal(games.filter(g => g.min > 0).length, season.games);
  assert.equal(season.pts, Math.round(games.reduce((sum, g) => sum + g.pts, 0) / Math.max(1, season.games) * 10) / 10);
}
assert.equal(new Set(c.history.map(s => s.season)).size, 29);
assert.equal(train(c, 'shooting', 'S'), c);
assert.equal(simulateGames(c, 1), c);
console.log('Engine checks passed: immutable actions, training, box scores, season limits, draft, contracts, 29-season career, save validation.');
