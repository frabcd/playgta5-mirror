import assert from 'node:assert/strict';
// @ts-expect-error local TypeScript runner.
import {createCareer,generatePlayer,simulateMatch,validateCareer,simulateGames} from '../src/lib/lanqiushengya/engine.ts';
// @ts-expect-error local TypeScript runner.
import {createNbaCareer} from '../src/lib/lanqiushengya/nba.ts';
// @ts-expect-error local TypeScript runner.
import {addBoxScore,validBoxScore,type BoxPlayer} from '../src/lib/lanqiushengya/boxscore.ts';
const p=generatePlayer({name:'数据核对',potential:95,height:198,weight:90,wingspan:210,number:'8',position:'SF',description:'三分传球'});
for(const career of [createCareer(p,'佛罗里达大学'),createNbaCareer(p,'洛杉矶湖人')]){
  for(const opponent of [career.phase==='college'?'杜克大学':'金州勇士','未收录球队']){
    for(const injured of [false,true]){
      const c=injured&&career.nba?{...career,nba:{...career.nba,injury:{name:'测试',remaining:2}}}:career;
      const before=JSON.stringify(c),g=simulateMatch(c,opponent,true);
      assert.equal(JSON.stringify(c),before);assert.ok(g.boxScore&&validBoxScore(g.boxScore));
      for(const [key,total] of [['team',g.teamScore],['opponent',g.opponentScore]] as const){
        const rows:BoxPlayer[]=g.boxScore![key];
        assert.equal(rows.reduce((s,r)=>s+r.pts,0),total);
        assert.equal(rows.reduce((s,r)=>s+r.min,0),career.phase==='college'?200:240);
        assert.equal(rows.filter(r=>r.started).length,5);
        for(const r of rows){assert.equal(r.pts,r.fgm*2+r.tpm+r.ftm);assert.ok(r.min<=(career.phase==='college'?40:48));assert.ok(r.fgm<=r.fga&&r.tpm<=r.tpa&&r.ftm<=r.fta);}
      }
      const own=g.boxScore!.team.find(r=>r.isUser)!;
      for(const key of ['pts','reb','ast','stl','blk','min','fgm','fga','tpm','tpa','ftm','fta'] as const)assert.equal(own[key],g[key]);
      assert.ok(g.boxScore!.team.some(r=>!r.isUser&&!r.generated&&r.source));
      if(opponent==='未收录球队')assert.ok(g.boxScore!.opponent.every(r=>r.generated&&r.name.includes('模拟')));
      assert.equal(addBoxScore(g,c),g);
      const overtime=addBoxScore({...g,boxScore:undefined,periods:[...g.periods!,{label:'加时1',team:0,opponent:0}]},c);
      assert.equal(overtime.boxScore!.team.reduce((sum,r)=>sum+r.min,0),(career.phase==='college'?200:240)+25);
      assert.equal(overtime.boxScore!.opponent.reduce((sum,r)=>sum+r.min,0),(career.phase==='college'?200:240)+25);
    }
  }
  const played=simulateGames(career,1);assert.ok(validateCareer(played));
  const invalid=structuredClone(played);invalid.games[0].boxScore!.team[0].pts=-1;assert.equal(validateCareer(invalid),false);
}
console.log('Box-score checks passed: real sourced rosters, explicit simulated fallbacks, exact team points and minutes, user line, DNP, shooting arithmetic, immutable snapshots and malformed-import validation.');
