import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { writeFileSync } from 'node:fs';
if (!process.env.GTA_PASSWORD) throw Error('GTA_PASSWORD must be supplied at packaging time');
const salt=randomBytes(24).toString('hex');
const passwordHash=pbkdf2Sync(process.env.GTA_PASSWORD,salt,10000,32,'sha256').toString('hex');
const sessionKey=randomBytes(32).toString('hex');
const constants=JSON.stringify({salt,passwordHash,sessionKey,origin:'https://9104c0b6.fran-abcd-abcd.pages.dev'});
const worker=`const config=${constants};
const enc=new TextEncoder();
const hex=bytes=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
async function sign(value){const key=await crypto.subtle.importKey('raw',enc.encode(config.sessionKey),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode(value)));}
async function passwordMatches(password){if(typeof password!=='string'||password.length>256)return false;const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);const result=hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(config.salt),iterations:10000,hash:'SHA-256'},key,256));let diff=0;for(let i=0;i<result.length;i++)diff|=result.charCodeAt(i)^config.passwordHash.charCodeAt(i);return diff===0;}
function privateHeaders(extra={}){return {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...extra};}
export default {async fetch(request,env){const url=new URL(request.url);
if(url.pathname==='/api/game-unlock'){
 if(request.method!=='POST')return new Response('Method not allowed',{status:405});
 if(request.headers.get('Origin')!==url.origin)return new Response('Forbidden',{status:403});
 if(Number(request.headers.get('Content-Length')||0)>2048)return new Response('Too large',{status:413});
 let body;try{body=await request.json();}catch{return new Response('Invalid request',{status:400});}
 if(!await passwordMatches(body.password))return new Response('Incorrect password',{status:401,headers:privateHeaders()});
 const expiry=String(Date.now()+8*60*60*1000),token=expiry+'.'+await sign(expiry);
 return new Response('OK',{headers:privateHeaders({'Set-Cookie':'fran_game='+token+'; Path=/calculator/gta-v; Max-Age=28800; HttpOnly; Secure; SameSite=Strict'})});
}
if(url.pathname==='/calculator/gta-v/play'){
 const token=(request.headers.get('Cookie')||'').split(';').map(v=>v.trim()).find(v=>v.startsWith('fran_game='))?.slice(10)||'';
 const [expiry,signature]=token.split('.');
 if(!expiry||Number(expiry)<Date.now()||Number(expiry)>Date.now()+28800000||signature!==await sign(expiry))return Response.redirect(url.origin+'/calculator/gta-v/',303);
 return new Response('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>洛圣都 · 计算器</title><style>body{margin:0;background:#111;color:white;font:14px Arial}nav{height:40px;display:flex;align-items:center;padding:0 16px;gap:20px}a{color:inherit}iframe{display:block;width:100%;height:calc(100svh - 40px);border:0}</style><nav><a href="/calculator">← 返回计算器</a><span>洛圣都 · 单人模式</span></nav><iframe src="'+config.origin+'/?low=1&fps=30&res=1280x720&shadows=0" title="洛圣都单人游戏" allow="cross-origin-isolated; fullscreen; gamepad; autoplay" allowfullscreen></iframe></html>',{headers:privateHeaders({'Content-Type':'text/html; charset=utf-8','Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Embedder-Policy':'require-corp','Permissions-Policy':'cross-origin-isolated=(self "'+config.origin+'")','Content-Security-Policy':"frame-ancestors 'self'"})});
}
if(url.pathname==='/calculator/gta-v'||url.pathname==='/calculator/gta-v/'){
 const response=await env.ASSETS.fetch(new Request(new URL('/gta-login.html',url),request));return new Response(response.body,{status:response.status,headers:new Headers([...response.headers,...Object.entries(privateHeaders())])});
}
return env.ASSETS.fetch(request);
}};`;
writeFileSync('out/_worker.js',worker);
writeFileSync('out/_routes.json',JSON.stringify({version:1,include:['/api/game-unlock','/calculator/gta-v','/calculator/gta-v/*'],exclude:[]}));
console.log('Packaged server-verified calculator gate; plaintext password is not included.');
